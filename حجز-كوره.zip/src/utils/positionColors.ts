export interface PositionStyle {
  cardBg: string;
  cardBorder: string;
  badgeBg: string;
  badgeText: string;
  avatarRing: string;
  indicatorDot: string;
  glowEffect: string;
  roleIcon: string;
  shortLabel: string;
  category: 'gk' | 'def' | 'mid' | 'att' | 'joker';
  categoryLabel: string;
}

export const getPositionStyle = (position?: string): PositionStyle => {
  if (!position) {
    return {
      cardBg: 'bg-neutral-900/90',
      cardBorder: 'border-neutral-800 hover:border-neutral-700',
      badgeBg: 'bg-neutral-800/80 border-neutral-700 text-neutral-300',
      badgeText: 'text-neutral-300',
      avatarRing: 'ring-1 ring-neutral-700',
      indicatorDot: 'bg-neutral-400',
      glowEffect: 'shadow-neutral-950/30',
      roleIcon: '⚽',
      shortLabel: 'لاعب',
      category: 'joker',
      categoryLabel: 'غير محدد'
    };
  }

  const p = position.toLowerCase();

  // 1. حارس المرمى (Goalkeeper) -> أصفر عنبري / ذهبي
  if (p.includes('جون') || p.includes('حارس') || p.includes('مرمى') || p.includes('gk')) {
    return {
      cardBg: 'bg-gradient-to-r from-amber-950/45 via-amber-900/20 to-neutral-950',
      cardBorder: 'border-amber-500/45 hover:border-amber-400',
      badgeBg: 'bg-amber-500/20 border-amber-500/40 text-amber-300',
      badgeText: 'text-amber-300',
      avatarRing: 'ring-2 ring-amber-500/60',
      indicatorDot: 'bg-amber-400 shadow-[0_0_8px_rgba(251,191,36,0.9)]',
      glowEffect: 'shadow-amber-950/30',
      roleIcon: '🧤',
      shortLabel: 'حارس مرمى',
      category: 'gk',
      categoryLabel: 'حراسة المرمى'
    };
  }

  // 2. المهاجم (Striker / Forward) -> أحمر ناري / وردي دافئ
  if (p.includes('مهاجم') || p.includes('حربة') || p.includes('striker') || p.includes('forward')) {
    return {
      cardBg: 'bg-gradient-to-r from-rose-950/50 via-rose-900/20 to-neutral-950',
      cardBorder: 'border-rose-500/50 hover:border-rose-400',
      badgeBg: 'bg-rose-500/20 border-rose-500/40 text-rose-300',
      badgeText: 'text-rose-300',
      avatarRing: 'ring-2 ring-rose-500/60',
      indicatorDot: 'bg-rose-400 shadow-[0_0_8px_rgba(251,113,133,0.9)]',
      glowEffect: 'shadow-rose-950/30',
      roleIcon: '🔥',
      shortLabel: 'مهاجم (رأس حربة)',
      category: 'att',
      categoryLabel: 'خط الهجوم'
    };
  }

  // 3. الأجنحة (Wings) -> برتقالي رياضي مفعم بالطاقة
  if (p.includes('وينج') || p.includes('wing') || p.includes('جناح')) {
    const isRight = p.includes('يمين') || p.includes('right');
    return {
      cardBg: 'bg-gradient-to-r from-orange-950/45 via-orange-900/20 to-neutral-950',
      cardBorder: 'border-orange-500/45 hover:border-orange-400',
      badgeBg: 'bg-orange-500/20 border-orange-500/40 text-orange-300',
      badgeText: 'text-orange-300',
      avatarRing: 'ring-2 ring-orange-500/60',
      indicatorDot: 'bg-orange-400 shadow-[0_0_8px_rgba(251,146,60,0.9)]',
      glowEffect: 'shadow-orange-950/30',
      roleIcon: '⚡',
      shortLabel: isRight ? 'وينج يمين' : 'وينج شمال',
      category: 'att',
      categoryLabel: 'أجنحة هجومية'
    };
  }

  // 4. خط الدفاع (Defenders)
  // قلب دفاع (مساك) -> أزرق ملكي متين
  if (p.includes('مساك') || p.includes('دفاع') || p.includes('cb') || p.includes('defender')) {
    return {
      cardBg: 'bg-gradient-to-r from-blue-950/45 via-blue-900/20 to-neutral-950',
      cardBorder: 'border-blue-500/45 hover:border-blue-400',
      badgeBg: 'bg-blue-500/20 border-blue-500/40 text-blue-300',
      badgeText: 'text-blue-300',
      avatarRing: 'ring-2 ring-blue-500/60',
      indicatorDot: 'bg-blue-400 shadow-[0_0_8px_rgba(96,165,250,0.9)]',
      glowEffect: 'shadow-blue-950/30',
      roleIcon: '🛡️',
      shortLabel: 'مساك (قلب دفاع)',
      category: 'def',
      categoryLabel: 'خط الدفاع'
    };
  }

  // باك يمين / شمال (Fullbacks) -> سماوي / أزرق نيلي سريع
  if (p.includes('باك') || p.includes('ظهير') || p.includes('lb') || p.includes('rb')) {
    const isRight = p.includes('يمين');
    return {
      cardBg: 'bg-gradient-to-r from-sky-950/45 via-sky-900/20 to-neutral-950',
      cardBorder: 'border-sky-500/45 hover:border-sky-400',
      badgeBg: 'bg-sky-500/20 border-sky-500/40 text-sky-300',
      badgeText: 'text-sky-300',
      avatarRing: 'ring-2 ring-sky-500/60',
      indicatorDot: 'bg-sky-400 shadow-[0_0_8px_rgba(56,189,248,0.9)]',
      glowEffect: 'shadow-sky-950/30',
      roleIcon: '🏃‍♂️',
      shortLabel: isRight ? 'باك يمين' : 'باك شمال',
      category: 'def',
      categoryLabel: 'أطراف الدفاع'
    };
  }

  // 5. خط الوسط (Midfielders)
  // صانع ألعاب (هاف) -> أخضر زمردي إبداعي
  if (p.includes('صانع') || p.includes('هاف') || p.includes('playmaker') || p.includes('cam')) {
    return {
      cardBg: 'bg-gradient-to-r from-emerald-950/45 via-emerald-900/20 to-neutral-950',
      cardBorder: 'border-emerald-500/45 hover:border-emerald-400',
      badgeBg: 'bg-emerald-500/20 border-emerald-500/40 text-emerald-300',
      badgeText: 'text-emerald-300',
      avatarRing: 'ring-2 ring-emerald-500/60',
      indicatorDot: 'bg-emerald-400 shadow-[0_0_8px_rgba(52,211,153,0.9)]',
      glowEffect: 'shadow-emerald-950/30',
      roleIcon: '🎯',
      shortLabel: 'صانع ألعاب (هاف)',
      category: 'mid',
      categoryLabel: 'خط الوسط'
    };
  }

  // خط وسط مدافع (ديفندر) -> تيل / أخضر بترولي قوي
  if (p.includes('ديفندر') || p.includes('cdm') || p.includes('وسط مدافع')) {
    return {
      cardBg: 'bg-gradient-to-r from-teal-950/45 via-teal-900/20 to-neutral-950',
      cardBorder: 'border-teal-500/45 hover:border-teal-400',
      badgeBg: 'bg-teal-500/20 border-teal-500/40 text-teal-300',
      badgeText: 'text-teal-300',
      avatarRing: 'ring-2 ring-teal-500/60',
      indicatorDot: 'bg-teal-400 shadow-[0_0_8px_rgba(45,212,191,0.9)]',
      glowEffect: 'shadow-teal-950/30',
      roleIcon: '⚓',
      shortLabel: 'خط وسط مدافع (ديفندر)',
      category: 'mid',
      categoryLabel: 'خط الوسط'
    };
  }

  // 6. جوكر في أي مركز -> بنفسجي مميز
  if (p.includes('جوكر') || p.includes('أي مركز') || p.includes('utility')) {
    return {
      cardBg: 'bg-gradient-to-r from-purple-950/45 via-purple-900/20 to-neutral-950',
      cardBorder: 'border-purple-500/45 hover:border-purple-400',
      badgeBg: 'bg-purple-500/20 border-purple-500/40 text-purple-300',
      badgeText: 'text-purple-300',
      avatarRing: 'ring-2 ring-purple-500/60',
      indicatorDot: 'bg-purple-400 shadow-[0_0_8px_rgba(192,132,252,0.9)]',
      glowEffect: 'shadow-purple-950/30',
      roleIcon: '🃏',
      shortLabel: 'جوكر في أي مركز',
      category: 'joker',
      categoryLabel: 'جوكر شامل'
    };
  }

  // افتراضي
  return {
    cardBg: 'bg-gradient-to-r from-neutral-900 via-neutral-900 to-neutral-950',
    cardBorder: 'border-neutral-700/60 hover:border-neutral-500',
    badgeBg: 'bg-neutral-800 border-neutral-700 text-neutral-300',
    badgeText: 'text-neutral-300',
    avatarRing: 'ring-1 ring-neutral-600',
    indicatorDot: 'bg-neutral-400',
    glowEffect: 'shadow-neutral-950/30',
    roleIcon: '⚽',
    shortLabel: position,
    category: 'joker',
    categoryLabel: 'لاعب'
  };
};

// قائمة المراكز التوضيحية للاستخدام في شريط التمييز البصري (Legend Bar)
export const POSITION_LEGEND = [
  { key: 'all', label: 'الكل', color: 'bg-neutral-800 text-neutral-200 border-neutral-700' },
  { key: 'gk', label: '🧤 حراسة (أصفر ذهبي)', color: 'bg-amber-500/20 text-amber-300 border-amber-500/40' },
  { key: 'def', label: '🛡️ دفاع (أزرق وسماوي)', color: 'bg-blue-500/20 text-blue-300 border-blue-500/40' },
  { key: 'mid', label: '🎯 وسط (أخضر وتيل)', color: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40' },
  { key: 'att', label: '🔥 هجوم ووينجات (أحمر وبرتقالي)', color: 'bg-rose-500/20 text-rose-300 border-rose-500/40' },
  { key: 'joker', label: '🃏 جوكر (بنفسجي)', color: 'bg-purple-500/20 text-purple-300 border-purple-500/40' },
];
