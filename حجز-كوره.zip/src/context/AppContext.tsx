import React, { createContext, useContext, useState, useEffect } from 'react';
import { 
  User, 
  Group, 
  MatchPost, 
  AppNotification, 
  JoinRequest, 
  ResponseStatus,
  PlayerPosition,
  PlayerRating,
  UserRatingStats
} from '../types';
import { 
  INITIAL_USERS, 
  INITIAL_GROUPS, 
  INITIAL_MATCH_POSTS, 
  INITIAL_NOTIFICATIONS, 
  INITIAL_JOIN_REQUESTS,
  INITIAL_RATINGS
} from '../data/initialData';

interface AppContextType {
  // Current user & auth
  currentUser: User;
  allUsers: User[];
  isLoggedIn: boolean;
  loginWithPhone: (phone: string) => { otp: string };
  verifyOtp: (phone: string, otp: string) => boolean;
  logout: () => void;
  switchUser: (userId: string) => void;
  updateProfile: (updated: Partial<User>) => void;
  getUserById: (userId: string) => User | undefined;
  
  // Selected state & navigation
  selectedGroup: Group | null;
  setSelectedGroup: (group: Group | null) => void;
  activeTab: 'matches' | 'groups' | 'leaderboard' | 'create_match' | 'notifications' | 'profile';
  setActiveTab: (tab: 'matches' | 'groups' | 'leaderboard' | 'create_match' | 'notifications' | 'profile') => void;

  // Groups
  groups: Group[];
  createGroup: (name: string, description: string, isPublic: boolean, avatarUrl?: string) => Group;
  toggleAdminRole: (groupId: string, targetUserId: string) => void;
  joinRequests: JoinRequest[];
  requestToJoinGroup: (groupId: string) => void;
  handleJoinRequest: (requestId: string, approve: boolean) => void;
  isUserGroupAdmin: (groupId: string, userId?: string) => boolean;
  isUserGroupMember: (groupId: string, userId?: string) => boolean;

  // Match posts
  matches: MatchPost[];
  createMatchPost: (data: Omit<MatchPost, 'id' | 'createdAt' | 'isCompleted' | 'responses'>) => MatchPost;
  updateMatchPost: (matchId: string, data: Partial<MatchPost>) => void;
  deleteMatchPost: (matchId: string) => void;
  respondToMatch: (matchId: string, status: ResponseStatus, reason?: string) => { success: boolean; message: string };

  // Notifications
  notifications: AppNotification[];
  markNotificationAsRead: (notificationId: string) => void;
  markAllNotificationsAsRead: () => void;
  activeToast: AppNotification | null;
  clearActiveToast: () => void;

  // Rating system
  ratings: PlayerRating[];
  getUserRatings: (userId: string) => PlayerRating[];
  getUserRatingStats: (userId: string) => UserRatingStats;
  ratePlayer: (rating: {
    matchId: string;
    matchTitle?: string;
    targetUserId: string;
    commitmentRating: number;
    skillRating: number;
    feedbackTag?: string;
    comment?: string;
  }) => { success: boolean; message: string };
  markMatchAsFinished: (matchId: string) => void;
  hasRatedPlayerInMatch: (matchId: string, targetUserId: string) => boolean;

  // Test simulation actions
  simulateWaitlistJump: (matchId: string) => void;
  simulateAlmostFull: (matchId: string) => void;
  simulateCancelRisk: (matchId: string) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Load from localStorage or initial
  const [allUsers, setAllUsers] = useState<User[]>(() => {
    const saved = localStorage.getItem('koretna_users');
    return saved ? JSON.parse(saved) : INITIAL_USERS;
  });

  const [currentUserId, setCurrentUserId] = useState<string>(() => {
    return localStorage.getItem('koretna_current_user_id') || 'user_1';
  });

  const [groups, setGroups] = useState<Group[]>(() => {
    const saved = localStorage.getItem('koretna_groups');
    return saved ? JSON.parse(saved) : INITIAL_GROUPS;
  });

  const [matches, setMatches] = useState<MatchPost[]>(() => {
    const saved = localStorage.getItem('koretna_matches');
    return saved ? JSON.parse(saved) : INITIAL_MATCH_POSTS;
  });

  const [notifications, setNotifications] = useState<AppNotification[]>(() => {
    const saved = localStorage.getItem('koretna_notifications');
    return saved ? JSON.parse(saved) : INITIAL_NOTIFICATIONS;
  });

  const [joinRequests, setJoinRequests] = useState<JoinRequest[]>(() => {
    const saved = localStorage.getItem('koretna_join_requests');
    return saved ? JSON.parse(saved) : INITIAL_JOIN_REQUESTS;
  });

  const [ratings, setRatings] = useState<PlayerRating[]>(() => {
    const saved = localStorage.getItem('koretna_ratings');
    return saved ? JSON.parse(saved) : INITIAL_RATINGS;
  });

  const [selectedGroupId, setSelectedGroupId] = useState<string | null>('group_1');
  const [activeTab, setActiveTab] = useState<'matches' | 'groups' | 'leaderboard' | 'create_match' | 'notifications' | 'profile'>('matches');
  const [activeToast, setActiveToast] = useState<AppNotification | null>(null);

  // Sync state to localStorage
  useEffect(() => {
    localStorage.setItem('koretna_users', JSON.stringify(allUsers));
  }, [allUsers]);

  useEffect(() => {
    localStorage.setItem('koretna_current_user_id', currentUserId);
  }, [currentUserId]);

  useEffect(() => {
    localStorage.setItem('koretna_groups', JSON.stringify(groups));
  }, [groups]);

  useEffect(() => {
    localStorage.setItem('koretna_matches', JSON.stringify(matches));
  }, [matches]);

  useEffect(() => {
    localStorage.setItem('koretna_notifications', JSON.stringify(notifications));
  }, [notifications]);

  useEffect(() => {
    localStorage.setItem('koretna_join_requests', JSON.stringify(joinRequests));
  }, [joinRequests]);

  useEffect(() => {
    localStorage.setItem('koretna_ratings', JSON.stringify(ratings));
  }, [ratings]);

  // Deep-linking from shared URLs & QR scans (?group=..., ?invite=..., ?match=...)
  useEffect(() => {
    if (typeof window !== 'undefined') {
      const searchParams = new URLSearchParams(window.location.search);
      const groupParam = searchParams.get('group');
      const inviteParam = searchParams.get('invite');
      const matchParam = searchParams.get('match');

      if (groupParam) {
        const found = groups.find(g => g.id === groupParam || g.inviteCode.toLowerCase() === groupParam.toLowerCase());
        if (found) {
          setSelectedGroupId(found.id);
          setActiveTab('matches');
        }
      } else if (inviteParam) {
        const found = groups.find(g => g.inviteCode.toLowerCase() === inviteParam.toLowerCase());
        if (found) {
          setSelectedGroupId(found.id);
          setActiveTab('matches');
        }
      }

      if (matchParam) {
        const foundMatch = matches.find(m => m.id === matchParam);
        if (foundMatch) {
          setSelectedGroupId(foundMatch.groupId);
          setActiveTab('matches');
        }
      }
    }
  }, []);

  const currentUser = allUsers.find(u => u.id === currentUserId) || allUsers[0];
  const isLoggedIn = Boolean(currentUser);

  const selectedGroup = groups.find(g => g.id === selectedGroupId) || null;
  const setSelectedGroup = (group: Group | null) => {
    setSelectedGroupId(group ? group.id : null);
  };

  const getUserById = (userId: string) => {
    return allUsers.find(u => u.id === userId);
  };

  const triggerPushNotification = (notif: Omit<AppNotification, 'id' | 'timestamp' | 'read'>) => {
    const newNotif: AppNotification = {
      ...notif,
      id: `notif_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      timestamp: new Date().toISOString(),
      read: false
    };

    setNotifications(prev => [newNotif, ...prev]);
    setActiveToast(newNotif);

    // Auto dismiss toast after 4.5 seconds
    setTimeout(() => {
      setActiveToast(current => current?.id === newNotif.id ? null : current);
    }, 4500);
  };

  // Auth & Profile
  const loginWithPhone = (phone: string) => {
    const otp = '1928'; // Static predictable OTP for effortless testability
    return { otp };
  };

  const verifyOtp = (phone: string, otp: string) => {
    if (otp !== '1928') return false;
    let user = allUsers.find(u => u.phone === phone);
    if (!user) {
      // Create new user if not found
      const newUser: User = {
        id: `user_${Date.now()}`,
        name: `كابتن جديد (${phone.slice(-4)})`,
        phone,
        avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80',
        position: 'جوكر في أي مركز',
        matchesPlayed: 0,
        lateCancellations: 0,
        hidePhone: false
      };
      setAllUsers(prev => [...prev, newUser]);
      setCurrentUserId(newUser.id);
    } else {
      setCurrentUserId(user.id);
    }
    return true;
  };

  const logout = () => {
    // default back to captain
    setCurrentUserId('user_1');
  };

  const switchUser = (userId: string) => {
    setCurrentUserId(userId);
    const user = allUsers.find(u => u.id === userId);
    if (user) {
      triggerPushNotification({
        type: 'match_reminder',
        title: `تم تبديل المستخدم إلى ${user.name} 👤`,
        message: `أنت الآن تتصفح كـ ${user.name} (${user.position}).`
      });
    }
  };

  const updateProfile = (updated: Partial<User>) => {
    setAllUsers(prev => prev.map(u => u.id === currentUserId ? { ...u, ...updated } : u));
    triggerPushNotification({
      type: 'match_reminder',
      title: 'تم تحديث البروفايل بنجاح ✅',
      message: 'تم حفظ تعديلات بياناتك وتفضيلات الخصوصية.'
    });
  };

  // Group permissions
  const isUserGroupAdmin = (groupId: string, userId = currentUserId) => {
    const group = groups.find(g => g.id === groupId);
    if (!group) return false;
    const member = group.members.find(m => m.userId === userId);
    return member?.role === 'creator' || member?.role === 'admin';
  };

  const isUserGroupMember = (groupId: string, userId = currentUserId) => {
    const group = groups.find(g => g.id === groupId);
    return Boolean(group?.members.some(m => m.userId === userId));
  };

  const createGroup = (name: string, description: string, isPublic: boolean, avatarUrl?: string) => {
    const newGroup: Group = {
      id: `group_${Date.now()}`,
      name,
      description,
      avatar: avatarUrl || '/src/assets/images/pitch_night_lights_1790105737855.jpg',
      isPublic,
      creatorId: currentUserId,
      createdAt: new Date().toISOString(),
      inviteCode: `${name.trim().slice(0, 4).toUpperCase()}-${Math.floor(1000 + Math.random() * 9000)}`,
      members: [
        { userId: currentUserId, role: 'creator', joinedAt: new Date().toISOString() }
      ]
    };

    setGroups(prev => [newGroup, ...prev]);
    setSelectedGroupId(newGroup.id);
    
    triggerPushNotification({
      type: 'new_match',
      title: `جروب جديد: ${name} ⚽`,
      message: `تم إنشاء الجروب بنجاح كـ ${isPublic ? 'عام (Public)' : 'خاص (Private)'}. أنت الآن الأدمن الأساسي.`
    });

    return newGroup;
  };

  const toggleAdminRole = (groupId: string, targetUserId: string) => {
    setGroups(prev => prev.map(g => {
      if (g.id !== groupId) return g;
      if (g.creatorId !== currentUserId) {
        alert('فقط منشئ الجروب الأساسي يملك صلاحية تغيير صلاحيات الأدمن');
        return g;
      }
      return {
        ...g,
        members: g.members.map(m => {
          if (m.userId !== targetUserId) return m;
          const newRole = m.role === 'admin' ? 'member' : 'admin';
          return { ...m, role: newRole };
        })
      };
    }));

    const targetUser = getUserById(targetUserId);
    triggerPushNotification({
      type: 'match_reminder',
      title: 'تحديث صلاحيات الأدمن 🛡️',
      message: `تم تحديث صلاحية ${targetUser?.name || 'العضو'} داخل الجروب.`
    });
  };

  const requestToJoinGroup = (groupId: string) => {
    const existingReq = joinRequests.find(r => r.groupId === groupId && r.userId === currentUserId && r.status === 'pending');
    if (existingReq) return;

    const newReq: JoinRequest = {
      id: `req_${Date.now()}`,
      groupId,
      userId: currentUserId,
      requestedAt: new Date().toISOString(),
      status: 'pending'
    };

    setJoinRequests(prev => [newReq, ...prev]);
    const targetGroup = groups.find(g => g.id === groupId);

    triggerPushNotification({
      type: 'match_reminder',
      title: 'تم إرسال طلب الانضمام ⏳',
      message: `طلبك للانضمام إلى جروب "${targetGroup?.name}" في انتظار موافقة الأدمن.`
    });
  };

  const handleJoinRequest = (requestId: string, approve: boolean) => {
    const req = joinRequests.find(r => r.id === requestId);
    if (!req) return;

    setJoinRequests(prev => prev.map(r => r.id === requestId ? { ...r, status: approve ? 'approved' : 'rejected' } : r));

    if (approve) {
      setGroups(prev => prev.map(g => {
        if (g.id !== req.groupId) return g;
        if (g.members.some(m => m.userId === req.userId)) return g;
        return {
          ...g,
          members: [...g.members, { userId: req.userId, role: 'member', joinedAt: new Date().toISOString() }]
        };
      }));

      const user = getUserById(req.userId);
      triggerPushNotification({
        type: 'match_reminder',
        title: 'تمت الموافقة على طلب الانضمام 🎉',
        message: `تم قبول انضمام الكابتن ${user?.name} إلى الجروب بنجاح.`
      });
    }
  };

  // Match management
  const createMatchPost = (data: Omit<MatchPost, 'id' | 'createdAt' | 'isCompleted' | 'responses'>) => {
    const newMatch: MatchPost = {
      ...data,
      id: `match_${Date.now()}`,
      createdAt: new Date().toISOString(),
      isCompleted: false,
      responses: [
        // Creator automatically joins as playing
        { userId: currentUserId, status: 'playing', timestamp: new Date().toISOString() }
      ]
    };

    setMatches(prev => [newMatch, ...prev]);

    triggerPushNotification({
      type: 'new_match',
      title: 'بوست حجز جديد اتعمل في الجروب! 📋⚽',
      message: `${currentUser.name} نزل حجز لماتش في "${data.pitchName}"، العدد المطلوب ${data.requiredPlayers} لاعب.`
    });

    return newMatch;
  };

  const updateMatchPost = (matchId: string, data: Partial<MatchPost>) => {
    setMatches(prev => prev.map(m => m.id === matchId ? { ...m, ...data } : m));
    triggerPushNotification({
      type: 'match_reminder',
      title: 'تم تعديل بوست الحجز ✏️',
      message: 'قام أدمن الجروب بتحديث تفاصيل الحجز.'
    });
  };

  const deleteMatchPost = (matchId: string) => {
    setMatches(prev => prev.filter(m => m.id !== matchId));
    triggerPushNotification({
      type: 'risk_cancellation',
      title: 'تم حذف بوست الحجز 🗑️',
      message: 'قام أدمن الجروب بإلغاء وحذف بوست الماتش.'
    });
  };

  // Responses & Waitlist logic (Specification 4 & 5)
  const respondToMatch = (matchId: string, status: ResponseStatus, reason?: string): { success: boolean; message: string } => {
    const match = matches.find(m => m.id === matchId);
    if (!match) return { success: false, message: 'الماتش مش موجود' };

    // Check deadline
    const deadlineTime = new Date(match.deadlineDateTime).getTime();
    const nowTime = new Date().getTime();
    if (nowTime > deadlineTime) {
      return { success: false, message: 'انتهى آخر ميعاد للرد على هذا الماتش ولا يمكن تغيير الرد حالياً.' };
    }

    let updatedResponses = [...match.responses];
    const existingIndex = updatedResponses.findIndex(r => r.userId === currentUserId);
    const existingResponse = existingIndex >= 0 ? updatedResponses[existingIndex] : null;

    // Current playing count (excluding waitlist)
    const activePlaying = updatedResponses.filter(r => r.status === 'playing' && !r.isWaitlist);
    const waitlistPlaying = updatedResponses.filter(r => r.status === 'playing' && r.isWaitlist).sort((a, b) => (a.waitlistIndex || 0) - (b.waitlistIndex || 0));

    let notificationToTrigger: Omit<AppNotification, 'id' | 'timestamp' | 'read'> | null = null;

    if (status === 'playing') {
      if (existingResponse?.status === 'playing') {
        return { success: true, message: 'أنت مسجل بالفعل في الماتش' };
      }

      // Check if match is already full / completed
      const isAlreadyFull = activePlaying.length >= match.requiredPlayers;

      if (isAlreadyFull) {
        // Enters waitlist automatically!
        const nextWaitlistIndex = waitlistPlaying.length + 1;
        const newResponse = {
          userId: currentUserId,
          status: 'playing' as ResponseStatus,
          timestamp: new Date().toISOString(),
          isWaitlist: true,
          waitlistIndex: nextWaitlistIndex
        };

        if (existingIndex >= 0) {
          updatedResponses[existingIndex] = newResponse;
        } else {
          updatedResponses.push(newResponse);
        }

        notificationToTrigger = {
          type: 'almost_full',
          title: 'العدد مكتمل! دخلت في قائمة الانتظار ⏳',
          message: `أنت الآن رقم (${nextWaitlistIndex}) في قائمة الانتظار (Waitlist). لو حد اعتذر هتدخل مكانه أوتوماتيك!`
        };
      } else {
        // Enters main lineup
        const newResponse = {
          userId: currentUserId,
          status: 'playing' as ResponseStatus,
          timestamp: new Date().toISOString(),
          isWaitlist: false
        };

        if (existingIndex >= 0) {
          updatedResponses[existingIndex] = newResponse;
        } else {
          updatedResponses.push(newResponse);
        }

        // Check if this filled the match!
        const newActiveCount = updatedResponses.filter(r => r.status === 'playing' && !r.isWaitlist).length;
        if (newActiveCount === match.requiredPlayers) {
          notificationToTrigger = {
            type: 'almost_full',
            title: 'اكتمل التشكيل بالكامل! ✅⚽',
            message: `اكتمل العدد المطلوب (${match.requiredPlayers} لاعب) لماتش ${match.pitchName}. أي رد قادم هيدخل قائمة انتظار.`
          };
        } else if (match.requiredPlayers - newActiveCount <= 2) {
          notificationToTrigger = {
            type: 'almost_full',
            title: 'العدد قرّب يكمل! باقي مكانين أو أقل 🔥',
            message: `باقي ${match.requiredPlayers - newActiveCount} لاعب ويكتمل العدد في ماتش ${match.pitchName}.`
          };
        }
      }
    } else if (status === 'declined') {
      // User is apologizing
      const wasActivePlaying = existingResponse?.status === 'playing' && !existingResponse.isWaitlist;

      const newResponse = {
        userId: currentUserId,
        status: 'declined' as ResponseStatus,
        timestamp: new Date().toISOString()
      };

      if (existingIndex >= 0) {
        updatedResponses[existingIndex] = newResponse;
      } else {
        updatedResponses.push(newResponse);
      }

      // If active player apologized and there is a waitlist, promote the 1st waitlist player!
      if (wasActivePlaying && waitlistPlaying.length > 0) {
        const firstInWaitlist = waitlistPlaying[0];
        const firstUser = getUserById(firstInWaitlist.userId);

        updatedResponses = updatedResponses.map(r => {
          if (r.userId === firstInWaitlist.userId) {
            return {
              ...r,
              isWaitlist: false,
              waitlistIndex: undefined
            };
          }
          if (r.isWaitlist && r.waitlistIndex && r.waitlistIndex > 1) {
            return {
              ...r,
              waitlistIndex: r.waitlistIndex - 1
            };
          }
          return r;
        });

        notificationToTrigger = {
          type: 'waitlist_promoted',
          title: 'عضو دخل من الـ Waitlist مكان حد اعتذر! 🚀',
          message: `الكابتن ${firstUser?.name || 'أحد المنتظرين'} دخل التشكيل الأساسي تلقائياً بعد اعتذار ${currentUser.name}.`
        };
      }
    } else if (status === 'uncertain') {
      if (!reason || reason.trim().length === 0) {
        return { success: false, message: 'لازم تكتب سبب عدم التأكد يا كابتن' };
      }

      const wasActivePlaying = existingResponse?.status === 'playing' && !existingResponse.isWaitlist;

      const newResponse = {
        userId: currentUserId,
        status: 'uncertain' as ResponseStatus,
        uncertainReason: reason.trim(),
        timestamp: new Date().toISOString()
      };

      if (existingIndex >= 0) {
        updatedResponses[existingIndex] = newResponse;
      } else {
        updatedResponses.push(newResponse);
      }

      // If they were active playing, promote waitlist
      if (wasActivePlaying && waitlistPlaying.length > 0) {
        const firstInWaitlist = waitlistPlaying[0];
        const firstUser = getUserById(firstInWaitlist.userId);

        updatedResponses = updatedResponses.map(r => {
          if (r.userId === firstInWaitlist.userId) {
            return {
              ...r,
              isWaitlist: false,
              waitlistIndex: undefined
            };
          }
          if (r.isWaitlist && r.waitlistIndex && r.waitlistIndex > 1) {
            return {
              ...r,
              waitlistIndex: r.waitlistIndex - 1
            };
          }
          return r;
        });

        notificationToTrigger = {
          type: 'waitlist_promoted',
          title: 'عضو دخل من الـ Waitlist تلقائياً ⚡',
          message: `${firstUser?.name || 'أحد المنتظرين'} دخل التشكيل الأساسي لأن ${currentUser.name} مش متأكد.`
        };
      }
    }

    // Determine isCompleted
    const finalActivePlaying = updatedResponses.filter(r => r.status === 'playing' && !r.isWaitlist).length;
    const isCompleted = finalActivePlaying >= match.requiredPlayers;

    setMatches(prev => prev.map(m => m.id === matchId ? {
      ...m,
      isCompleted,
      responses: updatedResponses
    } : m));

    if (notificationToTrigger) {
      triggerPushNotification(notificationToTrigger);
    }

    return { success: true, message: 'تم تسجيل ردك بنجاح' };
  };

  // Test simulation helper: Simulate player apology & waitlist promotion
  const simulateWaitlistJump = (matchId: string) => {
    const match = matches.find(m => m.id === matchId);
    if (!match) return;

    const activePlayers = match.responses.filter(r => r.status === 'playing' && !r.isWaitlist);
    const waitlistPlayers = match.responses.filter(r => r.status === 'playing' && r.isWaitlist).sort((a, b) => (a.waitlistIndex || 0) - (b.waitlistIndex || 0));

    if (activePlayers.length === 0) {
      alert('مفيش لاعبين أساسيين في الماتش للاعتذار');
      return;
    }

    if (waitlistPlayers.length === 0) {
      alert('مفيش لاعبين في قائمة الانتظار (Waitlist) للترقية حالياً');
      return;
    }

    const apologizingPlayer = activePlayers[activePlayers.length - 1];
    const apologizingUser = getUserById(apologizingPlayer.userId);
    const promotedPlayer = waitlistPlayers[0];
    const promotedUser = getUserById(promotedPlayer.userId);

    const updated = match.responses.map(r => {
      if (r.userId === apologizingPlayer.userId) {
        return { ...r, status: 'declined' as ResponseStatus, isWaitlist: false, waitlistIndex: undefined };
      }
      if (r.userId === promotedPlayer.userId) {
        return { ...r, isWaitlist: false, waitlistIndex: undefined };
      }
      if (r.isWaitlist && r.waitlistIndex && r.waitlistIndex > 1) {
        return { ...r, waitlistIndex: r.waitlistIndex - 1 };
      }
      return r;
    });

    setMatches(prev => prev.map(m => m.id === matchId ? { ...m, responses: updated } : m));

    triggerPushNotification({
      type: 'waitlist_promoted',
      title: 'عضو دخل من الـ Waitlist مكان حد اعتذر! ⚡',
      message: `اعتذر الكابتن ${apologizingUser?.name}، وتم تصعيد ${promotedUser?.name} تلقائياً من الـ Waitlist ليصبح في التشكيل الأساسي.`
    });
  };

  const simulateAlmostFull = (matchId: string) => {
    const match = matches.find(m => m.id === matchId);
    if (!match) return;
    triggerPushNotification({
      type: 'almost_full',
      title: 'العدد قرّب يكمل (باقي مكان واحد بس)! 🔥',
      message: `تنبيه: ماتش ${match.pitchName} محتاج لاعب واحد فقط ويقفل البوست ويكتمل.`
    });
  };

  const simulateCancelRisk = (matchId: string) => {
    const match = matches.find(m => m.id === matchId);
    if (!match) return;
    triggerPushNotification({
      type: 'risk_cancellation',
      title: 'تنبيه: الماتش مهدد بالإلغاء! ⚠️',
      message: `وصلنا لآخر ميعاد للرد على ماتش "${match.pitchName}" والعدد لسه منكملش. يرجى التنسيق فوراً يا شباب.`
    });
  };

  const markNotificationAsRead = (id: string) => {
    setNotifications(prev => prev.map(n => n.id === id ? { ...n, read: true } : n));
  };

  const markAllNotificationsAsRead = () => {
    setNotifications(prev => prev.map(n => ({ ...n, read: true })));
  };

  // Rating methods
  const getUserRatings = (userId: string): PlayerRating[] => {
    return ratings
      .filter(r => r.targetUserId === userId)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  };

  const getUserRatingStats = (userId: string): UserRatingStats => {
    const userRatings = ratings.filter(r => r.targetUserId === userId);
    const user = allUsers.find(u => u.id === userId);

    if (userRatings.length === 0) {
      if (user?.ratingStats) {
        return user.ratingStats;
      }
      return {
        averageOverall: 5.0,
        averageCommitment: 5.0,
        averageSkill: 5.0,
        totalRatingsCount: 0
      };
    }

    const sumCommitment = userRatings.reduce((acc, curr) => acc + curr.commitmentRating, 0);
    const sumSkill = userRatings.reduce((acc, curr) => acc + curr.skillRating, 0);
    const count = userRatings.length;

    const avgCommitment = Math.round((sumCommitment / count) * 10) / 10;
    const avgSkill = Math.round((sumSkill / count) * 10) / 10;
    const avgOverall = Math.round(((avgCommitment + avgSkill) / 2) * 10) / 10;

    return {
      averageOverall: avgOverall,
      averageCommitment: avgCommitment,
      averageSkill: avgSkill,
      totalRatingsCount: count
    };
  };

  const hasRatedPlayerInMatch = (matchId: string, targetUserId: string): boolean => {
    return ratings.some(r => r.matchId === matchId && r.targetUserId === targetUserId && r.raterUserId === currentUserId);
  };

  const ratePlayer = (data: {
    matchId: string;
    matchTitle?: string;
    targetUserId: string;
    commitmentRating: number;
    skillRating: number;
    feedbackTag?: string;
    comment?: string;
  }): { success: boolean; message: string } => {
    if (data.targetUserId === currentUserId) {
      return { success: false, message: 'متقدرش تقيم نفسك يا كابتن!' };
    }

    const existingIndex = ratings.findIndex(
      r => r.matchId === data.matchId && r.targetUserId === data.targetUserId && r.raterUserId === currentUserId
    );

    const newRating: PlayerRating = {
      id: existingIndex >= 0 ? ratings[existingIndex].id : `rate_${Date.now()}`,
      matchId: data.matchId,
      matchTitle: data.matchTitle,
      raterUserId: currentUserId,
      raterName: currentUser.name,
      targetUserId: data.targetUserId,
      commitmentRating: data.commitmentRating,
      skillRating: data.skillRating,
      feedbackTag: data.feedbackTag,
      comment: data.comment,
      createdAt: new Date().toISOString()
    };

    let updatedRatings: PlayerRating[];
    if (existingIndex >= 0) {
      updatedRatings = [...ratings];
      updatedRatings[existingIndex] = newRating;
    } else {
      updatedRatings = [newRating, ...ratings];
    }

    setRatings(updatedRatings);

    // Update target user stats
    const targetUserRatings = updatedRatings.filter(r => r.targetUserId === data.targetUserId);
    const sumCommitment = targetUserRatings.reduce((acc, curr) => acc + curr.commitmentRating, 0);
    const sumSkill = targetUserRatings.reduce((acc, curr) => acc + curr.skillRating, 0);
    const count = targetUserRatings.length;
    const avgCommitment = Math.round((sumCommitment / count) * 10) / 10;
    const avgSkill = Math.round((sumSkill / count) * 10) / 10;
    const avgOverall = Math.round(((avgCommitment + avgSkill) / 2) * 10) / 10;

    const newStats: UserRatingStats = {
      averageOverall: avgOverall,
      averageCommitment: avgCommitment,
      averageSkill: avgSkill,
      totalRatingsCount: count
    };

    setAllUsers(prev => prev.map(u => u.id === data.targetUserId ? { ...u, ratingStats: newStats } : u));

    const targetUser = allUsers.find(u => u.id === data.targetUserId);
    triggerPushNotification({
      type: 'member_rated',
      title: `تم حفظ تقييمك للكابتن ${targetUser?.name || 'اللاعب'} ⭐`,
      message: `الالتزام: ${data.commitmentRating}/5 • المستوى: ${data.skillRating}/5 - شكراً لمساهمتك في تقييم أصحابك!`
    });

    return { success: true, message: 'تم حفظ التقييم بنجاح' };
  };

  const markMatchAsFinished = (matchId: string) => {
    setMatches(prev => prev.map(m => m.id === matchId ? { ...m, isFinished: true, isCompleted: true } : m));
    const match = matches.find(m => m.id === matchId);
    triggerPushNotification({
      type: 'match_finished',
      title: 'انتهى الماتش! قيّم زمايلك في الملعب 🏆⭐',
      message: `انتهى ماتش "${match?.pitchName || 'الكورة'}". ادخل قيّم التزام ومستوى اللعيبة دلوقتي!`
    });
  };

  return (
    <AppContext.Provider
      value={{
        currentUser,
        allUsers,
        isLoggedIn,
        loginWithPhone,
        verifyOtp,
        logout,
        switchUser,
        updateProfile,
        getUserById,
        selectedGroup,
        setSelectedGroup,
        activeTab,
        setActiveTab,
        groups,
        createGroup,
        toggleAdminRole,
        joinRequests,
        requestToJoinGroup,
        handleJoinRequest,
        isUserGroupAdmin,
        isUserGroupMember,
        matches,
        createMatchPost,
        updateMatchPost,
        deleteMatchPost,
        respondToMatch,
        notifications,
        markNotificationAsRead,
        markAllNotificationsAsRead,
        activeToast,
        clearActiveToast: () => setActiveToast(null),
        ratings,
        getUserRatings,
        getUserRatingStats,
        ratePlayer,
        markMatchAsFinished,
        hasRatedPlayerInMatch,
        simulateWaitlistJump,
        simulateAlmostFull,
        simulateCancelRisk
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
