export type PlayerPosition = 
  | 'جون كيبر (حارس مرمى)'
  | 'مساك (قلب دفاع)'
  | 'باك يمين'
  | 'باك شمال'
  | 'خط وسط مدافع (ديفندر)'
  | 'صانع ألعاب (هاف)'
  | 'وينج يمين'
  | 'وينج شمال'
  | 'مهاجم (رأس حربة)'
  | 'جوكر في أي مركز';

export interface PlayerRating {
  id: string;
  matchId: string;
  matchTitle?: string;
  raterUserId: string;
  raterName: string;
  targetUserId: string;
  commitmentRating: number; // 1 to 5 (الالتزام بالمواعيد والروح الرياضية)
  skillRating: number;      // 1 to 5 (المستوى الكروي والمهارة)
  feedbackTag?: string;     // e.g. "حريف جداً", "ملتزم بالميعاد", "روح رياضية"
  comment?: string;         // optional custom note
  createdAt: string;
}

export interface UserRatingStats {
  averageOverall: number;    // e.g. 4.8
  averageCommitment: number; // e.g. 4.9
  averageSkill: number;      // e.g. 4.7
  totalRatingsCount: number;
}

export interface User {
  id: string;
  name: string;
  phone: string;
  avatar: string;
  position: PlayerPosition;
  matchesPlayed: number;
  lateCancellations: number;
  hidePhone: boolean;
  bio?: string;
  ratingStats?: UserRatingStats;
}

export type ResponseStatus = 'playing' | 'declined' | 'uncertain';

export interface MatchResponse {
  userId: string;
  status: ResponseStatus;
  uncertainReason?: string;
  timestamp: string; // ISO string
  isWaitlist?: boolean;
  waitlistIndex?: number; // 1, 2, ...
}

export interface MatchPost {
  id: string;
  groupId: string;
  creatorId: string;
  creatorName: string;
  creatorAvatar: string;
  createdAt: string;
  // Match info
  pitchName: string;
  pitchLocationText: string;
  matchDateTime: string; // e.g., '2026-09-24T20:00:00'
  requiredPlayers: number; // e.g., 10 or 12
  hourlyRate: number; // e.g., 350 EGP
  durationHours: number; // e.g., 1.5 or 2
  totalCost: number; // calculated: hourlyRate * durationHours
  notes: string;
  deadlineDateTime: string; // "آخر ميعاد للرد"
  // Status
  isCompleted: boolean; // "اكتمل ✅"
  isFinished?: boolean; // "انتهى الماتش 🏁"
  isAtRiskNoticeSent?: boolean;
  responses: MatchResponse[];
}

export interface GroupMember {
  userId: string;
  role: 'creator' | 'admin' | 'member';
  joinedAt: string;
}

export interface JoinRequest {
  id: string;
  groupId: string;
  userId: string;
  requestedAt: string;
  status: 'pending' | 'approved' | 'rejected';
}

export interface Group {
  id: string;
  name: string;
  description: string;
  avatar: string;
  isPublic: boolean; // Public (shows in explore) or Private (invite only)
  creatorId: string;
  createdAt: string;
  members: GroupMember[];
  inviteCode: string;
}

export type NotificationType = 
  | 'new_match'
  | 'waitlist_promoted'
  | 'match_reminder'
  | 'almost_full'
  | 'risk_cancellation'
  | 'member_rated'
  | 'match_finished';

export interface AppNotification {
  id: string;
  type: NotificationType;
  title: string;
  message: string;
  matchId?: string;
  groupId?: string;
  timestamp: string;
  read: boolean;
}
