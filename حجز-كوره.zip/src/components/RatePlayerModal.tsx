import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Star, X, Check, ShieldCheck, ThumbsUp, MessageSquare, Award } from 'lucide-react';

interface RatePlayerModalProps {
  matchId: string;
  matchTitle?: string;
  targetUserId?: string; // If provided, rates this specific player directly
  participantUserIds?: string[]; // If provided, shows roster to rate
  onClose: () => void;
  onRatedSuccess?: () => void;
}

const COMMITMENT_LABELS: Record<number, string> = {
  1: 'اعتذر متأخر / مجاش في الميعاد',
  2: 'اتأخر ومقصر في الالتزام',
  3: 'حضور مقبول ومستوى التزام عادي',
  4: 'ملتزم بالميعاد واللعب بروح طيبة',
  5: 'قدوة في الالتزام بالمواعيد والروح العالية ⭐'
};

const SKILL_LABELS: Record<number, string> = {
  1: 'مبتدئ ومحتاج تمرين',
  2: 'متوسط الأداء',
  3: 'كويس وبيلعب كورة نضيفة',
  4: 'حريف وتأثيره واضح في الملعب',
  5: 'نجم الماتش وأداء استثنائي ⚽🔥'
};

const SUGGESTED_TAGS = [
  'حريف جداً ⚽',
  'ملتزم بالدقيقة ⏱️',
  'روح رياضية عالية 🤝',
  'صانع ألعاب 🎩',
  'حارس سد منيع 🧤',
  'دفاع حديدي 🛡️',
  'فينشر قدام الجون 🎯',
  'لياقة ونشاط عالي ⚡'
];

export const RatePlayerModal: React.FC<RatePlayerModalProps> = ({
  matchId,
  matchTitle,
  targetUserId: initialTargetUserId,
  participantUserIds,
  onClose,
  onRatedSuccess
}) => {
  const { 
    currentUser, 
    getUserById, 
    ratePlayer, 
    hasRatedPlayerInMatch, 
    getUserRatings, 
    getUserRatingStats 
  } = useApp();

  // If a list of participants is provided, filter out current user
  const ratableParticipants = (participantUserIds || [])
    .filter(id => id !== currentUser.id)
    .map(id => getUserById(id))
    .filter((u): u is NonNullable<typeof u> => Boolean(u));

  // Current selected player to rate
  const [selectedUserId, setSelectedUserId] = useState<string>(() => {
    if (initialTargetUserId && initialTargetUserId !== currentUser.id) {
      return initialTargetUserId;
    }
    return ratableParticipants[0]?.id || '';
  });

  const targetUser = getUserById(selectedUserId);

  // Form states
  const [commitmentRating, setCommitmentRating] = useState<number>(5);
  const [skillRating, setSkillRating] = useState<number>(5);
  const [selectedTag, setSelectedTag] = useState<string>('حريف جداً ⚽');
  const [comment, setComment] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [successFeedback, setSuccessFeedback] = useState<string | null>(null);

  // Check if current user already rated this target player for this match
  const alreadyRated = selectedUserId ? hasRatedPlayerInMatch(matchId, selectedUserId) : false;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedUserId || selectedUserId === currentUser.id) return;

    setIsSubmitting(true);
    const res = ratePlayer({
      matchId,
      matchTitle: matchTitle || 'ماتش كورة',
      targetUserId: selectedUserId,
      commitmentRating,
      skillRating,
      feedbackTag: selectedTag,
      comment: comment.trim() || undefined
    });

    setIsSubmitting(false);

    if (res.success) {
      setSuccessFeedback(`تم حفظ تقييمك للكابتن ${targetUser?.name || ''} بنجاح! ⭐`);
      setTimeout(() => {
        setSuccessFeedback(null);
        if (onRatedSuccess) onRatedSuccess();
        // If there's another unrated player in the roster, switch to them, else close after brief delay
        const nextUnrated = ratableParticipants.find(p => p.id !== selectedUserId && !hasRatedPlayerInMatch(matchId, p.id));
        if (nextUnrated) {
          setSelectedUserId(nextUnrated.id);
          setCommitmentRating(5);
          setSkillRating(5);
          setComment('');
        } else {
          onClose();
        }
      }, 1200);
    }
  };

  // Helper for interactive stars
  const renderInteractiveStars = (
    value: number,
    onChange: (val: number) => void,
    colorClass: string
  ) => {
    return (
      <div className="flex items-center gap-1.5 justify-center py-1">
        {[1, 2, 3, 4, 5].map((star) => (
          <button
            key={star}
            type="button"
            onClick={() => onChange(star)}
            className="p-1 min-w-[40px] min-h-[40px] flex items-center justify-center transition-transform active:scale-125 focus:outline-none"
            aria-label={`${star} من 5 نجوم`}
          >
            <Star
              className={`w-7 h-7 transition-colors ${
                star <= value
                  ? `${colorClass} fill-current drop-shadow-[0_0_8px_rgba(250,204,21,0.4)]`
                  : 'text-neutral-700 stroke-[1.5]'
              }`}
            />
          </button>
        ))}
      </div>
    );
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4 animate-in fade-in duration-200">
      <div className="w-full max-w-md bg-neutral-900 border border-neutral-800 rounded-t-3xl sm:rounded-3xl overflow-hidden shadow-2xl max-h-[92vh] flex flex-col">
        {/* Header */}
        <div className="p-4 pb-3 flex items-center justify-between border-b border-neutral-800 bg-neutral-900/90">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center">
              <Award className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white">تقييم الكباتن بعد الماتش ⭐</h3>
              <p className="text-[10px] text-neutral-400">
                {matchTitle ? `ماتش ${matchTitle}` : 'تقييم الالتزام والمستوى'}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full flex items-center justify-center bg-neutral-800 hover:bg-neutral-700 text-neutral-400 hover:text-white transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-4 overflow-y-auto space-y-4">
          {/* If participant list provided, show horizontal player carousel picker */}
          {ratableParticipants.length > 1 && (
            <div>
              <span className="text-[11px] font-semibold text-neutral-400 block mb-1.5">
                اختر اللاعب اللي عايز تقيمه من الماتش:
              </span>
              <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
                {ratableParticipants.map((player) => {
                  const isSelected = player.id === selectedUserId;
                  const isRated = hasRatedPlayerInMatch(matchId, player.id);
                  const playerStats = getUserRatingStats(player.id);

                  return (
                    <button
                      key={player.id}
                      onClick={() => {
                        setSelectedUserId(player.id);
                        setSuccessFeedback(null);
                      }}
                      className={`relative flex flex-col items-center p-2 rounded-2xl border transition-all shrink-0 min-w-[76px] ${
                        isSelected
                          ? 'bg-neutral-800 border-amber-500/80 shadow-md shadow-amber-500/10'
                          : 'bg-neutral-950/70 border-neutral-800 hover:border-neutral-700'
                      }`}
                    >
                      <div className="relative">
                        <img
                          src={player.avatar}
                          alt={player.name}
                          className="w-10 h-10 rounded-full object-cover border border-neutral-700"
                          referrerPolicy="no-referrer"
                        />
                        {isRated && (
                          <span className="absolute -bottom-1 -right-1 w-4 h-4 rounded-full bg-emerald-500 text-white flex items-center justify-center text-[10px] font-bold">
                            ✓
                          </span>
                        )}
                      </div>
                      <span className="text-[11px] font-bold text-white mt-1 truncate max-w-[70px]">
                        {player.name.split(' ')[0]}
                      </span>
                      <span className="text-[9px] text-amber-400 font-semibold flex items-center gap-0.5">
                        <Star className="w-2.5 h-2.5 fill-current" />
                        <span>{playerStats.averageOverall}</span>
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Selected Player Identity Card */}
          {targetUser ? (
            <div className="p-3 rounded-2xl bg-neutral-950 border border-neutral-800 flex items-center gap-3">
              <img
                src={targetUser.avatar}
                alt={targetUser.name}
                className="w-12 h-12 rounded-2xl object-cover border border-neutral-700 ring-2 ring-emerald-500/20 shrink-0"
                referrerPolicy="no-referrer"
              />
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between">
                  <h4 className="text-sm font-bold text-white truncate">{targetUser.name}</h4>
                  {alreadyRated && (
                    <span className="px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 text-[10px] font-bold">
                      تم تقييمه سابقاً ✓
                    </span>
                  )}
                </div>
                <div className="flex items-center gap-2 mt-0.5 text-xs text-neutral-400">
                  <span className="text-emerald-400 font-semibold flex items-center gap-1">
                    <ShieldCheck className="w-3 h-3" />
                    {targetUser.position.split(' ')[0]}
                  </span>
                  <span>•</span>
                  <span>{targetUser.matchesPlayed} ماتش</span>
                </div>
              </div>
            </div>
          ) : (
            <p className="text-xs text-neutral-500 text-center py-4">اختر لاعباً لتقييمه</p>
          )}

          {/* Success Banner */}
          {successFeedback && (
            <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs flex items-center gap-2 animate-in zoom-in-95 duration-150">
              <Check className="w-4 h-4 shrink-0 text-emerald-400" />
              <span>{successFeedback}</span>
            </div>
          )}

          {targetUser && (
            <form onSubmit={handleSubmit} className="space-y-4">
              {/* ========================================================================= */}
              {/* 1. تقييم الالتزام (Commitment) */}
              {/* ========================================================================= */}
              <div className="p-3.5 rounded-2xl bg-neutral-950/90 border border-neutral-800 space-y-1.5 text-center">
                <div className="flex items-center justify-between px-1">
                  <span className="text-xs font-bold text-neutral-200">
                    1. الالتزام بالمواعيد والروح الرياضية ⏱️🤝
                  </span>
                  <span className="text-xs font-mono font-bold text-amber-400">
                    {commitmentRating} / 5
                  </span>
                </div>

                {renderInteractiveStars(
                  commitmentRating,
                  setCommitmentRating,
                  'text-amber-400'
                )}

                <div className="text-[11px] text-amber-300 font-medium px-2 py-1 rounded-lg bg-neutral-900 border border-neutral-800">
                  {COMMITMENT_LABELS[commitmentRating]}
                </div>
              </div>

              {/* ========================================================================= */}
              {/* 2. تقييم المستوى (Skill Level) */}
              {/* ========================================================================= */}
              <div className="p-3.5 rounded-2xl bg-neutral-950/90 border border-neutral-800 space-y-1.5 text-center">
                <div className="flex items-center justify-between px-1">
                  <span className="text-xs font-bold text-neutral-200">
                    2. المستوى الكروي والمهارة في الملعب ⚽⚡
                  </span>
                  <span className="text-xs font-mono font-bold text-emerald-400">
                    {skillRating} / 5
                  </span>
                </div>

                {renderInteractiveStars(
                  skillRating,
                  setSkillRating,
                  'text-emerald-400'
                )}

                <div className="text-[11px] text-emerald-300 font-medium px-2 py-1 rounded-lg bg-neutral-900 border border-neutral-800">
                  {SKILL_LABELS[skillRating]}
                </div>
              </div>

              {/* ========================================================================= */}
              {/* 3. شارة سريعة أو وسام تميز */}
              {/* ========================================================================= */}
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-neutral-300 flex items-center gap-1.5">
                  <ThumbsUp className="w-3.5 h-3.5 text-neutral-400" />
                  <span>كلمة حق أو ميزة تميز بها في الماتش:</span>
                </label>
                <div className="flex flex-wrap gap-1.5">
                  {SUGGESTED_TAGS.map((tag) => (
                    <button
                      key={tag}
                      type="button"
                      onClick={() => setSelectedTag(tag === selectedTag ? '' : tag)}
                      className={`text-xs px-2.5 py-1.5 rounded-xl border transition-colors ${
                        selectedTag === tag
                          ? 'bg-amber-500/20 text-amber-300 border-amber-500/40 font-bold'
                          : 'bg-neutral-950 text-neutral-400 border-neutral-800 hover:text-neutral-200'
                      }`}
                    >
                      {tag}
                    </button>
                  ))}
                </div>
              </div>

              {/* ========================================================================= */}
              {/* 4. ملاحظة أو تعليق اختياري */}
              {/* ========================================================================= */}
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-neutral-300 flex items-center gap-1.5">
                  <MessageSquare className="w-3.5 h-3.5 text-neutral-400" />
                  <span>كلمة تشجيع للكابتن (اختياري):</span>
                </label>
                <input
                  type="text"
                  value={comment}
                  onChange={(e) => setComment(e.target.value)}
                  placeholder="مثلاً: باص ممتاز ولعب برجولة لآخر دقيقة..."
                  className="w-full bg-neutral-950 border border-neutral-800 focus:border-amber-500 rounded-xl px-3 py-2 text-xs text-white placeholder-neutral-500 outline-none"
                />
              </div>

              {/* Submit Button */}
              <div className="pt-2">
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full min-h-[46px] rounded-xl bg-amber-600 hover:bg-amber-500 active:scale-[0.98] text-white font-bold text-xs shadow-lg shadow-amber-950 transition-all flex items-center justify-center gap-1.5 disabled:opacity-50"
                >
                  <Star className="w-4 h-4 fill-current" />
                  <span>{alreadyRated ? 'تحديث التقييم الحالي ⭐' : 'تأكيد وحفظ التقييم ⭐'}</span>
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
