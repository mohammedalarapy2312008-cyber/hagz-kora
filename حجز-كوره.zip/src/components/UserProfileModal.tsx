import React, { useState } from 'react';
import { User, PlayerPosition } from '../types';
import { useApp } from '../context/AppContext';
import { 
  X, 
  Phone, 
  EyeOff, 
  Trophy, 
  AlertTriangle, 
  Edit3, 
  Check, 
  MessageCircle, 
  PhoneCall, 
  ShieldCheck,
  Flame,
  Star,
  Award,
  Sparkles
} from 'lucide-react';
import { RatePlayerModal } from './RatePlayerModal';
import { getPlayerTier } from './LeaderboardView';

interface UserProfileModalProps {
  userId: string | null;
  onClose: () => void;
}

const POSITIONS: PlayerPosition[] = [
  'جون كيبر (حارس مرمى)',
  'مساك (قلب دفاع)',
  'باك يمين',
  'باك شمال',
  'خط وسط مدافع (ديفندر)',
  'صانع ألعاب (هاف)',
  'وينج يمين',
  'وينج شمال',
  'مهاجم (رأس حربة)',
  'جوكر في أي مركز'
];

export const UserProfileModal: React.FC<UserProfileModalProps> = ({ userId, onClose }) => {
  const { currentUser, getUserById, updateProfile, getUserRatingStats, getUserRatings } = useApp();

  const user = userId ? getUserById(userId) : currentUser;
  const isMe = user?.id === currentUser.id;

  const [isEditing, setIsEditing] = useState(false);
  const [showRateModal, setShowRateModal] = useState(false);
  const [nameInput, setNameInput] = useState(user?.name || '');
  const [positionInput, setPositionInput] = useState<PlayerPosition>(user?.position || 'جوكر في أي مركز');
  const [hidePhoneInput, setHidePhoneInput] = useState(user?.hidePhone ?? false);
  const [bioInput, setBioInput] = useState(user?.bio || '');

  if (!user) return null;

  const ratingStats = getUserRatingStats(user.id);
  const userRatings = getUserRatings(user.id);

  const handleSave = () => {
    updateProfile({
      name: nameInput.trim() || user.name,
      position: positionInput,
      hidePhone: hidePhoneInput,
      bio: bioInput.trim()
    });
    setIsEditing(false);
  };

  // Late cancellation badge color
  const getLateCancellationSeverity = (count: number) => {
    if (count === 0) return { label: 'ملتزم جداً بالمواعيد ⭐', color: 'text-emerald-400 bg-emerald-500/10 border-emerald-500/20' };
    if (count <= 2) return { label: 'تنبيه خفيف ⚠️', color: 'text-amber-400 bg-amber-500/10 border-amber-500/20' };
    return { label: 'متكرر الاعتذار المتأخر 🚨', color: 'text-rose-400 bg-rose-500/10 border-rose-500/20' };
  };

  const cancellationStatus = getLateCancellationSeverity(user.lateCancellations);

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4 animate-in fade-in duration-200">
      <div className="w-full max-w-md bg-neutral-900 border border-neutral-800 rounded-t-3xl sm:rounded-3xl overflow-hidden shadow-2xl max-h-[90vh] flex flex-col">
        {/* Header Bar */}
        <div className="relative p-4 pb-2 flex items-center justify-between border-b border-neutral-800">
          <div className="flex items-center gap-2">
            <span className="font-display font-bold text-sm text-neutral-200">
              {isMe ? 'بروفايلي وإعداداتي' : 'بروفايل الكابتن'}
            </span>
          </div>

          <div className="flex items-center gap-1">
            {isMe && !isEditing && (
              <button
                onClick={() => setIsEditing(true)}
                className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-xs font-semibold text-emerald-400 border border-neutral-700 transition-colors"
              >
                <Edit3 className="w-3.5 h-3.5" />
                <span>تعديل</span>
              </button>
            )}
            <button
              onClick={onClose}
              className="w-8 h-8 rounded-full flex items-center justify-center bg-neutral-800 hover:bg-neutral-700 text-neutral-400 hover:text-white transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Content Body */}
        <div className="p-4 overflow-y-auto space-y-4">
          {/* User Avatar + Main Info */}
          <div className="flex items-center gap-3.5">
            <div className="relative">
              <div className="w-16 h-16 rounded-2xl overflow-hidden ring-2 ring-emerald-500/40 border border-neutral-700 shadow-md">
                <img
                  src={user.avatar}
                  alt={user.name}
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
              </div>
            </div>

            <div className="flex-1 min-w-0">
              {isEditing ? (
                <div className="space-y-2">
                  <input
                    type="text"
                    value={nameInput}
                    onChange={(e) => setNameInput(e.target.value)}
                    placeholder="اسمك في الكورة"
                    className="w-full bg-neutral-950 border border-neutral-700 focus:border-emerald-500 rounded-lg px-2.5 py-1.5 text-xs text-white outline-none"
                  />
                  <select
                    value={positionInput}
                    onChange={(e) => setPositionInput(e.target.value as PlayerPosition)}
                    className="w-full bg-neutral-950 border border-neutral-700 focus:border-emerald-500 rounded-lg px-2 py-1.5 text-xs text-white outline-none"
                  >
                    {POSITIONS.map(p => (
                      <option key={p} value={p}>{p}</option>
                    ))}
                  </select>
                </div>
              ) : (
                <div>
                  <h3 className="text-base font-bold text-white truncate">{user.name}</h3>
                  <div className="inline-flex items-center gap-1 mt-0.5 text-xs font-semibold text-emerald-400">
                    <ShieldCheck className="w-3.5 h-3.5" />
                    <span>{user.position}</span>
                  </div>
                  {user.bio && (
                    <p className="text-[11px] text-neutral-400 mt-1 line-clamp-2">
                      "{user.bio}"
                    </p>
                  )}
                </div>
              )}
            </div>
          </div>

          {/* ========================================================================= */}
          {/* إحصائيات اللاعب (Specification 1: عدد الماتشات + عدد مرات الاعتذار المتأخر) */}
          {/* ========================================================================= */}
          <div className="rounded-2xl p-3 bg-neutral-950/80 border border-neutral-800 space-y-2">
            <div className="text-[11px] font-bold text-neutral-300 flex items-center justify-between">
              <span>إحصائيات وسجل الالتزام 📊</span>
              <span className={`text-[10px] px-2 py-0.5 rounded border ${cancellationStatus.color}`}>
                {cancellationStatus.label}
              </span>
            </div>

            <div className="grid grid-cols-3 gap-2 pt-1">
              {/* Stat 1: Matches Played */}
              <div className="p-2.5 rounded-xl bg-neutral-900 border border-neutral-800 text-center">
                <div className="w-6 h-6 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto mb-1">
                  <Trophy className="w-3.5 h-3.5" />
                </div>
                <div className="text-lg font-black font-display text-white">
                  {user.matchesPlayed}
                </div>
                <span className="text-[10px] text-neutral-400">ماتش ملعوب</span>
              </div>

              {/* Stat 2: Total Points */}
              {(() => {
                const bonus = Math.min((ratingStats.totalRatingsCount || 0) * 5, 50);
                const pts = Math.max(0, Math.round((user.matchesPlayed * 15) + (ratingStats.averageOverall * 50) + bonus - (user.lateCancellations * 30)));
                const tier = getPlayerTier(pts);
                return (
                  <div className="p-2.5 rounded-xl bg-neutral-900 border border-amber-500/30 text-center">
                    <div className="w-6 h-6 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center mx-auto mb-1 text-xs">
                      {tier.badge}
                    </div>
                    <div className="text-lg font-black font-display text-amber-400 font-mono">
                      {pts}
                    </div>
                    <span className="text-[10px] text-amber-300/90 font-medium">نقطة تصنيف</span>
                  </div>
                );
              })()}

              {/* Stat 3: Late Cancellations */}
              <div className="p-2.5 rounded-xl bg-neutral-900 border border-neutral-800 text-center">
                <div className={`w-6 h-6 rounded-lg flex items-center justify-center mx-auto mb-1 ${
                  user.lateCancellations > 0 ? 'bg-rose-500/20 text-rose-400' : 'bg-emerald-500/20 text-emerald-400'
                }`}>
                  <AlertTriangle className="w-3.5 h-3.5" />
                </div>
                <div className={`text-lg font-black font-display ${
                  user.lateCancellations > 0 ? 'text-rose-400' : 'text-emerald-400'
                }`}>
                  {user.lateCancellations}
                </div>
                <span className="text-[10px] text-neutral-400">اعتذار متأخر</span>
              </div>
            </div>

            {user.lateCancellations > 0 && (
              <p className="text-[10px] text-neutral-400 px-1 pt-1 leading-relaxed">
                * الاعتذار المتأخر يتم تسجيله إذا اعتذر العضو بعد انتهاء آخر ميعاد للرد أو قرب الماتش.
              </p>
            )}
          </div>

          {/* ========================================================================= */}
          {/* تقييم الأعضاء للكابتن (Specification: نجوم الالتزام والمستوى ومتوسط التقييم) */}
          {/* ========================================================================= */}
          <div className="rounded-2xl p-3.5 bg-neutral-950/80 border border-neutral-800 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1.5">
                <Star className="w-4 h-4 text-amber-400 fill-current" />
                <span className="text-xs font-bold text-white">تقييم الالتزام والمستوى ⭐</span>
              </div>
              <span className="text-[10px] text-neutral-400">
                {ratingStats.totalRatingsCount > 0 
                  ? `بناءً على ${ratingStats.totalRatingsCount} تقييم`
                  : 'لا يوجد تقييمات بعد'}
              </span>
            </div>

            {/* Average Summary Card */}
            <div className="p-3 rounded-xl bg-gradient-to-br from-amber-500/10 via-neutral-900 to-neutral-900 border border-amber-500/20 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="text-3xl font-black font-display text-amber-400 tracking-tight flex items-baseline gap-1">
                  <span>{ratingStats.averageOverall}</span>
                  <span className="text-xs text-neutral-400 font-normal">/ 5</span>
                </div>
                <div className="space-y-0.5">
                  <div className="flex items-center gap-0.5 text-amber-400">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <Star
                        key={star}
                        className={`w-3.5 h-3.5 ${
                          star <= Math.round(ratingStats.averageOverall)
                            ? 'fill-current text-amber-400'
                            : 'text-neutral-700'
                        }`}
                      />
                    ))}
                  </div>
                  <span className="text-[10px] text-neutral-400 block">
                    {ratingStats.averageOverall >= 4.7
                      ? 'لاعب ممتاز ومحبوب في كل الحجوزات 🌟'
                      : ratingStats.averageOverall >= 4.0
                      ? 'مستوى عالي والتزام جيد 👍'
                      : 'محتاج تركيز في الالتزام بالمواعيد ⏱️'}
                  </span>
                </div>
              </div>

              {!isMe && (
                <button
                  onClick={() => setShowRateModal(true)}
                  className="px-3 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 active:scale-95 text-neutral-950 font-bold text-xs shadow-md shadow-amber-500/10 transition-all flex items-center gap-1"
                >
                  <Star className="w-3.5 h-3.5 fill-current" />
                  <span>قيّم الكابتن</span>
                </button>
              )}
            </div>

            {/* Detailed Criteria Breakdown */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
              {/* Criterion 1: الالتزام */}
              <div className="p-2.5 rounded-xl bg-neutral-900 border border-neutral-800 space-y-1">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-neutral-300 font-semibold flex items-center gap-1">
                    <span>⏱️</span>
                    <span>الالتزام بالمواعيد</span>
                  </span>
                  <span className="font-mono font-bold text-amber-400">
                    {ratingStats.averageCommitment} / 5
                  </span>
                </div>
                {/* Progress bar */}
                <div className="w-full h-1.5 bg-neutral-800 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-amber-400 rounded-full transition-all duration-500"
                    style={{ width: `${(ratingStats.averageCommitment / 5) * 100}%` }}
                  />
                </div>
                <span className="text-[9px] text-neutral-400 block">
                  حضور في الميعاد وعدم انسحاب مفاجئ
                </span>
              </div>

              {/* Criterion 2: المستوى الكروي */}
              <div className="p-2.5 rounded-xl bg-neutral-900 border border-neutral-800 space-y-1">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-neutral-300 font-semibold flex items-center gap-1">
                    <span>⚽</span>
                    <span>المستوى والمهارة</span>
                  </span>
                  <span className="font-mono font-bold text-emerald-400">
                    {ratingStats.averageSkill} / 5
                  </span>
                </div>
                {/* Progress bar */}
                <div className="w-full h-1.5 bg-neutral-800 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-emerald-400 rounded-full transition-all duration-500"
                    style={{ width: `${(ratingStats.averageSkill / 5) * 100}%` }}
                  />
                </div>
                <span className="text-[9px] text-neutral-400 block">
                  دقة الباص والتحكم وتأثيره في الماتش
                </span>
              </div>
            </div>

            {/* Teammate comments / recent feedback */}
            {userRatings.length > 0 && (
              <div className="space-y-1.5 pt-1">
                <span className="text-[10px] font-bold text-neutral-400 block">
                  آراء وشهادات زمايله في الماتشات الأخيرة:
                </span>
                <div className="space-y-1.5 max-h-36 overflow-y-auto pr-0.5">
                  {userRatings.slice(0, 3).map((r) => (
                    <div
                      key={r.id}
                      className="p-2 rounded-xl bg-neutral-900/90 border border-neutral-800/80 text-xs space-y-1"
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-neutral-200 text-[11px]">
                          {r.raterName}
                        </span>
                        <div className="flex items-center gap-1 text-[10px]">
                          <span className="text-amber-400 font-bold flex items-center gap-0.5">
                            <Star className="w-2.5 h-2.5 fill-current" />
                            {r.commitmentRating}
                          </span>
                          <span className="text-neutral-500">•</span>
                          <span className="text-emerald-400 font-bold flex items-center gap-0.5">
                            ⚽ {r.skillRating}
                          </span>
                        </div>
                      </div>
                      {r.feedbackTag && (
                        <span className="inline-block text-[9px] font-semibold px-2 py-0.5 rounded-full bg-amber-500/10 text-amber-300 border border-amber-500/20">
                          {r.feedbackTag}
                        </span>
                      )}
                      {r.comment && (
                        <p className="text-[10px] text-neutral-400 italic">
                          "{r.comment}"
                        </p>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* ========================================================================= */}
          {/* رقم الموبايل وخيار الإخفاء (Specification 1) */}
          {/* ========================================================================= */}
          <div className="rounded-2xl p-3.5 bg-neutral-950/80 border border-neutral-800 space-y-2.5">
            <div className="text-[11px] font-bold text-neutral-300 flex items-center gap-1.5">
              <Phone className="w-3.5 h-3.5 text-neutral-400" />
              <span>بيانات الاتصال برقم الموبايل</span>
            </div>

            {/* Check if phone is hidden by user and viewer is not owner */}
            {user.hidePhone && !isMe ? (
              <div className="p-3 rounded-xl bg-neutral-900 border border-neutral-800 flex items-center gap-2.5 text-neutral-400">
                <div className="w-7 h-7 rounded-lg bg-neutral-800 flex items-center justify-center text-neutral-400 shrink-0">
                  <EyeOff className="w-4 h-4" />
                </div>
                <div>
                  <div className="text-xs font-semibold text-neutral-300">
                    رقم الموبايل مخفي
                  </div>
                  <div className="text-[10px] text-neutral-400">
                    اللاعب مفعل خيار إخفاء رقمه عن باقي أعضاء الجروب للخصوصية.
                  </div>
                </div>
              </div>
            ) : (
              <div className="p-3 rounded-xl bg-neutral-900 border border-neutral-800 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-mono text-sm font-bold text-white tracking-wider" dir="ltr">
                    {user.phone}
                  </span>
                  {user.hidePhone && isMe && (
                    <span className="text-[10px] px-2 py-0.5 rounded bg-amber-500/10 text-amber-400 border border-amber-500/20 font-semibold">
                      مخفي عن باقي الأعضاء
                    </span>
                  )}
                </div>

                {!isMe && (
                  <div className="grid grid-cols-2 gap-2 pt-1 border-t border-neutral-800">
                    <a
                      href={`https://wa.me/2${user.phone.replace(/[^0-9]/g, '')}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="py-1.5 px-3 rounded-lg bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-400 text-xs font-bold flex items-center justify-center gap-1.5 transition-colors"
                    >
                      <MessageCircle className="w-3.5 h-3.5" />
                      <span>واتساب</span>
                    </a>
                    <a
                      href={`tel:${user.phone}`}
                      className="py-1.5 px-3 rounded-lg bg-neutral-800 hover:bg-neutral-750 text-neutral-200 text-xs font-bold flex items-center justify-center gap-1.5 transition-colors"
                    >
                      <PhoneCall className="w-3.5 h-3.5" />
                      <span>اتصال</span>
                    </a>
                  </div>
                )}
              </div>
            )}

            {/* Privacy toggle setting for current user (Specification 1) */}
            {isMe && (
              <div className="pt-2 border-t border-neutral-800">
                <label className="flex items-center justify-between cursor-pointer p-1 rounded-lg hover:bg-neutral-900 transition-colors">
                  <div className="space-y-0.5">
                    <span className="text-xs font-semibold text-neutral-200 block">
                      إخفاء رقمي عن باقي الأعضاء
                    </span>
                    <span className="text-[10px] text-neutral-400 block">
                      لن يظهر رقمك لأي لاعب آخر في الجروب، فقط أنت الذي تراه
                    </span>
                  </div>
                  <input
                    type="checkbox"
                    checked={isEditing ? hidePhoneInput : user.hidePhone}
                    onChange={(e) => {
                      if (isEditing) {
                        setHidePhoneInput(e.target.checked);
                      } else {
                        updateProfile({ hidePhone: e.target.checked });
                      }
                    }}
                    className="w-4 h-4 rounded text-emerald-600 bg-neutral-800 border-neutral-700 focus:ring-emerald-500 cursor-pointer"
                  />
                </label>
              </div>
            )}
          </div>

          {/* Bio input when editing */}
          {isEditing && (
            <div className="rounded-2xl p-3 bg-neutral-950/80 border border-neutral-800 space-y-1.5">
              <label className="text-xs font-bold text-neutral-300">نبذة عن طريقة لعبك:</label>
              <textarea
                value={bioInput}
                onChange={(e) => setBioInput(e.target.value)}
                placeholder="مثلاً: بلعب هجوم وبحب التسديد من برة 18..."
                rows={2}
                className="w-full bg-neutral-900 border border-neutral-700 focus:border-emerald-500 rounded-xl p-2 text-xs text-white placeholder-neutral-500 outline-none resize-none"
              />
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="p-3 border-t border-neutral-800 bg-neutral-900 flex items-center justify-end gap-2">
          {isEditing ? (
            <>
              <button
                onClick={() => setIsEditing(false)}
                className="px-4 py-2 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-300 text-xs font-medium transition-colors"
              >
                إلغاء
              </button>
              <button
                onClick={handleSave}
                className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition-colors flex items-center gap-1"
              >
                <Check className="w-3.5 h-3.5" />
                <span>حفظ التعديلات</span>
              </button>
            </>
          ) : (
            <button
              onClick={onClose}
              className="w-full py-2.5 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-xs font-semibold transition-colors"
            >
              إغلاق
            </button>
          )}
        </div>
      </div>

      {/* Rate Player Modal */}
      {showRateModal && (
        <RatePlayerModal
          matchId="direct_profile_rate"
          matchTitle="تقييم مباشر من البروفايل"
          targetUserId={user.id}
          onClose={() => setShowRateModal(false)}
        />
      )}
    </div>
  );
};
