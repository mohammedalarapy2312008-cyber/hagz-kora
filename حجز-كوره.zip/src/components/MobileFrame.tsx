import React from 'react';
import { useApp } from '../context/AppContext';
import { Wifi, BatteryMedium, Signal, X, Sparkles, CheckCircle2, AlertTriangle, Users, Calendar } from 'lucide-react';

interface MobileFrameProps {
  children: React.ReactNode;
  deviceType: 'ios' | 'android';
  isFramed: boolean;
  onNotificationClick?: () => void;
}

export const MobileFrame: React.FC<MobileFrameProps> = ({
  children,
  deviceType,
  isFramed,
  onNotificationClick
}) => {
  const { activeToast, clearActiveToast } = useApp();

  // Current simulated time
  const currentTime = '20:30';

  const content = (
    <div className="relative w-full h-full flex flex-col bg-neutral-950 text-neutral-100 overflow-hidden select-none">
      {/* Mobile Status Bar */}
      <div className="shrink-0 h-9 px-5 pt-1.5 flex items-center justify-between text-[11px] font-semibold text-neutral-300 z-50 bg-neutral-900/40 backdrop-blur-sm select-none">
        {/* Left: Time */}
        <span className="font-mono tracking-tight text-xs font-bold text-white">
          {currentTime}
        </span>

        {/* Center: iOS Dynamic Island or Android Punch Hole */}
        {deviceType === 'ios' ? (
          <div className="w-24 h-4 bg-black rounded-full mx-auto flex items-center justify-center space-x-1 ring-1 ring-neutral-800/80">
            <span className="w-2.5 h-2.5 rounded-full bg-neutral-900 ring-1 ring-neutral-800" />
            <span className="w-1.5 h-1.5 rounded-full bg-blue-900/60" />
          </div>
        ) : (
          <div className="w-3.5 h-3.5 bg-black rounded-full mx-auto ring-1 ring-neutral-800" />
        )}

        {/* Right: Icons (Signal, Wifi, Battery) */}
        <div className="flex items-center gap-1.5 text-neutral-300">
          <Signal className="w-3 h-3" />
          <Wifi className="w-3 h-3" />
          <div className="flex items-center gap-0.5">
            <span className="text-[9px] font-mono">88%</span>
            <BatteryMedium className="w-3.5 h-3.5 text-emerald-400" />
          </div>
        </div>
      </div>

      {/* Floating Push Notification Toast Banner */}
      {activeToast && (
        <aside 
          aria-label="إشعار فوري جديد"
          onClick={() => {
            onNotificationClick?.();
            clearActiveToast();
          }}
          className="absolute top-10 left-3 right-3 z-50 p-3 rounded-2xl bg-neutral-900/95 border border-emerald-500/40 shadow-2xl backdrop-blur-md animate-in slide-in-from-top duration-250 cursor-pointer flex items-start gap-2.5"
        >
          <div className="w-8 h-8 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0">
            {activeToast.type === 'waitlist_promoted' ? (
              <Users className="w-4 h-4 text-blue-400" />
            ) : activeToast.type === 'risk_cancellation' ? (
              <AlertTriangle className="w-4 h-4 text-rose-400" />
            ) : (
              <Sparkles className="w-4 h-4 text-emerald-400" />
            )}
          </div>

          <div className="min-w-0 flex-1 text-right">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-white truncate">
                {activeToast.title}
              </span>
              <span className="text-[9px] text-neutral-400 font-mono">الآن</span>
            </div>
            <p className="text-[11px] text-neutral-300 mt-0.5 line-clamp-2">
              {activeToast.message}
            </p>
          </div>

          <button
            onClick={(e) => {
              e.stopPropagation();
              clearActiveToast();
            }}
            className="p-1 rounded-full text-neutral-400 hover:text-white"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </aside>
      )}

      {/* Main Inner Application Container */}
      <div className="flex-1 flex flex-col min-h-0 overflow-hidden relative">
        {children}
      </div>

      {/* iOS Home Indicator Bar */}
      {deviceType === 'ios' && (
        <div className="shrink-0 h-4 flex items-center justify-center bg-neutral-900/95 pb-1">
          <div className="w-32 h-1 bg-neutral-500/60 rounded-full" />
        </div>
      )}
    </div>
  );

  if (!isFramed) {
    return (
      <div className="w-full min-h-screen bg-neutral-950 flex justify-center">
        <main className="w-full max-w-md h-screen flex flex-col shadow-2xl relative">
          {content}
        </main>
      </div>
    );
  }

  return (
    <div className="w-full min-h-[calc(100vh-45px)] py-4 flex items-center justify-center bg-neutral-950/95 px-2">
      {/* Smartphone Device Mockup Bezel */}
      <main className="relative w-full max-w-[400px] h-[830px] rounded-[48px] bg-neutral-900 border-[10px] border-neutral-800 shadow-[0_25px_60px_-15px_rgba(0,0,0,0.8)] overflow-hidden ring-1 ring-neutral-700/50 flex flex-col">
        {content}
      </main>
    </div>
  );
};
