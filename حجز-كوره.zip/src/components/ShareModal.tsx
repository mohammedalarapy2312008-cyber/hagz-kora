import React, { useState } from 'react';
import { QRCodeSVG } from 'qrcode.react';
import { 
  X, 
  Share2, 
  Copy, 
  Check, 
  QrCode, 
  MessageSquare, 
  ExternalLink, 
  Download, 
  Calendar, 
  MapPin, 
  Users, 
  Banknote,
  Sparkles,
  Smartphone
} from 'lucide-react';
import { MatchPost, Group } from '../types';

export type ShareType = 'match' | 'group' | 'app';

interface ShareModalProps {
  type: ShareType;
  match?: MatchPost;
  group?: Group;
  isOpen: boolean;
  onClose: () => void;
}

export const ShareModal: React.FC<ShareModalProps> = ({
  type,
  match,
  group,
  isOpen,
  onClose
}) => {
  const [activeSubTab, setActiveSubTab] = useState<'share' | 'qr'>('share');
  const [copiedLink, setCopiedLink] = useState(false);
  const [copiedText, setCopiedText] = useState(false);
  const [copiedCode, setCopiedCode] = useState(false);

  if (!isOpen) return null;

  // Base URL calculation (production app URL or origin)
  const origin = typeof window !== 'undefined' ? window.location.origin : 'https://koretna.app';
  
  let shareUrl = origin;
  let shareTitle = 'كورتنا - تنسيق ماتشات الكورة';
  let shareText = '';

  if (type === 'match' && match) {
    shareUrl = `${origin}?match=${match.id}${match.groupId ? `&group=${match.groupId}` : ''}`;
    shareTitle = `حجز ماتش كورة في ${match.pitchName}`;

    // Format date & time
    const matchDate = new Date(match.matchDateTime);
    const dateStr = matchDate.toLocaleDateString('ar-EG', {
      weekday: 'long',
      day: 'numeric',
      month: 'long'
    });
    const timeStr = matchDate.toLocaleTimeString('ar-EG', {
      hour: '2-digit',
      minute: '2-digit'
    });

    const activePlayersCount = match.responses.filter(r => r.status === 'playing' && !r.isWaitlist).length;
    const spotsLeft = Math.max(0, match.requiredPlayers - activePlayersCount);
    const costPerPlayer = Math.round(match.totalCost / match.requiredPlayers);

    shareText = `⚽ يلا يا شباب ماتش كورة جديد في "${match.pitchName}"!
📍 المكان: ${match.pitchLocationText || 'ملعب كورة'}
📅 الميعاد: ${dateStr} الساعة ${timeStr}
👥 العدد المطلوب: ${match.requiredPlayers} لاعب (فاضل ${spotsLeft} أماكن)
💵 الحسبة: ${costPerPlayer} ج.م للفرد (إجمالي الملعب ${match.totalCost} ج.م)
⏳ سجل ردك من الرابط قبل اكتمال العدد:
${shareUrl}`;
  } else if (type === 'group' && group) {
    shareUrl = `${origin}?group=${group.id}&invite=${group.inviteCode}`;
    shareTitle = `دعوة للانضمام إلى جروب "${group.name}" على كورتنا`;
    shareText = `⚽ انضم لجروبنا "${group.name}" على تطبيق كورتنا!
🏆 لتنسيق ماتشات الكورة الأسبوعية، متابعة الحجوزات، والـ Waitlist.
🔑 كود الدعوة: ${group.inviteCode}
📲 ادخل مباشرة من الرابط:
${shareUrl}`;
  } else {
    // App general share
    shareUrl = origin;
    shareTitle = 'تطبيق كورتنا لتنسيق ماتشات الكورة';
    shareText = `⚽ نزل وجرب أبلكيشن "كورتنا" لتنسيق ماتشات الكورة وقوائم الانتظار وتقسيم الفلوس بين الصحاب!
📱 الرابط المباشر:
${shareUrl}`;
  }

  // Open WhatsApp directly
  const handleWhatsAppShare = () => {
    const encodedText = encodeURIComponent(shareText);
    const whatsappUrl = `https://api.whatsapp.com/send?text=${encodedText}`;
    window.open(whatsappUrl, '_blank', 'noopener,noreferrer');
  };

  // Copy link to clipboard
  const handleCopyLink = async () => {
    try {
      if (navigator.clipboard?.writeText) {
        await navigator.clipboard.writeText(shareUrl);
      } else {
        const textArea = document.createElement('textarea');
        textArea.value = shareUrl;
        document.body.appendChild(textArea);
        textArea.select();
        document.execCommand('copy');
        document.body.removeChild(textArea);
      }
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2500);
    } catch {
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2500);
    }
  };

  // Copy full message text
  const handleCopyFullText = async () => {
    try {
      if (navigator.clipboard?.writeText) {
        await navigator.clipboard.writeText(shareText);
      } else {
        const textArea = document.createElement('textarea');
        textArea.value = shareText;
        document.body.appendChild(textArea);
        textArea.select();
        document.execCommand('copy');
        document.body.removeChild(textArea);
      }
      setCopiedText(true);
      setTimeout(() => setCopiedText(false), 2500);
    } catch {
      setCopiedText(true);
      setTimeout(() => setCopiedText(false), 2500);
    }
  };

  // Copy invite code (for group)
  const handleCopyCode = async (code: string) => {
    try {
      if (navigator.clipboard?.writeText) {
        await navigator.clipboard.writeText(code);
      }
      setCopiedCode(true);
      setTimeout(() => setCopiedCode(false), 2500);
    } catch {
      setCopiedCode(true);
      setTimeout(() => setCopiedCode(false), 2500);
    }
  };

  // Web Share API
  const handleNativeShare = async () => {
    if (typeof navigator !== 'undefined' && navigator.share) {
      try {
        await navigator.share({
          title: shareTitle,
          text: shareText,
          url: shareUrl
        });
      } catch {
        // user cancelled or share failed, fallback handled
      }
    } else {
      handleCopyLink();
    }
  };

  // Download QR Code as SVG
  const handleDownloadQR = () => {
    const svgElement = document.getElementById('koretna-qr-svg');
    if (!svgElement) return;

    const svgData = new XMLSerializer().serializeToString(svgElement);
    const svgBlob = new Blob([svgData], { type: 'image/svg+xml;charset=utf-8' });
    const svgUrl = URL.createObjectURL(svgBlob);
    const downloadLink = document.createElement('a');
    downloadLink.href = svgUrl;
    downloadLink.download = `koretna-${type}-${Date.now()}.svg`;
    document.body.appendChild(downloadLink);
    downloadLink.click();
    document.body.removeChild(downloadLink);
    URL.revokeObjectURL(svgUrl);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4 animate-in fade-in duration-200">
      <div className="w-full max-w-md bg-neutral-900 border border-neutral-800 rounded-t-3xl sm:rounded-3xl overflow-hidden shadow-2xl max-h-[92vh] flex flex-col">
        {/* Header */}
        <div className="p-4 pb-3 border-b border-neutral-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className={`w-9 h-9 rounded-xl flex items-center justify-center text-white shadow-md ${
              type === 'match' 
                ? 'bg-gradient-to-br from-emerald-500 to-teal-700 shadow-emerald-950' 
                : type === 'group' 
                ? 'bg-gradient-to-br from-blue-500 to-indigo-700 shadow-blue-950' 
                : 'bg-gradient-to-br from-amber-500 to-orange-700 shadow-amber-950'
            }`}>
              {type === 'match' ? (
                <Share2 className="w-4.5 h-4.5 stroke-[2.2]" />
              ) : type === 'group' ? (
                <Users className="w-4.5 h-4.5 stroke-[2.2]" />
              ) : (
                <Smartphone className="w-4.5 h-4.5 stroke-[2.2]" />
              )}
            </div>
            <div>
              <h3 className="text-sm font-bold text-white font-display">
                {type === 'match' 
                  ? 'مشاركة الماتش مع الأصحاب' 
                  : type === 'group' 
                  ? 'مشاركة الجروب ورمز الدعوة' 
                  : 'مشاركة تطبيق كورتنا'}
              </h3>
              <p className="text-[11px] text-neutral-400">
                {type === 'match'
                  ? 'دعوة لعيبة للانضمام وإكمال تشكيل الماتش'
                  : type === 'group'
                  ? 'انضمام لعيبة جدد للجروب عبر واتساب أو QR'
                  : 'رمز QR سريع لفتح أو تنزيل التطبيق'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-neutral-800 hover:bg-neutral-700 text-neutral-400 hover:text-white flex items-center justify-center transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tab switch: Share & WhatsApp vs QR Code */}
        <div className="px-4 pt-3">
          <div className="flex items-center p-1 bg-neutral-950 rounded-xl border border-neutral-800">
            <button
              onClick={() => setActiveSubTab('share')}
              className={`flex-1 py-1.5 text-xs font-bold rounded-lg transition-colors flex items-center justify-center gap-1.5 ${
                activeSubTab === 'share'
                  ? 'bg-neutral-850 text-white shadow-sm'
                  : 'text-neutral-400 hover:text-neutral-200'
              }`}
            >
              <Share2 className="w-3.5 h-3.5 text-emerald-400" />
              <span>مشاركة وواتساب</span>
            </button>
            <button
              onClick={() => setActiveSubTab('qr')}
              className={`flex-1 py-1.5 text-xs font-bold rounded-lg transition-colors flex items-center justify-center gap-1.5 ${
                activeSubTab === 'qr'
                  ? 'bg-neutral-850 text-white shadow-sm'
                  : 'text-neutral-400 hover:text-neutral-200'
              }`}
            >
              <QrCode className="w-3.5 h-3.5 text-emerald-400" />
              <span>رمز QR للاستجابة السريعة</span>
            </button>
          </div>
        </div>

        {/* Modal Body */}
        <div className="p-4 overflow-y-auto space-y-3.5">
          {/* TAB 1: WhatsApp & Links */}
          {activeSubTab === 'share' && (
            <div className="space-y-3">
              {/* Highlight Card preview for Match or Group */}
              {type === 'match' && match && (
                <div className="p-3 rounded-2xl bg-neutral-950 border border-neutral-800 text-xs space-y-1.5">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-white flex items-center gap-1.5">
                      <MapPin className="w-3.5 h-3.5 text-emerald-400" />
                      {match.pitchName}
                    </span>
                    <span className="text-[10px] text-emerald-400 font-bold bg-emerald-500/10 px-2 py-0.5 rounded-full">
                      ماتش مفتوح
                    </span>
                  </div>
                  <div className="grid grid-cols-2 gap-2 text-[11px] text-neutral-300 pt-1 border-t border-neutral-850">
                    <div className="flex items-center gap-1">
                      <Calendar className="w-3 h-3 text-neutral-400" />
                      <span>{new Date(match.matchDateTime).toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' })}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Banknote className="w-3 h-3 text-emerald-400" />
                      <span>{Math.round(match.totalCost / match.requiredPlayers)} ج.م / لاعب</span>
                    </div>
                  </div>
                </div>
              )}

              {type === 'group' && group && (
                <div className="p-3 rounded-2xl bg-neutral-950 border border-neutral-800 flex items-center justify-between">
                  <div className="flex items-center gap-2.5 truncate">
                    <img
                      src={group.avatar}
                      alt={group.name}
                      className="w-10 h-10 rounded-xl object-cover border border-neutral-700 shrink-0"
                    />
                    <div className="truncate text-right">
                      <span className="text-xs font-bold text-white block truncate">{group.name}</span>
                      <span className="text-[10px] text-neutral-400 block font-mono">
                        كود الدعوة: <strong className="text-emerald-400">{group.inviteCode}</strong>
                      </span>
                    </div>
                  </div>
                  <button
                    onClick={() => handleCopyCode(group.inviteCode)}
                    className="px-2.5 py-1.5 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-xs font-semibold flex items-center gap-1 shrink-0"
                  >
                    {copiedCode ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                    <span>{copiedCode ? 'تم النسخ!' : 'نسخ الكود'}</span>
                  </button>
                </div>
              )}

              {/* Primary Action 1: WhatsApp Button */}
              <button
                onClick={handleWhatsAppShare}
                className="w-full py-3 px-4 rounded-2xl bg-[#25D366] hover:bg-[#20ba59] active:scale-[0.99] text-white font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-[#25D366]/20 transition-all"
              >
                {/* WhatsApp Logo SVG */}
                <svg className="w-5 h-5 fill-current" viewBox="0 0 24 24">
                  <path d="M12.031 6.172c-3.181 0-5.767 2.586-5.768 5.766-.001 1.298.38 2.27 1.019 3.287l-.582 2.128 2.182-.573c.978.58 1.911.928 3.145.929 3.178 0 5.767-2.587 5.768-5.766.001-3.187-2.575-5.77-5.764-5.771zm3.392 8.244c-.144.405-.837.774-1.17.824-.299.045-.677.063-1.092-.069-.252-.08-.575-.187-.988-.365-1.739-.751-2.874-2.502-2.961-2.617-.087-.116-.708-.94-.708-1.793s.448-1.273.607-1.446c.159-.173.346-.217.462-.217l.332.007c.106.005.249-.04.39.299.144.347.491 1.2.534 1.287.043.087.072.188.014.304-.058.116-.087.188-.173.289l-.26.304c-.087.086-.177.18-.076.354.101.174.449.741.964 1.201.662.591 1.221.774 1.394.86.174.086.275.072.376-.044.101-.116.433-.506.549-.68.116-.173.231-.144.39-.086s1.011.477 1.184.564.289.13.332.202c.045.072.045.419-.099.824zm-3.423-14.416c-6.627 0-12 5.373-12 12 0 2.155.57 4.179 1.564 5.927l-1.572 5.733 5.867-1.539c1.691.923 3.633 1.447 5.703 1.447 6.627 0 12-5.373 12-12s-5.373-12-12-12z"/>
                </svg>
                <span>مشاركة مباشرة على واتساب</span>
              </button>

              {/* Action 2: Copy Share Link */}
              <div className="flex items-center gap-1.5 bg-neutral-950 p-1.5 rounded-xl border border-neutral-800">
                <input
                  type="text"
                  readOnly
                  value={shareUrl}
                  className="bg-transparent text-xs text-neutral-300 font-mono flex-1 outline-none px-2 truncate text-left"
                  dir="ltr"
                />
                <button
                  onClick={handleCopyLink}
                  className={`px-3 py-2 rounded-lg text-xs font-bold flex items-center gap-1 transition-all shrink-0 ${
                    copiedLink
                      ? 'bg-emerald-600 text-white'
                      : 'bg-neutral-800 hover:bg-neutral-700 text-neutral-200'
                  }`}
                >
                  {copiedLink ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedLink ? 'تم النسخ!' : 'نسخ الرابط'}</span>
                </button>
              </div>

              {/* Action 3: Copy Pre-formatted WhatsApp Message */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-bold text-neutral-400">
                    نص الدعوة المجهز للماتش:
                  </span>
                  <button
                    onClick={handleCopyFullText}
                    className="text-[11px] text-emerald-400 hover:text-emerald-300 font-semibold flex items-center gap-1"
                  >
                    {copiedText ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                    <span>{copiedText ? 'تم نسخ الرسالة!' : 'نسخ الرسالة كاملة'}</span>
                  </button>
                </div>
                <div className="p-2.5 rounded-xl bg-neutral-950/80 border border-neutral-800/80 text-[11px] text-neutral-300 leading-relaxed font-sans whitespace-pre-line max-h-32 overflow-y-auto">
                  {shareText}
                </div>
              </div>

              {/* Action 4: Native Share sheet if supported */}
              {typeof navigator !== 'undefined' && 'share' in navigator && (
                <button
                  onClick={handleNativeShare}
                  className="w-full py-2.5 rounded-xl bg-neutral-800 hover:bg-neutral-750 text-neutral-200 text-xs font-semibold flex items-center justify-center gap-1.5 border border-neutral-700 transition-colors"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                  <span>مشاركة عبر تطبيقات أخرى (تليجرام، ماسنجر...)</span>
                </button>
              )}
            </div>
          )}

          {/* TAB 2: QR Code */}
          {activeSubTab === 'qr' && (
            <div className="flex flex-col items-center justify-center text-center space-y-3.5 py-1">
              <div className="p-4 rounded-3xl bg-white shadow-xl ring-4 ring-emerald-500/20 inline-block">
                <QRCodeSVG
                  id="koretna-qr-svg"
                  value={shareUrl}
                  size={190}
                  level="M"
                  includeMargin={false}
                  bgColor="#ffffff"
                  fgColor="#0a0a0a"
                />
              </div>

              <div className="space-y-1 max-w-xs">
                <h4 className="text-xs font-bold text-white flex items-center justify-center gap-1">
                  <span>امسح الرمز بكاميرا الموبايل 📷</span>
                </h4>
                <p className="text-[11px] text-neutral-400 leading-relaxed">
                  {type === 'match'
                    ? 'اظهر الرمز لأصحابك في الملعب أو القهوة ليسجلوا في الماتش فوراً'
                    : type === 'group'
                    ? 'امسح الرمز للانضمام المباشر لجروب الكورة'
                    : 'امسح الرمز لفتح واستخدام تطبيق كورتنا'}
                </p>
              </div>

              {/* Action Buttons for QR */}
              <div className="flex items-center gap-2 w-full pt-1">
                <button
                  onClick={handleDownloadQR}
                  className="flex-1 py-2 px-3 rounded-xl bg-neutral-800 hover:bg-neutral-750 text-white text-xs font-bold flex items-center justify-center gap-1.5 border border-neutral-700 transition-colors"
                >
                  <Download className="w-3.5 h-3.5 text-emerald-400" />
                  <span>حفظ صورة QR</span>
                </button>
                <button
                  onClick={handleCopyLink}
                  className="flex-1 py-2 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold flex items-center justify-center gap-1.5 shadow-md shadow-emerald-950 transition-colors"
                >
                  {copiedLink ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedLink ? 'تم نسخ الرابط!' : 'نسخ الرابط'}</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
