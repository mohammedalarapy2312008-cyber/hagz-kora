import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { 
  X, 
  MapPin, 
  Calendar, 
  Clock, 
  Users, 
  Banknote, 
  FileText, 
  Hourglass, 
  Sparkles,
  CheckCircle2
} from 'lucide-react';

interface CreateMatchModalProps {
  onClose: () => void;
}

export const CreateMatchModal: React.FC<CreateMatchModalProps> = ({ onClose }) => {
  const { groups, selectedGroup, createMatchPost, currentUser, setActiveTab } = useApp();

  const [groupId, setGroupId] = useState(selectedGroup ? selectedGroup.id : (groups[0]?.id || ''));
  const [pitchName, setPitchName] = useState('');
  const [pitchLocationText, setPitchLocationText] = useState('');
  
  // Match Date & Time
  const tomorrow = new Date();
  tomorrow.setDate(tomorrow.getDate() + 2);
  const defaultDateStr = tomorrow.toISOString().split('T')[0];
  const [matchDate, setMatchDate] = useState(defaultDateStr);
  const [matchTime, setMatchTime] = useState('20:00');

  // Players & Cost
  const [requiredPlayers, setRequiredPlayers] = useState(10);
  const [hourlyRate, setHourlyRate] = useState(350);
  const [durationHours, setDurationHours] = useState(1.5);

  // Notes
  const [notes, setNotes] = useState('• التواجد قبل الميعاد بربع ساعة.\n• اللعب بكوتشي نجيل صناعي ترتان فقط.\n• الدفع وتقسيم الفلوس قبل بداية الماتش.');

  // Deadline (آخر ميعاد للرد)
  const deadlineDefault = new Date();
  deadlineDefault.setDate(deadlineDefault.getDate() + 1);
  const defaultDeadlineDate = deadlineDefault.toISOString().split('T')[0];
  const [deadlineDate, setDeadlineDate] = useState(defaultDeadlineDate);
  const [deadlineTime, setDeadlineTime] = useState('14:00');

  const [error, setError] = useState<string | null>(null);

  // Automatic calculation of total cost (سعر الساعة × عدد الساعات)
  const calculatedTotalCost = Math.round(hourlyRate * durationHours);
  const fixedPerPlayer = requiredPlayers > 0 ? Math.round(calculatedTotalCost / requiredPlayers) : 0;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!pitchName.trim()) {
      setError('يرجى كتابة اسم أو مكان الملعب');
      return;
    }

    if (!groupId) {
      setError('يرجى اختيار الجروب الذي تريد نشر الحجز فيه');
      return;
    }

    const playersCount = Number(requiredPlayers);
    if (!playersCount || playersCount < 2) {
      setError('يرجى كتابة عدد لاعبين صحيح (لاعبين كحد أدنى)');
      return;
    }

    const matchDateTimeStr = `${matchDate}T${matchTime}:00`;
    const deadlineDateTimeStr = `${deadlineDate}T${deadlineTime}:00`;

    if (new Date(deadlineDateTimeStr) >= new Date(matchDateTimeStr)) {
      setError('آخر ميعاد للرد يجب أن يكون قبل ميعاد الماتش');
      return;
    }

    createMatchPost({
      groupId,
      creatorId: currentUser.id,
      creatorName: currentUser.name,
      creatorAvatar: currentUser.avatar,
      pitchName: pitchName.trim(),
      pitchLocationText: pitchLocationText.trim(),
      matchDateTime: matchDateTimeStr,
      requiredPlayers: Number(requiredPlayers),
      hourlyRate: Number(hourlyRate),
      durationHours: Number(durationHours),
      totalCost: calculatedTotalCost,
      notes: notes.trim(),
      deadlineDateTime: deadlineDateTimeStr
    });

    setActiveTab('matches');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4 animate-in fade-in duration-200">
      <div className="w-full max-w-lg bg-neutral-900 border border-neutral-800 rounded-t-3xl sm:rounded-3xl overflow-hidden shadow-2xl max-h-[92vh] flex flex-col">
        {/* Header */}
        <div className="p-4 pb-3 border-b border-neutral-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
              ⚽
            </div>
            <div>
              <h2 className="text-sm font-bold text-white font-display">إنشاء بوست حجز جديد</h2>
              <p className="text-[11px] text-neutral-400">أي عضو يقدر ينزل حجز ماتش للجروب</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full flex items-center justify-center bg-neutral-800 hover:bg-neutral-700 text-neutral-400 hover:text-white transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-4 overflow-y-auto space-y-4">
          {error && (
            <div className="p-2.5 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs">
              {error}
            </div>
          )}

          {/* 1. Group Selector */}
          <div>
            <label className="text-xs font-bold text-neutral-300 mb-1.5 block">
              اختر الجروب:
            </label>
            <select
              value={groupId}
              onChange={(e) => setGroupId(e.target.value)}
              className="w-full bg-neutral-950 border border-neutral-700 focus:border-emerald-500 rounded-xl px-3 py-2 text-xs text-white outline-none"
            >
              {groups.map(g => (
                <option key={g.id} value={g.id}>
                  {g.name} {g.isPublic ? '(عام)' : '(خاص)'}
                </option>
              ))}
            </select>
          </div>

          {/* 2. Pitch Info */}
          <div className="space-y-2">
            <label className="text-xs font-bold text-neutral-300 flex items-center gap-1">
              <MapPin className="w-3.5 h-3.5 text-blue-400" />
              <span>بيانات الملعب والمكان:</span>
            </label>
            <input
              type="text"
              value={pitchName}
              onChange={(e) => setPitchName(e.target.value)}
              placeholder="اسم الملعب (مثلاً: أرينا سبورت - التجمع الخامس)"
              className="w-full bg-neutral-950 border border-neutral-700 focus:border-blue-500 rounded-xl px-3 py-2 text-xs text-white outline-none"
              required
            />
            {/* Quick Pitch Suggestions */}
            <div className="flex flex-wrap gap-1">
              {[
                'ملاعب نادي الصيد بالدقي',
                'صالة المعادي دجلة المغطاة',
                'أرينا التجمع الخامس',
                'ملعب النادي الأهلي مدينة نصر'
              ].map(suggested => (
                <button
                  type="button"
                  key={suggested}
                  onClick={() => setPitchName(suggested)}
                  className="text-[10px] px-2 py-0.5 rounded bg-neutral-800 hover:bg-neutral-750 text-neutral-400 hover:text-white border border-neutral-700 transition-colors"
                >
                  + {suggested}
                </button>
              ))}
            </div>
            <input
              type="text"
              value={pitchLocationText}
              onChange={(e) => setPitchLocationText(e.target.value)}
              placeholder="العنوان أو المعلم القريب (اختياري، مثلاً: بجوار المستشفى الجوي)"
              className="w-full bg-neutral-950 border border-neutral-700 focus:border-blue-500 rounded-xl px-3 py-2 text-xs text-white outline-none"
            />
          </div>

          {/* 3. Match Date & Time */}
          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="text-xs font-bold text-neutral-300 mb-1 flex items-center gap-1">
                <Calendar className="w-3.5 h-3.5 text-blue-400" />
                <span>تاريخ الماتش:</span>
              </label>
              <input
                type="date"
                value={matchDate}
                onChange={(e) => setMatchDate(e.target.value)}
                className="w-full bg-neutral-950 border border-neutral-700 focus:border-blue-500 rounded-xl px-2.5 py-2 text-xs text-white outline-none"
                required
              />
            </div>
            <div>
              <label className="text-xs font-bold text-neutral-300 mb-1 flex items-center gap-1">
                <Clock className="w-3.5 h-3.5 text-blue-400" />
                <span>ساعة البداية:</span>
              </label>
              <input
                type="time"
                value={matchTime}
                onChange={(e) => setMatchTime(e.target.value)}
                className="w-full bg-neutral-950 border border-neutral-700 focus:border-blue-500 rounded-xl px-2.5 py-2 text-xs text-white outline-none"
                required
              />
            </div>
          </div>

          {/* 4. Required Players (إدخال تحريري مرن يحدده صاحب البوست) */}
          <div className="rounded-2xl p-3 bg-neutral-950/80 border border-neutral-800 space-y-2.5">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-neutral-300 flex items-center gap-1.5">
                <Users className="w-4 h-4 text-emerald-400" />
                <span>عدد اللاعبين المطلوب (نظام تحريري):</span>
              </label>
              <span className="text-[11px] font-bold text-emerald-400 font-mono bg-emerald-500/10 px-2 py-0.5 rounded-full border border-emerald-500/20">
                {requiredPlayers || 0} لاعب
              </span>
            </div>

            {/* Manual Editable Input with Steppers */}
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setRequiredPlayers(prev => Math.max(2, (Number(prev) || 0) - 1))}
                className="w-10 h-10 rounded-xl bg-neutral-900 hover:bg-neutral-800 active:scale-95 border border-neutral-700 text-white font-bold text-lg flex items-center justify-center transition-all shrink-0"
                title="تقليل لاعب"
              >
                -
              </button>

              <div className="relative flex-1">
                <input
                  type="number"
                  min="2"
                  max="40"
                  value={requiredPlayers || ''}
                  onChange={(e) => {
                    const val = parseInt(e.target.value, 10);
                    setRequiredPlayers(isNaN(val) ? 0 : val);
                  }}
                  placeholder="اكتب عدد اللاعبين..."
                  className="w-full h-10 bg-neutral-900 border border-neutral-700 focus:border-emerald-500 rounded-xl px-3 text-center text-sm font-bold text-white font-mono outline-none transition-colors"
                  required
                />
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-[10px] text-neutral-400 pointer-events-none">
                  لاعب
                </span>
              </div>

              <button
                type="button"
                onClick={() => setRequiredPlayers(prev => Math.min(40, (Number(prev) || 0) + 1))}
                className="w-10 h-10 rounded-xl bg-neutral-900 hover:bg-neutral-800 active:scale-95 border border-neutral-700 text-white font-bold text-lg flex items-center justify-center transition-all shrink-0"
                title="زيادة لاعب"
              >
                +
              </button>
            </div>

            {/* Quick Suggestions / Presets for fast selection */}
            <div className="pt-1">
              <span className="text-[10px] text-neutral-400 block mb-1">
                اختيارات سريعة شائعة (خماسي، سداسي، سباعي):
              </span>
              <div className="grid grid-cols-5 gap-1.5">
                {[6, 8, 10, 12, 14].map(num => (
                  <button
                    type="button"
                    key={num}
                    onClick={() => setRequiredPlayers(num)}
                    className={`py-1 rounded-lg text-[11px] font-bold transition-all ${
                      requiredPlayers === num
                        ? 'bg-emerald-600 text-white shadow-sm ring-1 ring-emerald-400'
                        : 'bg-neutral-900 hover:bg-neutral-850 text-neutral-300 border border-neutral-800'
                    }`}
                  >
                    {num}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* 5. Hourly Rate & Duration -> Auto calculates Total Cost */}
          <div className="rounded-2xl p-3 bg-neutral-950/80 border border-emerald-500/20 space-y-2.5">
            <div className="text-xs font-bold text-emerald-400 flex items-center justify-between">
              <span className="flex items-center gap-1">
                <Banknote className="w-4 h-4" />
                <span>سعر الساعة + عدد الساعات (حساب التكلفة أوتوماتيك):</span>
              </span>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-[11px] text-neutral-400 mb-1 block">سعر الساعة (ج.م):</label>
                <input
                  type="number"
                  min="50"
                  step="50"
                  value={hourlyRate}
                  onChange={(e) => setHourlyRate(Number(e.target.value))}
                  className="w-full bg-neutral-900 border border-neutral-700 focus:border-emerald-500 rounded-xl px-2.5 py-1.5 text-xs text-white font-mono outline-none"
                  required
                />
              </div>
              <div>
                <label className="text-[11px] text-neutral-400 mb-1 block">عدد الساعات:</label>
                <select
                  value={durationHours}
                  onChange={(e) => setDurationHours(Number(e.target.value))}
                  className="w-full bg-neutral-900 border border-neutral-700 focus:border-emerald-500 rounded-xl px-2.5 py-1.5 text-xs text-white font-mono outline-none"
                >
                  <option value={1}>ساعة واحدة (60 دقيقة)</option>
                  <option value={1.5}>ساعة ونصف (90 دقيقة)</option>
                  <option value={2}>ساعتين (120 دقيقة)</option>
                  <option value={2.5}>ساعتين ونصف</option>
                  <option value={3}>3 ساعات</option>
                </select>
              </div>
            </div>

            {/* Live Calculation Preview Banner */}
            <div className="p-2 rounded-xl bg-emerald-950/50 border border-emerald-500/30 flex items-center justify-between text-xs">
              <span className="text-emerald-200">
                إجمالي الملعب: <strong className="font-mono text-emerald-300 font-bold">{calculatedTotalCost} ج.م</strong>
              </span>
              <span className="text-emerald-200">
                الحسبة للفرد لو اكتمل: <strong className="font-mono text-emerald-300 font-bold">{fixedPerPlayer} ج.م</strong>
              </span>
            </div>
          </div>

          {/* 6. Notes & Free Rules */}
          <div>
            <label className="text-xs font-bold text-neutral-300 mb-1 flex items-center gap-1">
              <FileText className="w-3.5 h-3.5 text-neutral-400" />
              <span>ملاحظات وقواعد حرة (نص حر):</span>
            </label>
            <textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="اكتب ملاحظاتك هنا..."
              rows={3}
              className="w-full bg-neutral-950 border border-neutral-700 focus:border-emerald-500 rounded-xl p-2.5 text-xs text-white outline-none resize-none leading-relaxed"
            />
          </div>

          {/* 7. آخر ميعاد للرد (يحدده صاحب البوست بنفسه) */}
          <div className="rounded-2xl p-3 bg-neutral-950/80 border border-amber-500/30 space-y-2">
            <div className="text-xs font-bold text-amber-300 flex items-center justify-between">
              <span className="flex items-center gap-1">
                <Hourglass className="w-4 h-4 text-amber-400" />
                <span>آخر ميعاد للرد (يحدده صاحب البوست):</span>
              </span>
              <span className="text-[10px] text-amber-200/80">بدل Deadline</span>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-[11px] text-neutral-400 mb-1 block">تاريخ الإغلاق:</label>
                <input
                  type="date"
                  value={deadlineDate}
                  onChange={(e) => setDeadlineDate(e.target.value)}
                  className="w-full bg-neutral-900 border border-neutral-700 focus:border-amber-500 rounded-xl px-2.5 py-1.5 text-xs text-white outline-none"
                  required
                />
              </div>
              <div>
                <label className="text-[11px] text-neutral-400 mb-1 block">ساعة الإغلاق:</label>
                <input
                  type="time"
                  value={deadlineTime}
                  onChange={(e) => setDeadlineTime(e.target.value)}
                  className="w-full bg-neutral-900 border border-neutral-700 focus:border-amber-500 rounded-xl px-2.5 py-1.5 text-xs text-white outline-none"
                  required
                />
              </div>
            </div>

            <p className="text-[10px] text-amber-200/70">
              * بعد هذا الميعاد لا يمكن تغيير الردود، ولو العدد منكملش هيروح إشعار تلقائي إن الماتش مهدد بالإلغاء.
            </p>
          </div>

          {/* Submit CTA */}
          <div className="pt-2">
            <button
              type="submit"
              className="w-full h-12 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-sm shadow-lg shadow-emerald-950 flex items-center justify-center gap-2 active:scale-[0.99] transition-transform"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>نشر بوست الحجز في الجروب</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
