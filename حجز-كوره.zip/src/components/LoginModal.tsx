import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Phone, KeyRound, ArrowRight, ShieldCheck, Check, Sparkles } from 'lucide-react';

interface LoginModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const LoginModal: React.FC<LoginModalProps> = ({ isOpen, onClose }) => {
  const { loginWithPhone, verifyOtp, allUsers, switchUser } = useApp();

  const [step, setStep] = useState<'phone' | 'otp'>('phone');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [otpCode, setOtpCode] = useState('');
  const [sentOtp, setSentOtp] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleSendPhone = (e: React.FormEvent) => {
    e.preventDefault();
    if (!phoneNumber.trim() || phoneNumber.length < 10) {
      setError('يرجى إدخال رقم موبايل مصري صحيح (11 رقم)');
      return;
    }
    setError(null);
    const { otp } = loginWithPhone(phoneNumber);
    setSentOtp(otp);
    setStep('otp');
  };

  const handleVerify = (e: React.FormEvent) => {
    e.preventDefault();
    if (otpCode !== '1928') {
      setError('كود التأكيد غير صحيح. الكود التجريبي هو: 1928');
      return;
    }

    const success = verifyOtp(phoneNumber, otpCode);
    if (success) {
      onClose();
      setStep('phone');
      setOtpCode('');
      setPhoneNumber('');
    } else {
      setError('حدث خطأ أثناء تسجيل الدخول');
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in duration-200">
      <div className="w-full max-w-sm bg-neutral-900 border border-neutral-800 rounded-3xl p-5 shadow-2xl space-y-4">
        <div className="text-center space-y-1">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-emerald-500 to-emerald-700 flex items-center justify-center text-white mx-auto shadow-lg shadow-emerald-950 text-xl font-display">
            ⚽
          </div>
          <h2 className="text-base font-bold text-white font-display">
            تسجيل الدخول برقم الموبايل (OTP)
          </h2>
          <p className="text-xs text-neutral-400">
            أبلكيشن حجز الكورة لتنظيم الماتشات وتجميع الصحاب
          </p>
        </div>

        {error && (
          <div className="p-2.5 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs text-right">
            {error}
          </div>
        )}

        {step === 'phone' ? (
          <form onSubmit={handleSendPhone} className="space-y-3">
            <div className="space-y-1 text-right">
              <label className="text-xs font-bold text-neutral-300">رقم الموبايل:</label>
              <div className="relative">
                <input
                  type="tel"
                  value={phoneNumber}
                  onChange={(e) => setPhoneNumber(e.target.value)}
                  placeholder="01012345678"
                  dir="ltr"
                  className="w-full bg-neutral-950 border border-neutral-700 focus:border-emerald-500 rounded-xl px-3 py-2.5 text-sm text-white placeholder-neutral-500 font-mono outline-none text-left"
                  required
                />
                <Phone className="w-4 h-4 text-neutral-500 absolute right-3 top-3 pointer-events-none" />
              </div>
              <span className="text-[10px] text-neutral-400 block">
                هنبعتلك كود تأكيد مكون من 4 أرقام في رسالة SMS
              </span>
            </div>

            <button
              type="submit"
              className="w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-lg shadow-emerald-950 transition-colors flex items-center justify-center gap-1.5"
            >
              <span>إرسال كود التأكيد</span>
              <ArrowRight className="w-3.5 h-3.5 rotate-180" />
            </button>
          </form>
        ) : (
          <form onSubmit={handleVerify} className="space-y-3">
            {/* Simulated SMS Toast */}
            {sentOtp && (
              <div className="p-3 rounded-2xl bg-emerald-950/60 border border-emerald-500/30 text-right space-y-1">
                <div className="flex items-center gap-1.5 text-xs font-bold text-emerald-400">
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>رسالة SMS واردة (محاكاة):</span>
                </div>
                <p className="text-xs text-white">
                  كود تأكيد كورتنا لتسجيل الدخول هو: <strong className="font-mono text-emerald-300 text-sm tracking-widest">{sentOtp}</strong>
                </p>
              </div>
            )}

            <div className="space-y-1 text-right">
              <label className="text-xs font-bold text-neutral-300">أدخل كود التأكيد (OTP):</label>
              <div className="relative">
                <input
                  type="text"
                  maxLength={4}
                  value={otpCode}
                  onChange={(e) => setOtpCode(e.target.value)}
                  placeholder="1928"
                  dir="ltr"
                  className="w-full bg-neutral-950 border border-neutral-700 focus:border-emerald-500 rounded-xl px-3 py-2.5 text-base tracking-widest text-center text-white font-mono outline-none"
                  required
                />
                <KeyRound className="w-4 h-4 text-neutral-500 absolute right-3 top-3.5 pointer-events-none" />
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-lg shadow-emerald-950 transition-colors"
            >
              تأكيد وتسجيل الدخول
            </button>

            <button
              type="button"
              onClick={() => setStep('phone')}
              className="w-full py-1 text-xs text-neutral-400 hover:text-white transition-colors"
            >
              تغيير رقم الموبايل
            </button>
          </form>
        )}

        {/* Demo Accounts Quick Login */}
        <div className="pt-2 border-t border-neutral-800 text-right">
          <p className="text-[11px] text-neutral-400 font-semibold mb-2">
            أو اختر حساباً تجريبياً جاهزاً للمعاينة السريعة:
          </p>
          <div className="space-y-1 max-h-36 overflow-y-auto pr-1">
            {allUsers.slice(0, 4).map(u => (
              <button
                key={u.id}
                onClick={() => {
                  switchUser(u.id);
                  onClose();
                }}
                className="w-full flex items-center justify-between p-2 rounded-xl bg-neutral-950 hover:bg-neutral-800 border border-neutral-800 text-xs transition-colors"
              >
                <div className="flex items-center gap-2 truncate">
                  <img src={u.avatar} alt={u.name} className="w-6 h-6 rounded-full object-cover shrink-0" referrerPolicy="no-referrer" />
                  <span className="font-semibold text-white truncate">{u.name}</span>
                </div>
                <span className="text-[10px] text-neutral-400 shrink-0">{u.position.split(' ')[0]}</span>
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
