import React, { useState } from 'react';
import { MatchPost, ResponseStatus } from '../types';
import { useApp } from '../context/AppContext';
import { 
  MapPin, 
  Clock, 
  Users, 
  Banknote, 
  AlertCircle, 
  CheckCircle2, 
  XCircle, 
  HelpCircle, 
  Trash2, 
  ChevronDown, 
  ChevronUp, 
  Info, 
  Hourglass,
  CalendarCheck,
  ShieldCheck,
  Share2,
  Star,
  Award,
  Edit3,
  QrCode
} from 'lucide-react';
import { RatePlayerModal } from './RatePlayerModal';
import { ShareModal } from './ShareModal';
import { getPositionStyle } from '../utils/positionColors';

interface MatchCardProps {
  match: MatchPost;
  onViewUserProfile: (userId: string) => void;
  onEditMatch?: (match: MatchPost) => void;
}

export const MatchCard: React.FC<MatchCardProps> = ({ match, onViewUserProfile, onEditMatch }) => {
  const { 
    currentUser, 
    respondToMatch, 
    deleteMatchPost, 
    updateMatchPost,
    isUserGroupAdmin, 
    groups,
    getUserById,
    markMatchAsFinished,
    hasRatedPlayerInMatch,
    getUserRatingStats
  } = useApp();

  const [isRosterExpanded, setIsRosterExpanded] = useState(false);
  const [showUncertainModal, setShowUncertainModal] = useState(false);
  const [showRateModal, setShowRateModal] = useState(false);
  const [showShareModal, setShowShareModal] = useState(false);
  const [showEditPlayersModal, setShowEditPlayersModal] = useState(false);
  const [editingPlayersCount, setEditingPlayersCount] = useState(match.requiredPlayers);
  const [selectedPlayerToRate, setSelectedPlayerToRate] = useState<string | undefined>(undefined);
  const [uncertainReasonInput, setUncertainReasonInput] = useState('');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const group = groups.find(g => g.id === match.groupId);
  const isAdmin = isUserGroupAdmin(match.groupId);

  // Parse responses
  const activePlayers = match.responses.filter(r => r.status === 'playing' && !r.isWaitlist);
  const waitlistPlayers = match.responses
    .filter(r => r.status === 'playing' && r.isWaitlist)
    .sort((a, b) => (a.waitlistIndex || 0) - (b.waitlistIndex || 0));
  const declinedPlayers = match.responses.filter(r => r.status === 'declined');
  const uncertainPlayers = match.responses.filter(r => r.status === 'uncertain');

  // Current user's response
  const myResponse = match.responses.find(r => r.userId === currentUser.id);

  // Deadline logic
  const deadlineDate = new Date(match.deadlineDateTime);
  const now = new Date();
  const isDeadlinePassed = now.getTime() > deadlineDate.getTime();
  
  // Time remaining calculation
  const diffMs = deadlineDate.getTime() - now.getTime();
  const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
  const diffMinutes = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));

  let timeRemainingText = '';
  if (isDeadlinePassed) {
    timeRemainingText = 'انتهى آخر ميعاد للرد';
  } else if (diffHours > 24) {
    const days = Math.floor(diffHours / 24);
    timeRemainingText = `باقي ${days} يوم و ${diffHours % 24} ساعة`;
  } else if (diffHours > 0) {
    timeRemainingText = `باقي ${diffHours} ساعة و ${diffMinutes} دقيقة`;
  } else if (diffMinutes > 0) {
    timeRemainingText = `باقي ${diffMinutes} دقيقة فقط!`;
  } else {
    timeRemainingText = 'أقل من دقيقة متبقية';
  }

  // Cost calculations
  // Fixed: totalCost / requiredPlayers
  const fixedPerPlayer = Math.round(match.totalCost / match.requiredPlayers);
  
  // Live Estimate: totalCost / active players right now (minimum 1 to prevent division by 0)
  const activeCount = activePlayers.length;
  const liveEstimatedPerPlayer = activeCount > 0 
    ? Math.round(match.totalCost / activeCount) 
    : match.totalCost;

  // Formatting match date
  const matchDate = new Date(match.matchDateTime);
  const dateFormatted = matchDate.toLocaleDateString('ar-EG', {
    weekday: 'long',
    day: 'numeric',
    month: 'long'
  });
  const timeFormatted = matchDate.toLocaleTimeString('ar-EG', {
    hour: '2-digit',
    minute: '2-digit'
  });

  const deadlineFormatted = deadlineDate.toLocaleDateString('ar-EG', {
    weekday: 'short',
    day: 'numeric',
    month: 'short',
    hour: '2-digit',
    minute: '2-digit'
  });

  const spotsLeft = Math.max(0, match.requiredPlayers - activeCount);
  const isAtRisk = !match.isCompleted && (isDeadlinePassed || (diffHours <= 6 && spotsLeft > 2));

  const handleResponse = (status: ResponseStatus) => {
    if (isDeadlinePassed) {
      setErrorMessage('انتهى آخر ميعاد للرد على هذا الماتش ولا يمكن تغيير الرد.');
      setTimeout(() => setErrorMessage(null), 3500);
      return;
    }

    if (status === 'uncertain') {
      setShowUncertainModal(true);
      return;
    }

    const res = respondToMatch(match.id, status);
    if (!res.success) {
      setErrorMessage(res.message);
      setTimeout(() => setErrorMessage(null), 3500);
    }
  };

  const submitUncertainWithReason = (reasonText: string) => {
    if (!reasonText.trim()) return;
    const res = respondToMatch(match.id, 'uncertain', reasonText.trim());
    if (!res.success) {
      setErrorMessage(res.message);
      setTimeout(() => setErrorMessage(null), 3500);
    }
    setShowUncertainModal(false);
    setUncertainReasonInput('');
  };

  return (
    <article className="bg-neutral-900 border border-neutral-800 rounded-3xl overflow-hidden shadow-xl mb-4 transition-all">
      {/* Post Header: Creator info + Group + Admin action */}
      <div className="p-3.5 pb-2 flex items-center justify-between border-b border-neutral-800/60 bg-neutral-900/60">
        <div className="flex items-center gap-2.5">
          <button 
            onClick={() => onViewUserProfile(match.creatorId)}
            className="w-10 h-10 rounded-full overflow-hidden border border-neutral-700 ring-2 ring-emerald-500/20 active:scale-95 transition-transform"
          >
            <img 
              src={match.creatorAvatar} 
              alt={match.creatorName} 
              className="w-full h-full object-cover" 
              referrerPolicy="no-referrer"
            />
          </button>
          <div>
            <div className="flex items-center gap-1.5">
              <button 
                onClick={() => onViewUserProfile(match.creatorId)}
                className="text-xs font-bold text-white hover:text-emerald-400 transition-colors text-right"
              >
                {match.creatorName}
              </button>
              {match.creatorId === group?.creatorId && (
                <span className="text-[10px] px-1.5 py-0.2 rounded bg-amber-500/10 text-amber-400 border border-amber-500/20 font-semibold">
                  مؤسس الجروب
                </span>
              )}
            </div>
            <div className="flex items-center gap-2 text-[11px] text-neutral-400">
              <span>{group ? group.name : 'جروب كورة'}</span>
              <span>•</span>
              <span>{new Date(match.createdAt).toLocaleDateString('ar-EG', { month: 'short', day: 'numeric' })}</span>
            </div>
          </div>
        </div>

        {/* Match status badge & share & admin actions */}
        <div className="flex items-center gap-1.5">
          {/* Quick Share Match Button in Header */}
          <button
            onClick={() => setShowShareModal(true)}
            className="p-1.5 px-2.5 rounded-xl text-emerald-300 hover:text-white bg-emerald-500/10 hover:bg-emerald-500/20 border border-emerald-500/30 transition-all flex items-center gap-1 text-[11px] font-bold active:scale-95"
            title="مشاركة الماتش على واتساب أو برمز QR"
          >
            <Share2 className="w-3.5 h-3.5 text-emerald-400" />
            <span>مشاركة</span>
          </button>

          {match.isFinished ? (
            <span className="px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30 text-[11px] font-bold flex items-center gap-1">
              <Star className="w-3 h-3 fill-current" />
              انتهى الماتش 🏁
            </span>
          ) : match.isCompleted ? (
            <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 text-[11px] font-bold flex items-center gap-1">
              <CheckCircle2 className="w-3 h-3" />
              اكتمل ✅
            </span>
          ) : null}

          {isAdmin && (
            <button
              onClick={() => {
                if (window.confirm('هل تريد بالتأكيد حذف بوست هذا الحجز؟')) {
                  deleteMatchPost(match.id);
                }
              }}
              className="p-1.5 rounded-lg text-neutral-400 hover:text-rose-400 hover:bg-neutral-800 transition-colors"
              title="حذف البوست (صلاحية أدمن)"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      <div className="p-3.5 space-y-3">
        {/* ========================================================================= */}
        {/* 1. كارت الميعاد (منفصل، بلون مميز - أزرق نيلي رياضي فاخر) */}
        {/* ========================================================================= */}
        <div className="rounded-2xl p-3.5 bg-gradient-to-br from-blue-950/80 via-indigo-950/70 to-slate-900 border border-blue-500/30 text-white shadow-md relative overflow-hidden">
          <div className="absolute top-0 left-0 px-2 py-0.5 rounded-br-xl bg-blue-500/20 border-r border-b border-blue-400/20 text-[10px] font-bold text-blue-300">
            كارت الميعاد والملعب 🏟️
          </div>

          <div className="mt-1 space-y-2.5">
            {/* Pitch Name & Location */}
            <div>
              <h3 className="text-base font-bold font-display text-blue-100 flex items-center gap-1.5">
                <MapPin className="w-4 h-4 text-blue-400 shrink-0" />
                <span>{match.pitchName}</span>
              </h3>
              {match.pitchLocationText && (
                <p className="text-xs text-blue-200/80 mt-0.5 pr-5 leading-relaxed">
                  {match.pitchLocationText}
                </p>
              )}
            </div>

            {/* Date & Time and Duration */}
            <div className="grid grid-cols-2 gap-2 pt-1 border-t border-blue-500/20">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-lg bg-blue-500/20 flex items-center justify-center shrink-0">
                  <Clock className="w-4 h-4 text-blue-300" />
                </div>
                <div>
                  <div className="text-[10px] text-blue-300 font-medium">ميعاد الماتش</div>
                  <div className="text-xs font-bold text-white">{dateFormatted}</div>
                  <div className="text-[11px] text-blue-200 font-semibold">{timeFormatted}</div>
                </div>
              </div>

              <div className="flex items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <div className="w-7 h-7 rounded-lg bg-blue-500/20 flex items-center justify-center shrink-0">
                    <Users className="w-4 h-4 text-blue-300" />
                  </div>
                  <div>
                    <div className="text-[10px] text-blue-300 font-medium">العدد المطلوب</div>
                    <div className="text-xs font-bold text-white flex items-center gap-1.5">
                      <span>{match.requiredPlayers} لاعب</span>
                      {(match.creatorId === currentUser.id || isAdmin) && !match.isFinished && (
                        <button
                          type="button"
                          onClick={() => {
                            setEditingPlayersCount(match.requiredPlayers);
                            setShowEditPlayersModal(true);
                          }}
                          className="px-1.5 py-0.5 rounded bg-blue-500/20 hover:bg-blue-500/40 text-blue-300 text-[10px] font-medium flex items-center gap-0.5 transition-colors border border-blue-400/30"
                          title="تعديل عدد اللاعبين تحريرياً"
                        >
                          <Edit3 className="w-2.5 h-2.5" />
                          <span>تعديل</span>
                        </button>
                      )}
                    </div>
                    <span className="text-[10px] font-normal text-blue-200 block">
                      ({match.durationHours} ساعة - {match.hourlyRate} ج/س)
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* Rules / Notes */}
            {match.notes && (
              <div className="bg-blue-900/30 rounded-xl p-2.5 border border-blue-500/20 text-xs text-blue-100/90 leading-relaxed whitespace-pre-line">
                <div className="text-[10px] font-bold text-blue-300 mb-1 flex items-center gap-1">
                  <Info className="w-3 h-3" />
                  قواعد وملاحظات الماتش:
                </div>
                {match.notes}
              </div>
            )}
          </div>
        </div>

        {/* ========================================================================= */}
        {/* 2. كارت الفلوس (منفصل، بلون مميز - أخضر زمردي جذاب، برقمين مفصولين بخط) */}
        {/* ========================================================================= */}
        <div className="rounded-2xl p-3.5 bg-gradient-to-br from-emerald-950/80 via-teal-950/70 to-neutral-900 border border-emerald-500/30 text-white shadow-md relative overflow-hidden">
          <div className="flex items-center justify-between mb-2">
            <span className="inline-flex items-center gap-1 text-xs font-bold text-emerald-400">
              <Banknote className="w-4 h-4" />
              كارت الفلوس وحسبة الفرد 💵
            </span>
            <span className="text-[10px] text-emerald-200/70">
              إجمالي الملعب: <strong className="text-emerald-300 font-mono">{match.totalCost}</strong> ج.م
            </span>
          </div>

          {/* Two numbers separated by a vertical divider */}
          <div className="grid grid-cols-2 rounded-xl bg-neutral-950/60 border border-emerald-500/20 p-2.5 divide-x divide-x-reverse divide-emerald-500/20 text-center">
            {/* Number 1: Fixed cost per player */}
            <div className="px-2">
              <span className="text-[10px] text-neutral-400 block font-medium">
                ثابت عند الاكتمال
              </span>
              <div className="text-xl font-black font-display text-emerald-400 tracking-tight my-0.5">
                {fixedPerPlayer} <span className="text-xs font-normal">ج.م</span>
              </div>
              <span className="text-[9px] text-neutral-400 leading-none block">
                (إجمالي التكلفة ÷ {match.requiredPlayers} لاعب)
              </span>
            </div>

            {/* Number 2: Live estimated cost */}
            <div className="px-2">
              <span className="text-[10px] text-neutral-400 block font-medium flex items-center justify-center gap-1">
                تقديري لايف حالياً
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
              </span>
              <div className="text-xl font-black font-display text-teal-300 tracking-tight my-0.5">
                {liveEstimatedPerPlayer} <span className="text-xs font-normal">ج.م</span>
              </div>
              <span className="text-[9px] text-neutral-400 leading-none block">
                (حسب {activeCount} لاعب قالوا هلعب)
              </span>
            </div>
          </div>

          <p className="text-[10px] text-emerald-200/60 text-center mt-2">
            * رقم استرشادي لتسهيل الحساب بين الصحاب، بدون دفع إلكتروني فعلي
          </p>
        </div>

        {/* ========================================================================= */}
        {/* 3. كارت "آخر ميعاد للرد" (منفصل، بلون بارز - كهرماني / برتقالي واضح) */}
        {/* ========================================================================= */}
        <div className={`rounded-2xl p-3 border shadow-md relative overflow-hidden transition-all ${
          isAtRisk 
            ? 'bg-gradient-to-br from-rose-950/90 via-amber-950/80 to-neutral-900 border-rose-500/50' 
            : 'bg-gradient-to-br from-amber-950/80 via-orange-950/70 to-neutral-900 border-amber-500/40'
        }`}>
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <div className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 ${
                isAtRisk ? 'bg-rose-500/20 text-rose-400' : 'bg-amber-500/20 text-amber-400'
              }`}>
                <Hourglass className="w-4 h-4 animate-spin-slow" />
              </div>
              <div>
                <div className="flex items-center gap-1.5">
                  <span className="text-xs font-bold text-amber-200">
                    آخر ميعاد للرد:
                  </span>
                  <span className="text-xs font-black text-white">
                    {deadlineFormatted}
                  </span>
                </div>
                <div className={`text-[11px] font-semibold mt-0.5 ${
                  isDeadlinePassed ? 'text-rose-400 font-bold' : 'text-amber-300'
                }`}>
                  {timeRemainingText}
                </div>
              </div>
            </div>

            {/* Status Indicator Pill */}
            {isAtRisk && (
              <span className="px-2 py-1 rounded-lg bg-rose-500/20 text-rose-300 border border-rose-500/30 text-[10px] font-bold animate-pulse text-center shrink-0">
                ⚠️ مهدد بالإلغاء
              </span>
            )}
          </div>

          {isAtRisk && (
            <p className="text-[11px] text-rose-200/90 mt-2 bg-rose-950/50 p-2 rounded-lg border border-rose-500/20 leading-relaxed">
              ⚠️ تنبيه: آخر ميعاد للرد قارب على الانتهاء أو انتهى والعدد لسه منكملش ({activeCount} من {match.requiredPlayers} فقط).
            </p>
          )}
        </div>

        {/* ========================================================================= */}
        {/* بنر مشاركة الماتش ودعوة الصحاب (واتساب + QR) */}
        {/* ========================================================================= */}
        <div className="p-2.5 rounded-2xl bg-gradient-to-r from-emerald-950/70 via-neutral-900 to-teal-950/60 border border-emerald-500/30 shadow-md flex items-center justify-between gap-2">
          <div className="flex items-center gap-2 min-w-0">
            <div className="w-8 h-8 rounded-xl bg-emerald-500/20 border border-emerald-500/30 text-emerald-400 flex items-center justify-center shrink-0">
              <Share2 className="w-4 h-4" />
            </div>
            <div className="truncate text-right">
              <span className="text-xs font-bold text-white block truncate">
                ادعُ شلتك واقفل العدد ⚽
              </span>
              <span className="text-[10px] text-emerald-300/80 block truncate">
                مشاركة مباشرة على واتساب أو كود QR سريع للملعب
              </span>
            </div>
          </div>
          <button
            onClick={() => setShowShareModal(true)}
            className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 active:scale-95 text-white text-xs font-bold flex items-center gap-1.5 shadow-md shadow-emerald-950 transition-all shrink-0"
          >
            <Share2 className="w-3.5 h-3.5" />
            <span>مشاركة الماتش</span>
          </button>
        </div>

        {/* Error message toast if response fails */}
        {errorMessage && (
          <div className="p-2.5 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-1.5">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{errorMessage}</span>
          </div>
        )}

        {/* ========================================================================= */}
        {/* بنر تقييم الأعضاء بعد انتهاء الماتش (Rating & Evaluation Banner) */}
        {/* ========================================================================= */}
        {match.isFinished ? (
          <div className="p-3.5 rounded-2xl bg-gradient-to-r from-amber-500/20 via-neutral-900 to-amber-500/10 border border-amber-500/40 space-y-2 shadow-lg shadow-amber-950/20">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center shrink-0 border border-amber-500/30">
                  <Star className="w-5 h-5 fill-current" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-white flex items-center gap-1">
                    <span>انتهى الماتش! قيّم زمايلك 🏆⭐</span>
                  </h4>
                  <p className="text-[10px] text-neutral-300">
                    قيّم التزام ومستوى اللعيبة اللي حضروا الماتش
                  </p>
                </div>
              </div>
              <button
                onClick={() => {
                  setSelectedPlayerToRate(undefined);
                  setShowRateModal(true);
                }}
                className="px-3.5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 active:scale-95 text-neutral-950 font-bold text-xs shadow-md shadow-amber-500/20 transition-all flex items-center gap-1.5 shrink-0"
              >
                <Star className="w-3.5 h-3.5 fill-current" />
                <span>تقييم اللعيبة</span>
              </button>
            </div>
          </div>
        ) : (isAdmin || match.creatorId === currentUser.id) && match.isCompleted ? (
          <div className="p-3 rounded-2xl bg-neutral-900 border border-amber-500/30 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="text-sm">🏁</span>
              <div>
                <div className="text-xs font-bold text-white">الماتش اتلعب خلاص؟</div>
                <div className="text-[10px] text-neutral-400">تقدر تنهي الماتش وتفتح تقييم اللعيبة بالنجوم</div>
              </div>
            </div>
            <button
              onClick={() => markMatchAsFinished(match.id)}
              className="px-3 py-1.5 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 text-xs font-bold transition-all flex items-center gap-1"
            >
              <Star className="w-3.5 h-3.5 fill-current" />
              <span>إنهاء وبدء التقييم ⭐</span>
            </button>
          </div>
        ) : null}

        {/* ========================================================================= */}
        {/* 4. أزرار التفاعل مع البوست (✅ هلعب / ❌ مش هقدر / 🤔 لسه مش متأكد) */}
        {/* ========================================================================= */}
        <div className="pt-1">
          <div className="text-[11px] font-semibold text-neutral-400 mb-2 flex items-center justify-between">
            <span>ردك على الماتش:</span>
            {myResponse && (
              <span className="text-neutral-300">
                ردك الحالي: <strong className="text-emerald-400">
                  {myResponse.status === 'playing' ? (myResponse.isWaitlist ? `قائمة انتظار (#${myResponse.waitlistIndex})` : '✅ هلعب') : myResponse.status === 'declined' ? '❌ مش هقدر' : '🤔 مش متأكد'}
                </strong>
              </span>
            )}
          </div>

          <div className="grid grid-cols-3 gap-2">
            {/* 1: ✅ هلعب */}
            <button
              onClick={() => handleResponse('playing')}
              disabled={isDeadlinePassed}
              className={`min-h-[46px] rounded-xl flex flex-col items-center justify-center p-1.5 font-bold text-xs transition-all active:scale-95 ${
                myResponse?.status === 'playing'
                  ? 'bg-emerald-600 text-white ring-2 ring-emerald-400 shadow-lg shadow-emerald-950'
                  : 'bg-neutral-800 hover:bg-neutral-750 text-neutral-200 border border-neutral-700'
              } ${isDeadlinePassed ? 'opacity-50 cursor-not-allowed' : ''}`}
            >
              <div className="flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                <span>هلعب</span>
              </div>
              <span className="text-[10px] font-normal text-neutral-300 mt-0.5">
                ({activePlayers.length}
                {waitlistPlayers.length > 0 ? ` + ${waitlistPlayers.length} انتظار` : ''})
              </span>
            </button>

            {/* 2: ❌ مش هقدر */}
            <button
              onClick={() => handleResponse('declined')}
              disabled={isDeadlinePassed}
              className={`min-h-[46px] rounded-xl flex flex-col items-center justify-center p-1.5 font-bold text-xs transition-all active:scale-95 ${
                myResponse?.status === 'declined'
                  ? 'bg-rose-700 text-white ring-2 ring-rose-400 shadow-lg shadow-rose-950'
                  : 'bg-neutral-800 hover:bg-neutral-750 text-neutral-200 border border-neutral-700'
              } ${isDeadlinePassed ? 'opacity-50 cursor-not-allowed' : ''}`}
            >
              <div className="flex items-center gap-1">
                <XCircle className="w-3.5 h-3.5 text-rose-400" />
                <span>مش هقدر</span>
              </div>
              <span className="text-[10px] font-normal text-neutral-300 mt-0.5">
                ({declinedPlayers.length})
              </span>
            </button>

            {/* 3: 🤔 لسه مش متأكد */}
            <button
              onClick={() => handleResponse('uncertain')}
              disabled={isDeadlinePassed}
              className={`min-h-[46px] rounded-xl flex flex-col items-center justify-center p-1.5 font-bold text-xs transition-all active:scale-95 ${
                myResponse?.status === 'uncertain'
                  ? 'bg-amber-600 text-white ring-2 ring-amber-400 shadow-lg shadow-amber-950'
                  : 'bg-neutral-800 hover:bg-neutral-750 text-neutral-200 border border-neutral-700'
              } ${isDeadlinePassed ? 'opacity-50 cursor-not-allowed' : ''}`}
            >
              <div className="flex items-center gap-1">
                <HelpCircle className="w-3.5 h-3.5 text-amber-400" />
                <span>مش متأكد</span>
              </div>
              <span className="text-[10px] font-normal text-neutral-300 mt-0.5">
                ({uncertainPlayers.length})
              </span>
            </button>
          </div>
        </div>

        {/* ========================================================================= */}
        {/* 5. عرض التشكيل وقائمة الانتظار (Expandable Roster & Waitlist) */}
        {/* ========================================================================= */}
        <div className="pt-2 border-t border-neutral-800/80">
          <button
            onClick={() => setIsRosterExpanded(!isRosterExpanded)}
            className="w-full flex items-center justify-between p-2 rounded-xl bg-neutral-800/50 hover:bg-neutral-800 text-xs font-medium text-neutral-300 transition-colors"
          >
            <div className="flex items-center gap-2">
              <span className="font-bold text-white">
                التشكيل والردود ({activePlayers.length}/{match.requiredPlayers})
              </span>
              {waitlistPlayers.length > 0 && (
                <span className="px-1.5 py-0.5 rounded bg-blue-500/20 text-blue-300 text-[10px] font-bold">
                  {waitlistPlayers.length} في الـ Waitlist
                </span>
              )}
            </div>
            <div className="flex items-center gap-1 text-[11px] text-neutral-400">
              <span>{isRosterExpanded ? 'إخفاء' : 'عرض التفاصيل'}</span>
              {isRosterExpanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
            </div>
          </button>

          {/* Roster details breakdown */}
          {isRosterExpanded && (
            <div className="mt-2 space-y-3 p-2 bg-neutral-950/60 rounded-xl border border-neutral-800 text-xs animate-in fade-in duration-200">
              {/* Active playing players */}
              <div>
                <div className="text-[11px] font-bold text-emerald-400 mb-1.5 flex items-center justify-between">
                  <span>✅ اللاعبين الأساسيين ({activePlayers.length}/{match.requiredPlayers}):</span>
                  {spotsLeft > 0 ? (
                    <span className="text-[10px] text-amber-400">باقي {spotsLeft} لاعبين</span>
                  ) : (
                    <span className="text-[10px] text-emerald-400 font-bold">اكتمل التشكيل</span>
                  )}
                </div>

                {activePlayers.length === 0 ? (
                  <p className="text-[11px] text-neutral-500 py-1">محدش سجل لسه، كون أول واحد!</p>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
                    {activePlayers.map((resp, idx) => {
                      const user = getUserById(resp.userId);
                      const userStats = resp.userId ? getUserRatingStats(resp.userId) : null;
                      const hasRated = hasRatedPlayerInMatch(match.id, resp.userId);
                      const canRate = (match.isFinished || match.isCompleted) && resp.userId !== currentUser.id;

                      const posStyle = getPositionStyle(user?.position);

                      return (
                        <div
                          key={resp.userId}
                          className={`flex items-center justify-between p-1.5 rounded-xl border text-right group transition-all ${posStyle.cardBg} ${posStyle.cardBorder}`}
                        >
                          <button
                            onClick={() => onViewUserProfile(resp.userId)}
                            className="flex items-center gap-2 truncate flex-1 min-w-0"
                          >
                            <span className="w-4 h-4 rounded-full bg-emerald-500/20 text-emerald-400 text-[10px] font-bold flex items-center justify-center shrink-0">
                              {idx + 1}
                            </span>
                            <div className="relative shrink-0">
                              <img
                                src={user?.avatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100'}
                                alt={user?.name}
                                className={`w-6 h-6 rounded-full object-cover shrink-0 ${posStyle.avatarRing}`}
                                referrerPolicy="no-referrer"
                              />
                            </div>
                            <span className="text-xs font-semibold text-neutral-100 group-hover:text-emerald-300 transition-colors truncate">
                              {user?.name || 'لاعب'}
                            </span>
                            {userStats && (
                              <span className="text-[10px] text-amber-400 font-bold flex items-center gap-0.5 shrink-0">
                                <Star className="w-2.5 h-2.5 fill-current" />
                                <span>{userStats.averageOverall}</span>
                              </span>
                            )}
                          </button>

                          <div className="flex items-center gap-1.5 shrink-0">
                            <span className={`text-[10px] px-1.5 py-0.5 rounded border font-semibold ${posStyle.badgeBg}`}>
                              {posStyle.roleIcon} {user?.position?.split(' ')[0] || 'لاعب'}
                            </span>
                            {canRate && (
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setSelectedPlayerToRate(resp.userId);
                                  setShowRateModal(true);
                                }}
                                className={`px-2 py-0.5 rounded-md text-[10px] font-bold border transition-colors flex items-center gap-0.5 ${
                                  hasRated
                                    ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20'
                                    : 'bg-amber-500/15 hover:bg-amber-500/25 text-amber-300 border-amber-500/30'
                                }`}
                              >
                                <Star className="w-2.5 h-2.5 fill-current" />
                                <span>{hasRated ? 'تم ✓' : 'قيّم'}</span>
                              </button>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>

              {/* Waitlist (Specification 5) */}
              {waitlistPlayers.length > 0 && (
                <div className="pt-2 border-t border-neutral-800/80">
                  <div className="text-[11px] font-bold text-blue-400 mb-1.5 flex items-center justify-between">
                    <span>⏳ قائمة الانتظار (Waitlist):</span>
                    <span className="text-[10px] text-neutral-400">بيدخلوا أوتوماتيك لو حد اعتذر</span>
                  </div>
                  <div className="space-y-1">
                    {waitlistPlayers.map((resp) => {
                      const user = getUserById(resp.userId);
                      return (
                        <button
                          key={resp.userId}
                          onClick={() => onViewUserProfile(resp.userId)}
                          className="w-full flex items-center justify-between p-1.5 rounded-lg bg-blue-950/30 hover:bg-blue-900/40 border border-blue-500/30 text-right group transition-colors"
                        >
                          <div className="flex items-center gap-2 truncate">
                            <span className="px-1.5 py-0.5 rounded bg-blue-500/20 text-blue-300 text-[10px] font-mono font-bold shrink-0">
                              #{resp.waitlistIndex || 1} في الانتظار
                            </span>
                            <img
                              src={user?.avatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100'}
                              alt={user?.name}
                              className="w-6 h-6 rounded-full object-cover shrink-0"
                              referrerPolicy="no-referrer"
                            />
                            <span className="text-xs font-medium text-blue-200 group-hover:text-white truncate">
                              {user?.name || 'لاعب منتظر'}
                            </span>
                          </div>
                          <span className="text-[10px] text-neutral-400 shrink-0">
                            {user?.position?.split(' ')[0]}
                          </span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Uncertain players with REASONS (Specification 4: 🤔 لسه مش متأكد → لازم يكتب السبب) */}
              {uncertainPlayers.length > 0 && (
                <div className="pt-2 border-t border-neutral-800/80">
                  <div className="text-[11px] font-bold text-amber-400 mb-1.5">
                    🤔 لسه مش متأكدين ({uncertainPlayers.length}):
                  </div>
                  <div className="space-y-1">
                    {uncertainPlayers.map((resp) => {
                      const user = getUserById(resp.userId);
                      return (
                        <div
                          key={resp.userId}
                          className="p-2 rounded-lg bg-neutral-900/90 border border-amber-500/20 text-right"
                        >
                          <div className="flex items-center justify-between">
                            <button
                              onClick={() => onViewUserProfile(resp.userId)}
                              className="flex items-center gap-1.5 text-xs font-semibold text-neutral-200 hover:text-amber-300"
                            >
                              <img
                                src={user?.avatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100'}
                                alt={user?.name}
                                className="w-5 h-5 rounded-full object-cover"
                                referrerPolicy="no-referrer"
                              />
                              <span>{user?.name}</span>
                            </button>
                            <span className="text-[10px] text-neutral-500">
                              {new Date(resp.timestamp).toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' })}
                            </span>
                          </div>
                          {resp.uncertainReason && (
                            <p className="text-[11px] text-amber-200/90 mt-1 bg-amber-950/40 p-1.5 rounded border border-amber-500/10">
                              💬 السبب: "{resp.uncertainReason}"
                            </p>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Declined players */}
              {declinedPlayers.length > 0 && (
                <div className="pt-2 border-t border-neutral-800/80">
                  <div className="text-[11px] font-bold text-neutral-400 mb-1">
                    ❌ اعتذروا عن الماتش ({declinedPlayers.length}):
                  </div>
                  <div className="flex flex-wrap gap-1.5">
                    {declinedPlayers.map((resp) => {
                      const user = getUserById(resp.userId);
                      return (
                        <button
                          key={resp.userId}
                          onClick={() => onViewUserProfile(resp.userId)}
                          className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 text-[11px] text-neutral-400"
                        >
                          <span>{user?.name}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* ========================================================================= */}
      {/* Modal: سبب عدم التأكد (Required when clicking 'مش متأكد') */}
      {/* ========================================================================= */}
      {showUncertainModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4 animate-in fade-in duration-150">
          <div className="w-full max-w-sm bg-neutral-900 border border-neutral-700 rounded-t-3xl sm:rounded-3xl p-4 shadow-2xl">
            <div className="w-10 h-1 bg-neutral-700 rounded-full mx-auto mb-3" />
            
            <div className="flex items-center gap-2 mb-2">
              <div className="w-8 h-8 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center">
                <HelpCircle className="w-4 h-4" />
              </div>
              <div>
                <h4 className="text-sm font-bold text-white">إيه سبب عدم التأكد يا كابتن؟</h4>
                <p className="text-[11px] text-neutral-400">لازم تكتب سبب عشان المنظمين والشباب يعرفوا ظروفك</p>
              </div>
            </div>

            {/* Quick suggested excuses */}
            <div className="my-3 space-y-1.5">
              <p className="text-[10px] text-neutral-400 font-semibold">أسباب شائعة جاهزة للاختيار السريع:</p>
              <div className="flex flex-wrap gap-1.5">
                {[
                  'مستني تأكيد مواعيد الشغل',
                  'عندي شد عضلي خفيف وبجرب أتمرن',
                  'ممكن اتأخر نص ساعة عن الميعاد',
                  'مرتبط بمشوار عائلي وبحاول أفضى'
                ].map((sug) => (
                  <button
                    key={sug}
                    onClick={() => setUncertainReasonInput(sug)}
                    className="text-[11px] px-2 py-1 rounded-lg bg-neutral-800 hover:bg-neutral-750 text-neutral-300 border border-neutral-700 text-right transition-colors"
                  >
                    {sug}
                  </button>
                ))}
              </div>
            </div>

            {/* Custom Input */}
            <div className="mb-4">
              <textarea
                value={uncertainReasonInput}
                onChange={(e) => setUncertainReasonInput(e.target.value)}
                placeholder="اكتب سببك هنا بالتفصيل..."
                rows={3}
                className="w-full bg-neutral-950 border border-neutral-700 focus:border-amber-500 rounded-xl p-2.5 text-xs text-white placeholder-neutral-500 outline-none resize-none"
              />
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => submitUncertainWithReason(uncertainReasonInput)}
                disabled={!uncertainReasonInput.trim()}
                className="flex-1 py-2.5 rounded-xl bg-amber-600 hover:bg-amber-500 disabled:opacity-50 text-white font-bold text-xs transition-colors flex items-center justify-center gap-1"
              >
                <span>تأكيد وتسجيل الرد</span>
              </button>
              <button
                onClick={() => setShowUncertainModal(false)}
                className="py-2.5 px-4 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-300 font-medium text-xs transition-colors"
              >
                إلغاء
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* Modal: تعديل عدد اللاعبين تحريرياً (صاحب البوست أو الأدمن) */}
      {/* ========================================================================= */}
      {showEditPlayersModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-sm bg-neutral-900 border border-neutral-800 rounded-3xl p-5 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between pb-2 border-b border-neutral-800">
              <div className="flex items-center gap-2">
                <Users className="w-5 h-5 text-emerald-400" />
                <h3 className="text-sm font-bold text-white">تعديل عدد اللاعبين تحريرياً</h3>
              </div>
              <button
                onClick={() => setShowEditPlayersModal(false)}
                className="w-7 h-7 rounded-full bg-neutral-800 hover:bg-neutral-700 text-neutral-400 hover:text-white flex items-center justify-center transition-colors"
              >
                ✕
              </button>
            </div>

            <p className="text-xs text-neutral-400">
              اكتب العدد المطلوب الجديد للماتش، وسيتم تحديث الحسبة وقائمة الاحتياطي/الأساسي تلقائياً:
            </p>

            {/* Stepper + Input */}
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setEditingPlayersCount(prev => Math.max(2, (Number(prev) || 0) - 1))}
                className="w-10 h-10 rounded-xl bg-neutral-800 hover:bg-neutral-750 text-white font-bold text-lg flex items-center justify-center transition-all shrink-0"
              >
                -
              </button>
              <div className="relative flex-1">
                <input
                  type="number"
                  min="2"
                  max="40"
                  value={editingPlayersCount || ''}
                  onChange={(e) => {
                    const val = parseInt(e.target.value, 10);
                    setEditingPlayersCount(isNaN(val) ? 0 : val);
                  }}
                  className="w-full h-11 bg-neutral-950 border border-neutral-700 focus:border-emerald-500 rounded-xl px-3 text-center text-base font-bold text-white font-mono outline-none"
                  placeholder="عدد اللاعبين..."
                />
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-xs text-neutral-400 pointer-events-none">
                  لاعب
                </span>
              </div>
              <button
                type="button"
                onClick={() => setEditingPlayersCount(prev => Math.min(40, (Number(prev) || 0) + 1))}
                className="w-10 h-10 rounded-xl bg-neutral-800 hover:bg-neutral-750 text-white font-bold text-lg flex items-center justify-center transition-all shrink-0"
              >
                +
              </button>
            </div>

            {/* Quick shortcuts */}
            <div className="flex items-center justify-center gap-1.5 pt-1">
              {[8, 10, 12, 14, 16].map(num => (
                <button
                  key={num}
                  type="button"
                  onClick={() => setEditingPlayersCount(num)}
                  className={`px-2.5 py-1 rounded-lg text-xs font-bold border transition-colors ${
                    editingPlayersCount === num
                      ? 'bg-emerald-600 text-white border-emerald-500'
                      : 'bg-neutral-800 hover:bg-neutral-750 text-neutral-300 border-neutral-700'
                  }`}
                >
                  {num}
                </button>
              ))}
            </div>

            <div className="p-2 rounded-xl bg-neutral-950/80 border border-neutral-800 text-[11px] text-neutral-400 space-y-1">
              <div className="flex justify-between">
                <span>التكلفة للفرد بعد التعديل:</span>
                <span className="font-mono font-bold text-emerald-400">
                  {editingPlayersCount > 0 ? Math.round(match.totalCost / editingPlayersCount) : 0} ج.م
                </span>
              </div>
            </div>

            <div className="flex items-center gap-2 pt-1">
              <button
                type="button"
                onClick={() => {
                  const newCount = Number(editingPlayersCount);
                  if (newCount >= 2) {
                    updateMatchPost(match.id, { requiredPlayers: newCount });
                    setShowEditPlayersModal(false);
                  }
                }}
                className="flex-1 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-md transition-colors"
              >
                حفظ التعديل
              </button>
              <button
                type="button"
                onClick={() => setShowEditPlayersModal(false)}
                className="px-4 py-2.5 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-300 text-xs font-semibold transition-colors"
              >
                إلغاء
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* Modal: تقييم الأعضاء بعد الماتش (Post-match Player Rating Modal) */}
      {/* ========================================================================= */}
      {showRateModal && (
        <RatePlayerModal
          matchId={match.id}
          matchTitle={match.pitchName}
          targetUserId={selectedPlayerToRate}
          participantUserIds={activePlayers.map(p => p.userId)}
          onClose={() => {
            setShowRateModal(false);
            setSelectedPlayerToRate(undefined);
          }}
        />
      )}

      {/* ========================================================================= */}
      {/* Modal: مشاركة الماتش (واتساب + QR) */}
      {/* ========================================================================= */}
      {showShareModal && (
        <ShareModal
          isOpen={showShareModal}
          onClose={() => setShowShareModal(false)}
          type="match"
          match={match}
          group={group}
        />
      )}
    </article>
  );
};
