import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Group } from '../types';
import { 
  Users, 
  Plus, 
  Globe, 
  Lock, 
  ShieldCheck, 
  UserCheck, 
  UserPlus, 
  Check, 
  X, 
  Copy, 
  Share2, 
  ChevronLeft,
  Search,
  Sparkles,
  Trophy,
  QrCode
} from 'lucide-react';
import { ShareModal } from './ShareModal';
import { getPositionStyle, POSITION_LEGEND } from '../utils/positionColors';

interface GroupsViewProps {
  onViewUserProfile: (userId: string) => void;
}

export const GroupsView: React.FC<GroupsViewProps> = ({ onViewUserProfile }) => {
  const { 
    currentUser, 
    groups, 
    createGroup, 
    toggleAdminRole, 
    joinRequests, 
    requestToJoinGroup, 
    handleJoinRequest,
    isUserGroupAdmin, 
    isUserGroupMember,
    getUserById,
    setSelectedGroup,
    setActiveTab
  } = useApp();

  const [activeSubTab, setActiveSubTab] = useState<'my_groups' | 'explore' | 'requests'>('my_groups');
  const [selectedGroupDetail, setSelectedGroupDetail] = useState<Group | null>(null);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [shareGroupTarget, setShareGroupTarget] = useState<Group | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [copiedCode, setCopiedCode] = useState(false);
  const [memberPositionFilter, setMemberPositionFilter] = useState<string>('all');

  // Filter groups
  const myGroups = groups.filter(g => isUserGroupMember(g.id) && (!searchQuery || g.name.toLowerCase().includes(searchQuery.toLowerCase()) || g.description.toLowerCase().includes(searchQuery.toLowerCase())));
  const publicExploreGroups = groups.filter(g => g.isPublic && (!searchQuery || g.name.toLowerCase().includes(searchQuery.toLowerCase()) || g.description.toLowerCase().includes(searchQuery.toLowerCase())));

  // Pending requests for groups where current user is admin
  const adminGroupIds = groups.filter(g => isUserGroupAdmin(g.id)).map(g => g.id);
  const pendingRequestsForMe = joinRequests.filter(r => adminGroupIds.includes(r.groupId) && r.status === 'pending');

  // Create group form state
  const [newGroupName, setNewGroupName] = useState('');
  const [newGroupDesc, setNewGroupDesc] = useState('');
  const [newGroupIsPublic, setNewGroupIsPublic] = useState(true);

  const handleCreateGroupSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newGroupName.trim()) return;

    const created = createGroup(newGroupName.trim(), newGroupDesc.trim(), newGroupIsPublic);
    setShowCreateModal(false);
    setNewGroupName('');
    setNewGroupDesc('');
    setSelectedGroupDetail(created);
  };

  const copyInvite = (code: string) => {
    navigator.clipboard?.writeText?.(`https://koretna.app/join/${code}`);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  return (
    <div className="space-y-3 pb-8">
      {/* Sub Tabs: My Groups / Explore / Pending Requests */}
      <div className="flex items-center gap-1.5 p-1 bg-neutral-900/90 border border-neutral-800 rounded-2xl shadow-sm">
        <button
          onClick={() => setActiveSubTab('my_groups')}
          className={`flex-1 py-2 text-xs rounded-xl transition-all ${
            activeSubTab === 'my_groups'
              ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow-md shadow-emerald-950 font-black'
              : 'text-neutral-400 hover:text-neutral-200 font-semibold'
          }`}
        >
          جروباتي ({myGroups.length})
        </button>

        <button
          onClick={() => setActiveSubTab('explore')}
          className={`flex-1 py-2 text-xs rounded-xl transition-all ${
            activeSubTab === 'explore'
              ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow-md shadow-emerald-950 font-black'
              : 'text-neutral-400 hover:text-neutral-200 font-semibold'
          }`}
        >
          استكشاف الجروبات 🌍
        </button>

        {pendingRequestsForMe.length > 0 && (
          <button
            onClick={() => setActiveSubTab('requests')}
            className={`flex-1 py-2 text-xs rounded-xl relative transition-all ${
              activeSubTab === 'requests'
                ? 'bg-gradient-to-r from-rose-600 to-red-600 text-white shadow-md shadow-rose-950 font-black'
                : 'text-neutral-400 hover:text-neutral-200 font-semibold'
            }`}
          >
            الطلبات ({pendingRequestsForMe.length})
            <span className="w-2 h-2 rounded-full bg-rose-400 absolute top-2 right-2 animate-pulse" />
          </button>
        )}
      </div>

      {/* ========================================================================= */}
      {/* شريط البحث البارز بألوان مميزة وتفاعلية */}
      {/* ========================================================================= */}
      {(activeSubTab === 'my_groups' || activeSubTab === 'explore') && (
        <div className="relative group">
          <div className="relative flex items-center gap-2 p-1.5 pr-2.5 rounded-2xl bg-gradient-to-r from-neutral-900 via-neutral-900 to-neutral-950 border-2 border-emerald-500/50 hover:border-emerald-400 focus-within:border-emerald-400 focus-within:ring-4 focus-within:ring-emerald-500/25 shadow-xl shadow-emerald-950/40 transition-all duration-200">
            {/* Glowing background accent */}
            <div className="absolute -inset-0.5 bg-gradient-to-r from-emerald-500/20 via-teal-500/10 to-transparent rounded-2xl blur-sm -z-10 pointer-events-none opacity-70 group-hover:opacity-100 transition-opacity" />
            
            {/* Search Icon with Glowing Gradient Badge */}
            <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-emerald-500 to-teal-600 text-white flex items-center justify-center shadow-md shadow-emerald-950/60 shrink-0 ring-1 ring-white/20">
              <Search className="w-4 h-4 stroke-[2.5]" />
            </div>

            {/* Input field */}
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={activeSubTab === 'explore' ? "ابحث بالمنطقة أو المدينة (التجمع، المعادي...)" : "ابحث في جروباتك بالاسم..."}
              className="flex-1 bg-transparent text-xs text-white placeholder-neutral-400 outline-none font-semibold text-right"
            />

            {/* Clear Button */}
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="w-6 h-6 rounded-full bg-neutral-800 hover:bg-neutral-700 text-neutral-300 hover:text-white flex items-center justify-center transition-colors shrink-0"
                title="مسح البحث"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}

            {/* Match badge count */}
            {searchQuery && (
              <span className="text-[10px] font-black text-emerald-300 bg-emerald-500/20 border border-emerald-500/40 px-2 py-0.5 rounded-lg shrink-0 shadow-sm">
                {activeSubTab === 'my_groups' ? `${myGroups.length} جروب` : `${publicExploreGroups.length} جروب`}
              </span>
            )}
          </div>
        </div>
      )}

      {/* Main Action: Create Group CTA */}
      <div className="flex items-center justify-between">
        <h2 className="text-sm font-bold text-white font-display">
          {activeSubTab === 'my_groups' ? 'الجروبات المشترك فيها' : activeSubTab === 'explore' ? 'استكشاف جروبات كورة عامة' : 'طلبات الانضمام المعلقة'}
        </h2>
        <button
          onClick={() => setShowCreateModal(true)}
          className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold shadow-md shadow-emerald-950 transition-colors"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>إنشاء جروب جديد</span>
        </button>
      </div>

      {/* TAB 1: MY GROUPS */}
      {activeSubTab === 'my_groups' && (
        <div className="space-y-2.5">
          {myGroups.map(group => {
            const isAdmin = isUserGroupAdmin(group.id);
            const isCreator = group.creatorId === currentUser.id;

            return (
              <div
                key={group.id}
                className="p-3.5 rounded-2xl bg-neutral-900 border border-neutral-800 hover:border-neutral-700 transition-colors shadow-md flex items-center justify-between gap-3"
              >
                <div 
                  onClick={() => setSelectedGroupDetail(group)}
                  className="flex items-center gap-3 cursor-pointer min-w-0 flex-1"
                >
                  <img
                    src={group.avatar}
                    alt={group.name}
                    className="w-12 h-12 rounded-xl object-cover border border-neutral-700 shrink-0"
                    referrerPolicy="no-referrer"
                  />
                  <div className="min-w-0">
                    <div className="flex items-center gap-1.5 flex-wrap">
                      <h3 className="text-xs font-bold text-white truncate">{group.name}</h3>
                      {group.isPublic ? (
                        <span className="text-[10px] px-1.5 py-0.2 rounded bg-neutral-800 text-neutral-300 border border-neutral-700 flex items-center gap-0.5">
                          <Globe className="w-2.5 h-2.5" /> عام
                        </span>
                      ) : (
                        <span className="text-[10px] px-1.5 py-0.2 rounded bg-neutral-800 text-neutral-300 border border-neutral-700 flex items-center gap-0.5">
                          <Lock className="w-2.5 h-2.5" /> خاص
                        </span>
                      )}
                      {isAdmin && (
                        <span className="text-[10px] px-1.5 py-0.2 rounded bg-emerald-500/20 text-emerald-400 font-bold border border-emerald-500/30">
                          {isCreator ? 'المؤسس' : 'أدمن'}
                        </span>
                      )}
                    </div>
                    <p className="text-[11px] text-neutral-400 mt-1 line-clamp-1">
                      {group.description}
                    </p>
                    <span className="text-[10px] text-neutral-500 mt-1 block">
                      {group.members.length} أعضاء مسجلين
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-1.5 shrink-0">
                  <button
                    onClick={() => setShareGroupTarget(group)}
                    className="p-2 rounded-xl bg-neutral-800/80 hover:bg-neutral-800 text-neutral-300 hover:text-emerald-400 border border-neutral-700/80 transition-all flex items-center gap-1 text-xs font-semibold"
                    title="مشاركة الجروب على واتساب ورمز QR"
                  >
                    <QrCode className="w-3.5 h-3.5 text-emerald-400" />
                    <span className="hidden sm:inline">QR</span>
                  </button>
                  <button
                    onClick={() => {
                      setSelectedGroup(group);
                      setActiveTab('matches');
                    }}
                    className="px-2.5 py-1.5 rounded-lg bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-400 text-xs font-semibold transition-colors"
                  >
                    ماتشات الجروب
                  </button>
                  <button
                    onClick={() => setSelectedGroupDetail(group)}
                    className="p-1.5 rounded-lg text-neutral-400 hover:text-white hover:bg-neutral-800"
                    title="تفاصيل الجروب والأعضاء"
                  >
                    <ChevronLeft className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* TAB 2: EXPLORE PUBLIC GROUPS (Specification 2) */}
      {activeSubTab === 'explore' && (
        <div className="space-y-2.5">

          {publicExploreGroups.length === 0 ? (
            <div className="p-8 text-center bg-neutral-900 rounded-2xl border border-neutral-800 text-neutral-400 text-xs">
              مفيش جروبات عامة مطابقة لبحثك حالياً
            </div>
          ) : (
            publicExploreGroups.map(group => {
              const isMember = isUserGroupMember(group.id);
              const hasPendingReq = joinRequests.some(r => r.groupId === group.id && r.userId === currentUser.id && r.status === 'pending');

              return (
                <div
                  key={group.id}
                  className="p-3.5 rounded-2xl bg-neutral-900 border border-neutral-800 shadow-md flex items-center justify-between gap-3"
                >
                  <img
                    src={group.avatar}
                    alt={group.name}
                    className="w-12 h-12 rounded-xl object-cover border border-neutral-700 shrink-0"
                    referrerPolicy="no-referrer"
                  />
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-1.5">
                      <h3 className="text-xs font-bold text-white truncate">{group.name}</h3>
                      <span className="text-[10px] px-1.5 py-0.2 rounded bg-neutral-800 text-neutral-400 border border-neutral-700">
                        {group.members.length} عضو
                      </span>
                    </div>
                    <p className="text-[11px] text-neutral-400 mt-0.5 line-clamp-2">
                      {group.description}
                    </p>
                  </div>

                  <div className="shrink-0">
                    {isMember ? (
                      <button
                        onClick={() => {
                          setSelectedGroup(group);
                          setActiveTab('matches');
                        }}
                        className="px-3 py-1.5 rounded-lg bg-neutral-800 text-neutral-300 text-xs font-semibold"
                      >
                        أنت عضو بالفعل
                      </button>
                    ) : hasPendingReq ? (
                      <span className="px-2.5 py-1.5 rounded-lg bg-amber-500/10 text-amber-400 border border-amber-500/20 text-[11px] font-bold block text-center">
                        طلبك قيد المراجعة ⏳
                      </span>
                    ) : (
                      <button
                        onClick={() => requestToJoinGroup(group.id)}
                        className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition-colors flex items-center gap-1"
                      >
                        <UserPlus className="w-3.5 h-3.5" />
                        <span>طلب انضمام</span>
                      </button>
                    )}
                  </div>
                </div>
              );
            })
          )}
        </div>
      )}

      {/* TAB 3: PENDING JOIN REQUESTS (Specification 2: أي طلب انضمام لازم موافقة أدمن قبل ما يتفعل) */}
      {activeSubTab === 'requests' && (
        <div className="space-y-2">
          {pendingRequestsForMe.length === 0 ? (
            <div className="p-8 text-center bg-neutral-900 rounded-2xl border border-neutral-800 text-neutral-400 text-xs">
              مفيش أي طلبات انضمام معلقة حالياً
            </div>
          ) : (
            pendingRequestsForMe.map(req => {
              const requestingUser = getUserById(req.userId);
              const group = groups.find(g => g.id === req.groupId);

              return (
                <div
                  key={req.id}
                  className="p-3.5 rounded-2xl bg-neutral-900 border border-neutral-800 shadow-md flex items-center justify-between gap-3"
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <img
                      src={requestingUser?.avatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100'}
                      alt={requestingUser?.name}
                      className="w-10 h-10 rounded-full object-cover border border-neutral-700 shrink-0"
                      referrerPolicy="no-referrer"
                    />
                    <div className="min-w-0">
                      <button
                        onClick={() => onViewUserProfile(req.userId)}
                        className="text-xs font-bold text-white hover:text-emerald-400 truncate block text-right"
                      >
                        {requestingUser?.name}
                      </button>
                      <span className="text-[10px] text-emerald-400 block">
                        {requestingUser?.position}
                      </span>
                      <span className="text-[10px] text-neutral-400 block mt-0.5">
                        طلب انضمام إلى: <strong className="text-neutral-200">{group?.name}</strong>
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center gap-1.5 shrink-0">
                    <button
                      onClick={() => handleJoinRequest(req.id, true)}
                      className="p-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold flex items-center gap-1 transition-colors"
                      title="موافقة وقبول العضو في الجروب"
                    >
                      <Check className="w-3.5 h-3.5" />
                      <span>قبول</span>
                    </button>
                    <button
                      onClick={() => handleJoinRequest(req.id, false)}
                      className="p-2 rounded-xl bg-neutral-800 hover:bg-neutral-750 text-rose-400 text-xs font-bold transition-colors"
                      title="رفض الطلب"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              );
            })
          )}
        </div>
      )}

      {/* ========================================================================= */}
      {/* Group Detail Modal: Members & Admin Controls (Specification 2) */}
      {/* ========================================================================= */}
      {selectedGroupDetail && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4 animate-in fade-in duration-200">
          <div className="w-full max-w-md bg-neutral-900 border border-neutral-800 rounded-t-3xl sm:rounded-3xl overflow-hidden shadow-2xl max-h-[90vh] flex flex-col">
            {/* Header */}
            <div className="p-4 pb-2 border-b border-neutral-800 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="font-display font-bold text-sm text-white">تفاصيل وأعضاء الجروب</span>
              </div>
              <button
                onClick={() => setSelectedGroupDetail(null)}
                className="w-8 h-8 rounded-full flex items-center justify-center bg-neutral-800 text-neutral-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-4 overflow-y-auto space-y-4">
              {/* Group Cover & Info */}
              <div className="flex items-center gap-3">
                <img
                  src={selectedGroupDetail.avatar}
                  alt={selectedGroupDetail.name}
                  className="w-16 h-16 rounded-2xl object-cover border border-neutral-700 shadow-md shrink-0"
                  referrerPolicy="no-referrer"
                />
                <div>
                  <h3 className="text-sm font-bold text-white">{selectedGroupDetail.name}</h3>
                  <div className="flex items-center gap-1.5 mt-1">
                    {selectedGroupDetail.isPublic ? (
                      <span className="text-[10px] px-2 py-0.5 rounded bg-neutral-800 text-emerald-400 font-semibold border border-neutral-700 flex items-center gap-1">
                        <Globe className="w-3 h-3" /> عام (يظهر في الاستكشاف)
                      </span>
                    ) : (
                      <span className="text-[10px] px-2 py-0.5 rounded bg-neutral-800 text-amber-400 font-semibold border border-neutral-700 flex items-center gap-1">
                        <Lock className="w-3 h-3" /> خاص (بدعوة ولينك بس)
                      </span>
                    )}
                  </div>
                  <p className="text-[11px] text-neutral-400 mt-1">
                    {selectedGroupDetail.description}
                  </p>
                </div>
              </div>

              {/* Leaderboard CTA for this group */}
              <div className="p-3 rounded-2xl bg-amber-950/20 border border-amber-500/30 flex items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-xl bg-amber-500/20 border border-amber-500/30 flex items-center justify-center text-amber-400 shrink-0">
                    <Trophy className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="text-xs font-bold text-white block">ترتيب وتصنيف هذا الجروب 🏆</span>
                    <span className="text-[10px] text-amber-300/80 block">عرض أفضل لاعبي الجروب ونقاط الالتزام</span>
                  </div>
                </div>
                <button
                  onClick={() => {
                    setSelectedGroup(selectedGroupDetail);
                    setSelectedGroupDetail(null);
                    setActiveTab('leaderboard');
                  }}
                  className="px-3 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-neutral-950 text-xs font-bold transition-all shrink-0 shadow-sm"
                >
                  عرض الترتيب
                </button>
              </div>

              {/* Invite link & QR section */}
              <div className="p-3 rounded-2xl bg-neutral-950 border border-neutral-800 flex items-center justify-between gap-2">
                <div>
                  <span className="text-[10px] text-neutral-400 block font-medium">كود ورابط دعوة الجروب:</span>
                  <span className="text-xs font-mono font-bold text-white tracking-wider">
                    {selectedGroupDetail.inviteCode}
                  </span>
                </div>
                <div className="flex items-center gap-1.5">
                  <button
                    onClick={() => setShareGroupTarget(selectedGroupDetail)}
                    className="px-2.5 py-1.5 rounded-lg bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-300 text-xs font-bold flex items-center gap-1 border border-emerald-500/30 transition-all active:scale-95"
                    title="مشاركة الجروب على واتساب وبرمز QR"
                  >
                    <QrCode className="w-3.5 h-3.5" />
                    <span>مشاركة و QR</span>
                  </button>
                  <button
                    onClick={() => copyInvite(selectedGroupDetail.inviteCode)}
                    className="px-2.5 py-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-750 text-neutral-200 text-xs font-semibold flex items-center gap-1 transition-colors"
                  >
                    <Copy className="w-3.5 h-3.5" />
                    <span>{copiedCode ? 'تم النسخ!' : 'نسخ'}</span>
                  </button>
                </div>
              </div>

              {/* Members List with Roles & Position Colors */}
              <div>
                <div className="text-xs font-bold text-neutral-300 mb-2 flex items-center justify-between">
                  <span>أعضاء الجروب ({selectedGroupDetail.members.length}):</span>
                  {selectedGroupDetail.creatorId === currentUser.id && (
                    <span className="text-[10px] text-emerald-400">
                      أنت المؤسس: يمكنك منح صلاحية أدمن
                    </span>
                  )}
                </div>

                {/* شريط الدليل البصري وتصفية المراكز */}
                <div className="mb-2 p-2 rounded-xl bg-neutral-950/90 border border-neutral-800 space-y-1.5 shadow-sm">
                  <div className="flex items-center justify-between text-[11px]">
                    <span className="font-bold text-neutral-300">التمييز البصري للمراكز الكروية:</span>
                    <span className="text-[10px] text-neutral-400">اضغط للفلترة</span>
                  </div>
                  <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none text-[10px]">
                    {POSITION_LEGEND.map(item => {
                      const isSelected = memberPositionFilter === item.key;
                      return (
                        <button
                          key={item.key}
                          onClick={() => setMemberPositionFilter(isSelected && item.key !== 'all' ? 'all' : item.key)}
                          className={`px-2 py-0.5 rounded-lg border font-bold transition-all shrink-0 ${
                            isSelected 
                              ? 'ring-2 ring-emerald-400 scale-[1.03] ' + item.color
                              : item.color + ' opacity-75 hover:opacity-100'
                          }`}
                        >
                          {item.label}
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* قائمة بطاقات اللاعبين الملونة حسب المركز */}
                <div className="space-y-1.5">
                  {selectedGroupDetail.members
                    .filter(member => {
                      if (memberPositionFilter === 'all') return true;
                      const u = getUserById(member.userId);
                      const style = getPositionStyle(u?.position);
                      return style.category === memberPositionFilter;
                    })
                    .map(member => {
                      const user = getUserById(member.userId);
                      const isCreator = member.role === 'creator';
                      const isAdmin = member.role === 'admin' || isCreator;
                      const canToggleAdmin = selectedGroupDetail.creatorId === currentUser.id && !isCreator;
                      const posStyle = getPositionStyle(user?.position);

                      return (
                        <div
                          key={member.userId}
                          className={`p-2.5 rounded-xl border transition-all flex items-center justify-between gap-2 text-right ${posStyle.cardBg} ${posStyle.cardBorder} shadow-sm ${posStyle.glowEffect}`}
                        >
                          <button
                            onClick={() => {
                              setSelectedGroupDetail(null);
                              onViewUserProfile(member.userId);
                            }}
                            className="flex items-center gap-2.5 truncate group"
                          >
                            <div className="relative shrink-0">
                              <img
                                src={user?.avatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100'}
                                alt={user?.name}
                                className={`w-9 h-9 rounded-full object-cover shrink-0 ${posStyle.avatarRing}`}
                                referrerPolicy="no-referrer"
                              />
                              <span 
                                className="absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 rounded-full flex items-center justify-center text-[9px] bg-neutral-900 border border-neutral-700 shadow"
                                title={posStyle.categoryLabel}
                              >
                                {posStyle.roleIcon}
                              </span>
                            </div>
                            <div className="truncate text-right">
                              <div className="flex items-center gap-1.5">
                                <span className="text-xs font-bold text-white group-hover:text-emerald-300 transition-colors truncate">
                                  {user?.name}
                                </span>
                              </div>
                              <div className="flex items-center gap-1 mt-0.5">
                                <span className={`text-[10px] px-1.5 py-0.5 rounded-md font-semibold border ${posStyle.badgeBg}`}>
                                  {posStyle.roleIcon} {user?.position || posStyle.shortLabel}
                                </span>
                              </div>
                            </div>
                          </button>

                          <div className="flex items-center gap-1.5 shrink-0">
                            {isCreator ? (
                              <span className="text-[10px] px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30 font-bold">
                                المؤسس 👑
                              </span>
                            ) : isAdmin ? (
                              <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 font-bold border border-emerald-500/30">
                                أدمن 🛡️
                              </span>
                            ) : (
                              <span className="text-[10px] px-2 py-0.5 rounded bg-neutral-900/80 text-neutral-300 border border-neutral-700/80 font-medium">
                                عضو
                              </span>
                            )}

                            {/* Primary Admin Toggle Button (Specification 2) */}
                            {canToggleAdmin && (
                              <button
                                onClick={() => toggleAdminRole(selectedGroupDetail.id, member.userId)}
                                className="px-2 py-1 rounded-lg bg-neutral-900/90 hover:bg-neutral-800 text-[10px] font-semibold text-emerald-400 border border-neutral-700 hover:border-emerald-500/50 transition-colors"
                              >
                                {member.role === 'admin' ? 'سحب الأدمن' : 'ترقية لأدمن'}
                              </button>
                            )}
                          </div>
                        </div>
                      );
                    })}
                </div>
              </div>
            </div>

            <div className="p-3 border-t border-neutral-800 bg-neutral-900">
              <button
                onClick={() => {
                  setSelectedGroup(selectedGroupDetail);
                  setSelectedGroupDetail(null);
                  setActiveTab('matches');
                }}
                className="w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs transition-colors"
              >
                عرض حجوزات هذا الجروب
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* Create Group Modal (Specification 2) */}
      {/* ========================================================================= */}
      {showCreateModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4 animate-in fade-in duration-200">
          <div className="w-full max-w-md bg-neutral-900 border border-neutral-800 rounded-t-3xl sm:rounded-3xl overflow-hidden shadow-2xl p-4">
            <div className="flex items-center justify-between pb-3 border-b border-neutral-800">
              <h3 className="text-sm font-bold text-white font-display">إنشاء جروب كورة جديد</h3>
              <button
                onClick={() => setShowCreateModal(false)}
                className="w-8 h-8 rounded-full flex items-center justify-center bg-neutral-800 text-neutral-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCreateGroupSubmit} className="space-y-3.5 mt-3">
              <div>
                <label className="text-xs font-bold text-neutral-300 mb-1 block">اسم الجروب:</label>
                <input
                  type="text"
                  value={newGroupName}
                  onChange={(e) => setNewGroupName(e.target.value)}
                  placeholder="مثلاً: كورة الثلاثاء - ملاعب المعادي ⚽"
                  className="w-full bg-neutral-950 border border-neutral-700 focus:border-emerald-500 rounded-xl px-3 py-2 text-xs text-white outline-none"
                  required
                />
              </div>

              <div>
                <label className="text-xs font-bold text-neutral-300 mb-1 block">وصف ونظام الجروب:</label>
                <textarea
                  value={newGroupDesc}
                  onChange={(e) => setNewGroupDesc(e.target.value)}
                  placeholder="مثلاً: ماتش أسبوعي للأصحاب، الالتزام بالروح الرياضية وممنوع الاعتذار المتأخر..."
                  rows={2}
                  className="w-full bg-neutral-950 border border-neutral-700 focus:border-emerald-500 rounded-xl p-2.5 text-xs text-white outline-none resize-none"
                />
              </div>

              {/* Public vs Private selector (Specification 2) */}
              <div className="p-3 rounded-2xl bg-neutral-950 border border-neutral-800 space-y-2">
                <label className="text-xs font-bold text-neutral-300 block">نوع الجروب والخصوصية:</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setNewGroupIsPublic(true)}
                    className={`p-2.5 rounded-xl border text-right transition-all ${
                      newGroupIsPublic
                        ? 'bg-emerald-950/40 border-emerald-500/50 text-emerald-300'
                        : 'bg-neutral-900 border-neutral-800 text-neutral-400'
                    }`}
                  >
                    <div className="flex items-center gap-1.5 font-bold text-xs">
                      <Globe className="w-3.5 h-3.5 text-emerald-400" />
                      <span>جروب عام (Public)</span>
                    </div>
                    <span className="text-[10px] text-neutral-400 mt-1 block">
                      يظهر في صفحة البحث، وأي حد يقدر يبعت طلب انضمام يتطلب موافقة الأدمن.
                    </span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setNewGroupIsPublic(false)}
                    className={`p-2.5 rounded-xl border text-right transition-all ${
                      !newGroupIsPublic
                        ? 'bg-amber-950/40 border-amber-500/50 text-amber-300'
                        : 'bg-neutral-900 border-neutral-800 text-neutral-400'
                    }`}
                  >
                    <div className="flex items-center gap-1.5 font-bold text-xs">
                      <Lock className="w-3.5 h-3.5 text-amber-400" />
                      <span>جروب خاص (Private)</span>
                    </div>
                    <span className="text-[10px] text-neutral-400 mt-1 block">
                      مخفي، لا ينضم إليه إلا من يحمل كود أو رابط الدعوة المباشر.
                    </span>
                  </button>
                </div>
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  className="w-full py-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-lg shadow-emerald-950 transition-colors"
                >
                  تأكيد وإنشاء الجروب
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Share Group Modal with WhatsApp & QR */}
      {shareGroupTarget && (
        <ShareModal
          isOpen={!!shareGroupTarget}
          onClose={() => setShareGroupTarget(null)}
          type="group"
          group={shareGroupTarget}
        />
      )}
    </div>
  );
};
