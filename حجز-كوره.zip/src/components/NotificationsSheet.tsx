import React from 'react';
import { useApp } from '../context/AppContext';
import { NotificationType } from '../types';
import { 
  Bell, 
  Calendar, 
  Users, 
  AlertTriangle, 
  Flame, 
  CheckCheck, 
  Clock, 
  Sparkles,
  ChevronLeft
} from 'lucide-react';

interface NotificationsSheetProps {
  onSelectMatch?: (matchId: string) => void;
}

export const NotificationsSheet: React.FC<NotificationsSheetProps> = ({ onSelectMatch }) => {
  const { 
    notifications, 
    markNotificationAsRead, 
    markAllNotificationsAsRead, 
    setActiveTab,
    matches,
    setSelectedGroup,
    groups 
  } = useApp();

  const getIcon = (type: NotificationType) => {
    switch (type) {
      case 'new_match':
        return <Calendar className="w-4 h-4 text-emerald-400" />;
      case 'waitlist_promoted':
        return <Users className="w-4 h-4 text-blue-400" />;
      case 'almost_full':
        return <Flame className="w-4 h-4 text-amber-400" />;
      case 'member_rated':
      case 'match_finished':
        return <Sparkles className="w-4 h-4 text-amber-400" />;
      case 'risk_cancellation':
        return <AlertTriangle className="w-4 h-4 text-rose-400" />;
      case 'match_reminder':
      default:
        return <Clock className="w-4 h-4 text-indigo-400" />;
    }
  };

  const getBorderColor = (type: NotificationType, unread: boolean) => {
    if (!unread) return 'border-neutral-800 bg-neutral-900/60 opacity-80';
    switch (type) {
      case 'new_match':
        return 'border-emerald-500/40 bg-emerald-950/20';
      case 'waitlist_promoted':
        return 'border-blue-500/40 bg-blue-950/20';
      case 'almost_full':
        return 'border-amber-500/40 bg-amber-950/20';
      case 'member_rated':
      case 'match_finished':
        return 'border-amber-500/50 bg-amber-950/30';
      case 'risk_cancellation':
        return 'border-rose-500/50 bg-rose-950/30';
      default:
        return 'border-neutral-700 bg-neutral-900';
    }
  };

  const handleClick = (notifId: string, matchId?: string, groupId?: string) => {
    markNotificationAsRead(notifId);
    if (groupId) {
      const g = groups.find(group => group.id === groupId);
      if (g) setSelectedGroup(g);
    }
    if (matchId) {
      setActiveTab('matches');
      onSelectMatch?.(matchId);
    }
  };

  return (
    <div className="space-y-3 pb-8">
      {/* Header bar */}
      <div className="flex items-center justify-between pb-1 border-b border-neutral-800">
        <div>
          <h2 className="text-sm font-bold text-white font-display flex items-center gap-1.5">
            <Bell className="w-4 h-4 text-emerald-400" />
            <span>مركز الإشعارات الحية</span>
          </h2>
          <p className="text-[11px] text-neutral-400">تحديثات الحجوزات والـ Waitlist والمواعيد</p>
        </div>

        {notifications.some(n => !n.read) && (
          <button
            onClick={markAllNotificationsAsRead}
            className="flex items-center gap-1 text-[11px] font-semibold text-emerald-400 hover:text-emerald-300 transition-colors"
          >
            <CheckCheck className="w-3.5 h-3.5" />
            <span>تحديد الكل كمقروء</span>
          </button>
        )}
      </div>

      {/* Notifications List */}
      {notifications.length === 0 ? (
        <div className="p-12 text-center bg-neutral-900 rounded-3xl border border-neutral-800 text-neutral-400 text-xs space-y-2">
          <Bell className="w-8 h-8 mx-auto text-neutral-600 stroke-[1.5]" />
          <p>مفيش إشعارات جديدة حالياً يا كابتن</p>
        </div>
      ) : (
        <div className="space-y-2">
          {notifications.map(notif => {
            const isUnread = !notif.read;
            const timeAgo = new Date(notif.timestamp).toLocaleTimeString('ar-EG', {
              hour: '2-digit',
              minute: '2-digit'
            });

            return (
              <div
                key={notif.id}
                onClick={() => handleClick(notif.id, notif.matchId, notif.groupId)}
                className={`p-3 rounded-2xl border transition-all cursor-pointer shadow-sm relative text-right flex items-start gap-3 ${getBorderColor(
                  notif.type,
                  isUnread
                )}`}
              >
                {/* Icon avatar */}
                <div className="w-9 h-9 rounded-xl bg-neutral-900 border border-neutral-800 flex items-center justify-center shrink-0 shadow-inner">
                  {getIcon(notif.type)}
                </div>

                {/* Content */}
                <div className="min-w-0 flex-1">
                  <div className="flex items-center justify-between gap-1">
                    <h4 className="text-xs font-bold text-white truncate">
                      {notif.title}
                    </h4>
                    <span className="text-[10px] text-neutral-500 shrink-0 font-mono">
                      {timeAgo}
                    </span>
                  </div>

                  <p className="text-[11px] text-neutral-300 mt-0.5 leading-relaxed">
                    {notif.message}
                  </p>

                  {notif.matchId && (
                    <div className="flex items-center gap-1 text-[10px] text-emerald-400 font-semibold mt-1.5">
                      <span>عرض تفاصيل الماتش</span>
                      <ChevronLeft className="w-3 h-3" />
                    </div>
                  )}
                </div>

                {/* Unread dot */}
                {isUnread && (
                  <span className="w-2 h-2 rounded-full bg-emerald-400 shrink-0 mt-1" />
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
