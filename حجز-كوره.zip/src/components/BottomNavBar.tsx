import React from 'react';
import { useApp } from '../context/AppContext';
import { Calendar, Users, PlusCircle, Bell, User } from 'lucide-react';

export const BottomNavBar: React.FC = () => {
  const { activeTab, setActiveTab, notifications } = useApp();

  const unreadCount = notifications.filter(n => !n.read).length;

  interface NavItem {
    id: 'matches' | 'groups' | 'create_match' | 'notifications' | 'profile';
    label: string;
    icon: React.ElementType;
    badge: number;
    isPrimaryAction?: boolean;
  }

  const navItems: NavItem[] = [
    {
      id: 'matches',
      label: 'الماتشات',
      icon: Calendar,
      badge: 0
    },
    {
      id: 'groups',
      label: 'الجروبات',
      icon: Users,
      badge: 0
    },
    {
      id: 'create_match',
      label: 'حجز جديد',
      icon: PlusCircle,
      isPrimaryAction: true,
      badge: 0
    },
    {
      id: 'notifications',
      label: 'الإشعارات',
      icon: Bell,
      badge: unreadCount
    },
    {
      id: 'profile',
      label: 'بروفايلي',
      icon: User,
      badge: 0
    }
  ];

  return (
    <nav 
      aria-label="شريط التنقل السفلي"
      className="w-full bg-neutral-900/95 backdrop-blur-md border-t border-neutral-800/80 px-2 py-1.5 z-40 shrink-0 select-none pb-safe"
    >
      <div className="grid grid-cols-5 items-center max-w-md mx-auto">
        {navItems.map(item => {
          const isActive = activeTab === item.id;
          const Icon = item.icon;

          if (item.isPrimaryAction) {
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className="flex flex-col items-center justify-center min-h-[44px] relative group"
                aria-label={item.label}
              >
                <div className={`w-11 h-11 rounded-full flex items-center justify-center -mt-4 shadow-lg transition-transform active:scale-95 ${isActive ? 'bg-emerald-400 text-neutral-950 ring-2 ring-emerald-500/50 shadow-emerald-500/20' : 'bg-emerald-600 text-white hover:bg-emerald-500 shadow-emerald-900/40'}`}>
                  <Icon className="w-6 h-6 stroke-[2.5]" />
                </div>
                <span className={`text-[10px] font-semibold mt-0.5 tracking-tight transition-colors ${isActive ? 'text-emerald-400' : 'text-neutral-400 group-hover:text-neutral-200'}`}>
                  {item.label}
                </span>
              </button>
            );
          }

          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className="flex flex-col items-center justify-center min-h-[44px] py-1 relative transition-colors group"
              aria-label={item.label}
            >
              <div className="relative flex items-center justify-center">
                <Icon
                  className={`w-5 h-5 transition-transform group-hover:scale-105 ${
                    isActive ? 'text-emerald-400 stroke-[2.2]' : 'text-neutral-400 stroke-[1.8] group-hover:text-neutral-200'
                  }`}
                />
                {item.badge > 0 && (
                  <span className="absolute -top-1 -right-1.5 min-w-[16px] h-4 px-1 rounded-full bg-rose-600 text-white text-[9px] font-black flex items-center justify-center ring-2 ring-neutral-900 animate-pulse">
                    {item.badge > 9 ? '9+' : item.badge}
                  </span>
                )}
              </div>
              <span
                className={`text-[10px] mt-1 tracking-tight font-medium transition-colors ${
                  isActive ? 'text-emerald-400 font-bold' : 'text-neutral-400 group-hover:text-neutral-200'
                }`}
              >
                {item.label}
              </span>
              {isActive && (
                <span className="w-1 h-1 rounded-full bg-emerald-400 mt-0.5" />
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
};
