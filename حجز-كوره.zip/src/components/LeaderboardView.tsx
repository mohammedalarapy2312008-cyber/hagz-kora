import React, { useState, useMemo } from 'react';
import { useApp } from '../context/AppContext';
import { User, Group } from '../types';
import { 
  Trophy, 
  Medal, 
  Star, 
  Award, 
  Flame, 
  ShieldCheck, 
  Users, 
  ChevronDown, 
  Check, 
  Search, 
  TrendingUp,
  Sparkles,
  Zap,
  X
} from 'lucide-react';

interface LeaderboardViewProps {
  onViewUserProfile: (userId: string) => void;
}

export interface PlayerScoreData {
  user: User;
  rank: number;
  points: number;
  tier: {
    name: string;
    badge: string;
    color: string;
    bg: string;
    border: string;
  };
  overallRating: number;
  commitmentRating: number;
  skillRating: number;
  ratingsCount: number;
  matchesPlayed: number;
  lateCancellations: number;
  groupNames: string[];
}

export const getPlayerTier = (points: number) => {
  if (points >= 800) {
    return {
      name: 'أسطوري (Legend)',
      badge: '👑',
      color: 'text-amber-300',
      bg: 'bg-amber-500/15',
      border: 'border-amber-500/40'
    };
  }
  if (points >= 550) {
    return {
      name: 'ذهبي (Elite)',
      badge: '🥇',
      color: 'text-amber-400',
      bg: 'bg-amber-400/10',
      border: 'border-amber-400/30'
    };
  }
  if (points >= 350) {
    return {
      name: 'فضي (Pro)',
      badge: '🥈',
      color: 'text-slate-300',
      bg: 'bg-slate-400/10',
      border: 'border-slate-400/30'
    };
  }
  return {
    name: 'برونزي (Rising)',
    badge: '🥉',
    color: 'text-orange-400',
    bg: 'bg-orange-500/10',
    border: 'border-orange-500/30'
  };
};

export const LeaderboardView: React.FC<LeaderboardViewProps> = ({ onViewUserProfile }) => {
  const { 
    allUsers, 
    groups, 
    selectedGroup, 
    setSelectedGroup, 
    getUserRatingStats,
    currentUser 
  } = useApp();

  // Scope: 'all' (كل التطبيق) or groupId (جروب محدد)
  const [activeScope, setActiveScope] = useState<string>(selectedGroup ? selectedGroup.id : 'all');
  const [selectedSort, setSelectedSort] = useState<'points' | 'rating' | 'matches' | 'commitment'>('points');
  const [searchQuery, setSearchQuery] = useState('');
  const [isGroupDropdownOpen, setIsGroupDropdownOpen] = useState(false);

  // Sync with selectedGroup if it changes from top
  const currentScopeGroup = useMemo(() => {
    if (activeScope === 'all') return null;
    return groups.find(g => g.id === activeScope) || null;
  }, [activeScope, groups]);

  // Calculate scores and points for all players
  const playerLeaderboard: PlayerScoreData[] = useMemo(() => {
    // 1. Filter users based on scope
    let scopedUsers = allUsers;
    if (activeScope !== 'all') {
      const group = groups.find(g => g.id === activeScope);
      if (group) {
        const memberIds = new Set(group.members.map(m => m.userId));
        scopedUsers = allUsers.filter(u => memberIds.has(u.id));
      }
    }

    // 2. Filter by search query if any
    if (searchQuery.trim()) {
      const q = searchQuery.trim().toLowerCase();
      scopedUsers = scopedUsers.filter(u => 
        u.name.toLowerCase().includes(q) || 
        u.position.toLowerCase().includes(q)
      );
    }

    // 3. Compute stats and total points
    const mapped = scopedUsers.map(user => {
      const ratingStats = getUserRatingStats(user.id);
      const overall = ratingStats.averageOverall;
      const commitment = ratingStats.averageCommitment;
      const skill = ratingStats.averageSkill;
      const matches = user.matchesPlayed || 0;
      const late = user.lateCancellations || 0;

      // Point Calculation Formula:
      // - Match participation: matchesPlayed * 15 pts
      // - Star Rating: overallRating * 50 pts
      // - Rating count credibility bonus: min(ratingsCount * 5, 50) pts
      // - Penalty for late cancellation: lateCancellations * -30 pts
      const ratingBonus = Math.min((ratingStats.totalRatingsCount || 0) * 5, 50);
      const points = Math.max(
        0, 
        Math.round((matches * 15) + (overall * 50) + ratingBonus - (late * 30))
      );

      const tier = getPlayerTier(points);

      // Find groups user is a member of
      const userGroups = groups
        .filter(g => g.members.some(m => m.userId === user.id))
        .map(g => g.name);

      return {
        user,
        rank: 0,
        points,
        tier,
        overallRating: overall,
        commitmentRating: commitment,
        skillRating: skill,
        ratingsCount: ratingStats.totalRatingsCount,
        matchesPlayed: matches,
        lateCancellations: late,
        groupNames: userGroups
      };
    });

    // 4. Sort
    mapped.sort((a, b) => {
      if (selectedSort === 'points') return b.points - a.points;
      if (selectedSort === 'rating') return b.overallRating - a.overallRating || b.points - a.points;
      if (selectedSort === 'matches') return b.matchesPlayed - a.matchesPlayed || b.points - a.points;
      if (selectedSort === 'commitment') return b.commitmentRating - a.commitmentRating || b.points - a.points;
      return b.points - a.points;
    });

    // Assign rank
    return mapped.map((item, index) => ({
      ...item,
      rank: index + 1
    }));
  }, [allUsers, groups, activeScope, searchQuery, selectedSort, getUserRatingStats]);

  // Top 3 Podium
  const podiumTop3 = playerLeaderboard.slice(0, 3);
  const restPlayers = playerLeaderboard.slice(3);

  // My current position in the list
  const myRankData = playerLeaderboard.find(p => p.user.id === currentUser.id);

  return (
    <div className="space-y-3.5 pb-10 select-none animate-in fade-in duration-200">
      {/* Header Banner */}
      <div className="rounded-3xl bg-gradient-to-br from-amber-500/20 via-neutral-900 to-neutral-950 border border-amber-500/30 p-4 shadow-xl relative overflow-hidden">
        <div className="relative z-10 space-y-1.5">
          <div className="flex items-center justify-between">
            <span className="px-2.5 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30 text-[10px] font-bold flex items-center gap-1">
              <Trophy className="w-3 h-3 text-amber-400" />
              <span>قائمة الترتيب وتصنيف النجوم 🏆</span>
            </span>
            <span className="text-[10px] font-bold text-neutral-400">
              {playerLeaderboard.length} كابتن مصنف
            </span>
          </div>
          <h2 className="text-base font-black font-display text-white">
            ترتيب أفضل اللاعبين ونقاط الالتزام
          </h2>
          <p className="text-xs text-neutral-300 leading-relaxed">
            يتم احتساب الترتيب تلقائياً بناءً على تقييمات الماتشات (الالتزام + المهارة) وعدد الحضور والنشاط.
          </p>
        </div>
      </div>

      {/* Scope Selector: All App vs Specific Group */}
      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <span className="text-xs font-bold text-neutral-300 flex items-center gap-1.5">
            <Users className="w-3.5 h-3.5 text-emerald-400" />
            <span>نطاق القائمة:</span>
          </span>
          <span className="text-[10px] text-neutral-400 font-semibold">
            {activeScope === 'all' ? '🌍 على مستوى التطبيق بالكامل' : `👥 جروب: ${currentScopeGroup?.name}`}
          </span>
        </div>

        {/* Tab pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
          <button
            onClick={() => setActiveScope('all')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold shrink-0 transition-all flex items-center gap-1.5 ${
              activeScope === 'all'
                ? 'bg-emerald-600 text-white shadow-md shadow-emerald-950 ring-1 ring-emerald-400'
                : 'bg-neutral-900 hover:bg-neutral-800 text-neutral-400 border border-neutral-800'
            }`}
          >
            <span>🌍 كل التطبيق (العام)</span>
          </button>

          {groups.map(g => (
            <button
              key={g.id}
              onClick={() => setActiveScope(g.id)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold shrink-0 transition-all flex items-center gap-1.5 ${
                activeScope === g.id
                  ? 'bg-emerald-600 text-white shadow-md shadow-emerald-950 ring-1 ring-emerald-400'
                  : 'bg-neutral-900 hover:bg-neutral-800 text-neutral-400 border border-neutral-800'
              }`}
            >
              <span>{g.name.length > 18 ? g.name.substring(0, 18) + '...' : g.name}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Search & Sort Filters */}
      <div className="flex flex-col sm:flex-row gap-2">
        {/* Search */}
        <div className="relative flex-1 group">
          <div className="relative flex items-center gap-2 p-1.5 pr-2.5 rounded-2xl bg-gradient-to-r from-neutral-900 via-neutral-900 to-neutral-950 border-2 border-amber-500/50 hover:border-amber-400 focus-within:border-amber-400 focus-within:ring-4 focus-within:ring-amber-500/25 shadow-xl shadow-amber-950/40 transition-all duration-200">
            {/* Glowing background accent */}
            <div className="absolute -inset-0.5 bg-gradient-to-r from-amber-500/20 via-orange-500/10 to-transparent rounded-2xl blur-sm -z-10 pointer-events-none opacity-70 group-hover:opacity-100 transition-opacity" />

            {/* Search Icon with Glowing Gradient Badge */}
            <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-amber-500 to-orange-600 text-neutral-950 flex items-center justify-center shadow-md shadow-amber-950/60 shrink-0 ring-1 ring-white/20">
              <Search className="w-4 h-4 stroke-[2.5]" />
            </div>

            {/* Input field */}
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="ابحث عن لاعب باسمه أو مركزه..."
              className="flex-1 bg-transparent text-xs text-white placeholder-neutral-400 outline-none font-semibold text-right"
            />

            {/* Clear Button */}
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="w-6 h-6 rounded-full bg-neutral-800 hover:bg-neutral-700 text-neutral-300 hover:text-white flex items-center justify-center transition-colors shrink-0"
                title="مسح البحث"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}

            {/* Count Badge */}
            {searchQuery && (
              <span className="text-[10px] font-black text-amber-300 bg-amber-500/20 border border-amber-500/40 px-2 py-0.5 rounded-lg shrink-0 shadow-sm">
                {playerLeaderboard.length} لاعب
              </span>
            )}
          </div>
        </div>

        {/* Sort Dropdown */}
        <div className="flex items-center gap-1 bg-neutral-900/90 border border-neutral-800 rounded-2xl p-1.5 shrink-0 shadow-sm">
          <span className="text-[10px] text-neutral-400 px-1 font-bold">ترتيب:</span>
          {(
            [
              { id: 'points', label: 'النقاط ⚡' },
              { id: 'rating', label: 'النجوم ⭐' },
              { id: 'matches', label: 'الماتشات ⚽' },
              { id: 'commitment', label: 'الالتزام ⏱️' }
            ] as const
          ).map(sort => (
            <button
              key={sort.id}
              onClick={() => setSelectedSort(sort.id)}
              className={`px-2.5 py-1.5 rounded-xl text-[11px] transition-all ${
                selectedSort === sort.id
                  ? 'bg-gradient-to-r from-amber-500 to-orange-500 text-neutral-950 font-black shadow-md shadow-amber-950'
                  : 'text-neutral-400 hover:text-neutral-200 font-semibold'
              }`}
            >
              {sort.label}
            </button>
          ))}
        </div>
      </div>

      {/* Current User Floating Sticky Rank Pill if in the list */}
      {myRankData && (
        <div className="p-3 rounded-2xl bg-neutral-900 border border-emerald-500/40 shadow-lg flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <span className="w-6 h-6 rounded-full bg-emerald-500/20 text-emerald-400 text-xs font-black flex items-center justify-center font-display border border-emerald-500/30">
              #{myRankData.rank}
            </span>
            <div className="w-8 h-8 rounded-full overflow-hidden border border-emerald-500/50 shrink-0">
              <img src={currentUser.avatar} alt={currentUser.name} className="w-full h-full object-cover" />
            </div>
            <div>
              <div className="text-xs font-bold text-white flex items-center gap-1">
                <span>ترتيبك في هذه القائمة</span>
                <span className="text-[10px] text-emerald-400">({myRankData.tier.name})</span>
              </div>
              <div className="text-[10px] text-neutral-400">
                {myRankData.matchesPlayed} ماتش • {myRankData.overallRating} ⭐ • {myRankData.points} نقطة
              </div>
            </div>
          </div>

          <button
            onClick={() => onViewUserProfile(currentUser.id)}
            className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition-all shadow-sm"
          >
            بروفايلي
          </button>
        </div>
      )}

      {/* ========================================================================= */}
      {/* Top 3 Podium (منصة التتويج للثلاثة الأوائل) */}
      {/* ========================================================================= */}
      {podiumTop3.length >= 3 && !searchQuery && (
        <div className="pt-2 pb-1">
          <div className="grid grid-cols-3 gap-2 items-end">
            {/* 2nd Place (Left) */}
            <div 
              onClick={() => onViewUserProfile(podiumTop3[1].user.id)}
              className="cursor-pointer group flex flex-col items-center p-3 rounded-2xl bg-neutral-900/90 border border-slate-700/60 hover:border-slate-500 transition-all text-center space-y-1.5 relative shadow-lg"
            >
              <div className="absolute -top-2.5 bg-slate-400 text-neutral-950 text-[10px] font-black px-2 py-0.5 rounded-full shadow-md">
                #2 🥈
              </div>
              <div className="w-12 h-12 rounded-full overflow-hidden border-2 border-slate-400 shadow-md group-hover:scale-105 transition-transform">
                <img src={podiumTop3[1].user.avatar} alt={podiumTop3[1].user.name} className="w-full h-full object-cover" />
              </div>
              <span className="text-xs font-bold text-white truncate max-w-full block">
                {podiumTop3[1].user.name.split(' ')[0]}
              </span>
              <span className="text-[10px] font-black text-slate-300 font-mono">
                {podiumTop3[1].points} نقطة
              </span>
              <div className="flex items-center justify-center gap-0.5 text-[10px] text-amber-400 font-bold">
                <Star className="w-2.5 h-2.5 fill-current" />
                <span>{podiumTop3[1].overallRating}</span>
              </div>
            </div>

            {/* 1st Place (Center - Highlighted) */}
            <div 
              onClick={() => onViewUserProfile(podiumTop3[0].user.id)}
              className="cursor-pointer group flex flex-col items-center p-3.5 rounded-2xl bg-gradient-to-b from-amber-500/20 via-neutral-900 to-neutral-950 border-2 border-amber-500 hover:border-amber-400 transition-all text-center space-y-1.5 relative shadow-xl shadow-amber-950/30 scale-105 z-10"
            >
              <div className="absolute -top-3 bg-amber-400 text-neutral-950 text-[11px] font-black px-2.5 py-0.5 rounded-full shadow-md flex items-center gap-1">
                <span>#1 👑</span>
              </div>
              <div className="w-14 h-14 rounded-full overflow-hidden border-2 border-amber-400 shadow-lg group-hover:scale-105 transition-transform ring-2 ring-amber-500/30">
                <img src={podiumTop3[0].user.avatar} alt={podiumTop3[0].user.name} className="w-full h-full object-cover" />
              </div>
              <span className="text-xs font-bold text-white truncate max-w-full block">
                {podiumTop3[0].user.name.split(' ')[0]}
              </span>
              <span className="text-xs font-black text-amber-300 font-mono">
                {podiumTop3[0].points} نقطة
              </span>
              <div className="flex items-center justify-center gap-1 text-[10px] text-amber-300 font-bold bg-amber-500/20 px-2 py-0.5 rounded-full">
                <Star className="w-2.5 h-2.5 fill-current" />
                <span>{podiumTop3[0].overallRating} ⭐</span>
              </div>
            </div>

            {/* 3rd Place (Right) */}
            <div 
              onClick={() => onViewUserProfile(podiumTop3[2].user.id)}
              className="cursor-pointer group flex flex-col items-center p-3 rounded-2xl bg-neutral-900/90 border border-orange-700/60 hover:border-orange-500 transition-all text-center space-y-1.5 relative shadow-lg"
            >
              <div className="absolute -top-2.5 bg-orange-400 text-neutral-950 text-[10px] font-black px-2 py-0.5 rounded-full shadow-md">
                #3 🥉
              </div>
              <div className="w-12 h-12 rounded-full overflow-hidden border-2 border-orange-400 shadow-md group-hover:scale-105 transition-transform">
                <img src={podiumTop3[2].user.avatar} alt={podiumTop3[2].user.name} className="w-full h-full object-cover" />
              </div>
              <span className="text-xs font-bold text-white truncate max-w-full block">
                {podiumTop3[2].user.name.split(' ')[0]}
              </span>
              <span className="text-[10px] font-black text-orange-300 font-mono">
                {podiumTop3[2].points} نقطة
              </span>
              <div className="flex items-center justify-center gap-0.5 text-[10px] text-amber-400 font-bold">
                <Star className="w-2.5 h-2.5 fill-current" />
                <span>{podiumTop3[2].overallRating}</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Leaderboard Table / Cards */}
      <div className="space-y-2 pt-1">
        <div className="flex items-center justify-between text-[11px] font-bold text-neutral-400 px-2">
          <span>الترتيب واللاعب</span>
          <span>المستوى والنقاط</span>
        </div>

        {playerLeaderboard.length === 0 ? (
          <div className="p-8 text-center bg-neutral-900 rounded-3xl border border-neutral-800 text-neutral-400 text-xs">
            لا يوجد لاعبين مطابقين للبحث في هذا الجروب
          </div>
        ) : (
          playerLeaderboard.map((item) => {
            const isTop3 = item.rank <= 3;
            const isMe = item.user.id === currentUser.id;

            return (
              <div
                key={item.user.id}
                onClick={() => onViewUserProfile(item.user.id)}
                className={`p-3 rounded-2xl border transition-all cursor-pointer flex items-center justify-between gap-2.5 hover:border-neutral-600 ${
                  isMe
                    ? 'bg-emerald-950/30 border-emerald-500/50 shadow-md'
                    : isTop3
                    ? 'bg-neutral-900/90 border-neutral-800 hover:bg-neutral-850'
                    : 'bg-neutral-900 border-neutral-800/80 hover:bg-neutral-850'
                }`}
              >
                {/* Left side: Rank & Avatar & Details */}
                <div className="flex items-center gap-3 min-w-0">
                  {/* Rank badge */}
                  <div className="w-7 text-center shrink-0">
                    {item.rank === 1 ? (
                      <span className="text-lg">👑</span>
                    ) : item.rank === 2 ? (
                      <span className="text-lg">🥈</span>
                    ) : item.rank === 3 ? (
                      <span className="text-lg">🥉</span>
                    ) : (
                      <span className="text-xs font-bold font-mono text-neutral-400">
                        #{item.rank}
                      </span>
                    )}
                  </div>

                  {/* Avatar */}
                  <div className="relative shrink-0">
                    <img
                      src={item.user.avatar}
                      alt={item.user.name}
                      className="w-10 h-10 rounded-xl object-cover border border-neutral-700 shadow-sm"
                      referrerPolicy="no-referrer"
                    />
                    <span className="absolute -bottom-1 -right-1 text-xs">
                      {item.tier.badge}
                    </span>
                  </div>

                  {/* Name & Position */}
                  <div className="min-w-0">
                    <div className="flex items-center gap-1.5">
                      <span className="text-xs font-bold text-white truncate hover:text-emerald-400">
                        {item.user.name}
                      </span>
                      {isMe && (
                        <span className="text-[9px] font-bold px-1.5 py-0.2 rounded bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                          أنت
                        </span>
                      )}
                    </div>
                    <div className="flex items-center gap-2 text-[10px] text-neutral-400 mt-0.5">
                      <span>{item.user.position.split(' ')[0]}</span>
                      <span>•</span>
                      <span>{item.matchesPlayed} ماتش</span>
                      {item.lateCancellations > 0 && (
                        <>
                          <span>•</span>
                          <span className="text-rose-400">{item.lateCancellations} اعتذار</span>
                        </>
                      )}
                    </div>
                  </div>
                </div>

                {/* Right side: Points & Star breakdown */}
                <div className="text-left shrink-0 space-y-0.5">
                  <div className="flex items-center justify-end gap-1">
                    <span className="text-sm font-black font-mono text-amber-400">
                      {item.points}
                    </span>
                    <span className="text-[10px] text-neutral-400 font-semibold">نقطة</span>
                  </div>

                  <div className="flex items-center justify-end gap-1.5 text-[10px]">
                    <span className="flex items-center gap-0.5 font-bold text-amber-300">
                      <Star className="w-2.5 h-2.5 fill-current" />
                      <span>{item.overallRating}</span>
                    </span>
                    <span className="text-neutral-600">|</span>
                    <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded-full border ${item.tier.bg} ${item.tier.color} ${item.tier.border}`}>
                      {item.tier.name.split(' ')[0]}
                    </span>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Points Calculation Explainer Footer */}
      <div className="rounded-2xl p-3 bg-neutral-950/80 border border-neutral-800 text-[11px] text-neutral-400 space-y-1.5">
        <span className="font-bold text-neutral-300 flex items-center gap-1 text-xs">
          <Zap className="w-3.5 h-3.5 text-amber-400" />
          <span>إزاي بتتحسب نقاط وتصنيف اللاعبين؟ 💡</span>
        </span>
        <p className="leading-relaxed">
          • <strong className="text-neutral-200">+15 نقطة</strong> لكل ماتش تلعبه وتحضره.
          <br />
          • <strong className="text-neutral-200">+50 نقطة</strong> لكل نجمة في متوسط تقييمك العام من زمايلك (الالتزام والمستوى).
          <br />
          • <strong className="text-neutral-200">+5 نقاط بونص</strong> لكل تقييم موثق يدخل لك.
          <br />
          • <strong className="text-rose-400">-30 نقطة خصم</strong> عند الاعتذار المتأخر بعد الميعاد المحدد.
        </p>
      </div>
    </div>
  );
};
