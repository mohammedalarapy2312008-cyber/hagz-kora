import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { UserCheck, Sparkles, AlertTriangle, Users, Smartphone, RefreshCw, Star } from 'lucide-react';

interface QuickTestBarProps {
  deviceType: 'ios' | 'android';
  setDeviceType: (t: 'ios' | 'android') => void;
  isFramed: boolean;
  setIsFramed: (f: boolean) => void;
}

export const QuickTestBar: React.FC<QuickTestBarProps> = ({
  deviceType,
  setDeviceType,
  isFramed,
  setIsFramed
}) => {
  const { 
    currentUser, 
    allUsers, 
    switchUser, 
    matches, 
    simulateWaitlistJump, 
    simulateAlmostFull, 
    simulateCancelRisk,
    markMatchAsFinished
  } = useApp();

  const [isOpen, setIsOpen] = useState(false);

  return (
    <aside 
      aria-label="لوحة اختبار ومحاكاة السيناريوهات السريعة"
      className="w-full bg-neutral-900 border-b border-neutral-800 text-xs px-3 py-2 text-neutral-300 z-50 transition-all select-none shadow-md"
    >
      <div className="max-w-4xl mx-auto flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 font-semibold">
            <Sparkles className="w-3.5 h-3.5" />
            أدوات تجربة السيناريوهات
          </span>
          <span className="hidden sm:inline text-neutral-400">
            أنت مسجل حالياً كـ: <strong className="text-white">{currentUser.name}</strong> ({currentUser.position})
          </span>
        </div>

        <div className="flex items-center gap-1.5 flex-wrap">
          {/* Quick User Switcher */}
          <div className="flex items-center gap-1 bg-neutral-800 px-2 py-1 rounded-md border border-neutral-700">
            <UserCheck className="w-3.5 h-3.5 text-neutral-400" />
            <select
              value={currentUser.id}
              onChange={(e) => switchUser(e.target.value)}
              className="bg-transparent text-white text-xs outline-none cursor-pointer"
            >
              {allUsers.map(u => (
                <option key={u.id} value={u.id} className="bg-neutral-800 text-white">
                  {u.name} ({u.lateCancellations > 0 ? `⚠️ ${u.lateCancellations} اعتذار` : 'ملتزم'})
                </option>
              ))}
            </select>
          </div>

          {/* Toggle Device Frame */}
          <button
            onClick={() => setIsFramed(!isFramed)}
            className="flex items-center gap-1 px-2 py-1 rounded bg-neutral-800 hover:bg-neutral-700 border border-neutral-700 text-neutral-200 transition-colors"
            title="تبديل وضع إطار الموبايل أو ملء الشاشة"
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span>{isFramed ? 'شاشة كاملة' : 'إطار موبايل'}</span>
          </button>

          {/* iOS / Android Frame Switch */}
          {isFramed && (
            <div className="flex items-center bg-neutral-800 rounded border border-neutral-700 p-0.5">
              <button
                onClick={() => setDeviceType('ios')}
                className={`px-2 py-0.5 rounded text-[11px] font-medium transition-colors ${deviceType === 'ios' ? 'bg-neutral-700 text-white font-bold' : 'text-neutral-400 hover:text-white'}`}
              >
                iOS
              </button>
              <button
                onClick={() => setDeviceType('android')}
                className={`px-2 py-0.5 rounded text-[11px] font-medium transition-colors ${deviceType === 'android' ? 'bg-neutral-700 text-white font-bold' : 'text-neutral-400 hover:text-white'}`}
              >
                Android
              </button>
            </div>
          )}

          {/* Toggle Action drawer */}
          <button
            onClick={() => setIsOpen(!isOpen)}
            className="px-2 py-1 rounded bg-emerald-600 hover:bg-emerald-500 text-white font-medium text-xs transition-colors flex items-center gap-1"
          >
            <span>محاكاة الحالات</span>
            <span>{isOpen ? '▲' : '▼'}</span>
          </button>
        </div>
      </div>

      {isOpen && (
        <div className="max-w-4xl mx-auto mt-2 pt-2 border-t border-neutral-800 flex flex-wrap gap-2 items-center justify-between">
          <p className="text-neutral-400 text-[11px]">
            جرب الميزات المعقدة بضغطة زر واحدة لمعاينة رد فعل الأبلكيشن والإشعارات:
          </p>
          <div className="flex items-center gap-1.5 flex-wrap">
            <button
              onClick={() => simulateWaitlistJump(matches[1]?.id || matches[0]?.id)}
              className="flex items-center gap-1 px-2.5 py-1 rounded bg-blue-900/60 hover:bg-blue-800/80 text-blue-200 border border-blue-500/30 text-xs transition-colors"
            >
              <Users className="w-3.5 h-3.5" />
              <span>محاكاة اعتذار لاعب أساسي وترقية الـ Waitlist تلقائياً</span>
            </button>

            <button
              onClick={() => simulateAlmostFull(matches[0]?.id)}
              className="flex items-center gap-1 px-2.5 py-1 rounded bg-amber-900/60 hover:bg-amber-800/80 text-amber-200 border border-amber-500/30 text-xs transition-colors"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>إشعار "العدد قرب يكمل (باقي 1 أو 2)"</span>
            </button>

            <button
              onClick={() => simulateCancelRisk(matches[2]?.id || matches[0]?.id)}
              className="flex items-center gap-1 px-2.5 py-1 rounded bg-rose-900/60 hover:bg-rose-800/80 text-rose-200 border border-rose-500/30 text-xs transition-colors"
            >
              <AlertTriangle className="w-3.5 h-3.5" />
              <span>إشعار "الماتش مهدد بالإلغاء" عند آخر ميعاد</span>
            </button>

            <button
              onClick={() => {
                const targetMatch = matches.find(m => !m.isFinished) || matches[0];
                if (targetMatch) markMatchAsFinished(targetMatch.id);
              }}
              className="flex items-center gap-1 px-2.5 py-1 rounded bg-amber-900/60 hover:bg-amber-800/80 text-amber-200 border border-amber-500/30 text-xs transition-colors font-medium"
            >
              <Star className="w-3.5 h-3.5 fill-current" />
              <span>إنهاء الماتش وتفعيل تقييم النجوم ⭐</span>
            </button>
          </div>
        </div>
      )}
    </aside>
  );
};
