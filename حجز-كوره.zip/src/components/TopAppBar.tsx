import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { ChevronDown, Bell, Check, ShieldCheck, Plus, Trophy, QrCode } from 'lucide-react';
import { ShareModal } from './ShareModal';

interface TopAppBarProps {
  onOpenNotifications: () => void;
  onOpenProfile: () => void;
}

export const TopAppBar: React.FC<TopAppBarProps> = ({ onOpenNotifications, onOpenProfile }) => {
  const { 
    currentUser, 
    groups, 
    selectedGroup, 
    setSelectedGroup, 
    notifications, 
    setActiveTab,
    isUserGroupAdmin
  } = useApp();

  const [isGroupDropdownOpen, setIsGroupDropdownOpen] = useState(false);
  const [showAppShareModal, setShowAppShareModal] = useState(false);
  const unreadCount = notifications.filter(n => !n.read).length;
  const isAdmin = selectedGroup ? isUserGroupAdmin(selectedGroup.id) : false;

  return (
    <header className="sticky top-0 z-30 bg-neutral-900/90 backdrop-blur-md border-b border-neutral-800/80 px-3 py-2.5 shrink-0 select-none">
      <div className="flex items-center justify-between gap-2 max-w-md mx-auto">
        {/* Brand / Logo */}
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-emerald-500 to-emerald-700 flex items-center justify-center text-white shadow-md shadow-emerald-950 font-display font-black text-sm">
            ⚽
          </div>
          <span className="font-display font-black text-base text-white tracking-wide">
            كورتنا
          </span>
        </div>

        {/* Group Selector Dropdown */}
        <div className="relative flex-1 max-w-[215px]">
          <button
            onClick={() => setIsGroupDropdownOpen(!isGroupDropdownOpen)}
            className="w-full flex items-center justify-between gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-neutral-850 via-neutral-900 to-neutral-850 hover:from-neutral-800 hover:to-neutral-800 border-2 border-emerald-500/50 hover:border-emerald-400 text-right shadow-md shadow-emerald-950/50 transition-all active:scale-[0.98]"
            title="اختيار الجروب ومتابعة الماتشات"
          >
            <div className="flex items-center gap-1.5 truncate">
              {isAdmin ? (
                <span title="أنت أدمن في هذا الجروب" className="p-0.5 rounded-md bg-emerald-500/20 text-emerald-400 shrink-0">
                  <ShieldCheck className="w-3.5 h-3.5" />
                </span>
              ) : (
                <span className="w-2 h-2 rounded-full bg-emerald-400 shadow-[0_0_8px_rgba(52,211,153,0.8)] shrink-0 animate-pulse" />
              )}
              <span className="text-xs font-bold text-white truncate">
                {selectedGroup ? selectedGroup.name : 'كل الماتشات'}
              </span>
            </div>
            <ChevronDown className={`w-3.5 h-3.5 text-emerald-400 shrink-0 transition-transform ${isGroupDropdownOpen ? 'rotate-180' : ''}`} />
          </button>

          {/* Dropdown Menu */}
          {isGroupDropdownOpen && (
            <div className="absolute top-full mt-1.5 right-0 left-0 bg-neutral-850 rounded-xl border border-neutral-700 shadow-2xl p-1 z-50 animate-in fade-in zoom-in-95 duration-150">
              <div className="text-[10px] font-bold text-neutral-400 px-2 py-1 uppercase tracking-wider">
                جروباتك
              </div>
              
              <button
                onClick={() => {
                  setSelectedGroup(null);
                  setIsGroupDropdownOpen(false);
                }}
                className={`w-full flex items-center justify-between px-2.5 py-2 rounded-lg text-xs font-medium transition-colors text-right ${!selectedGroup ? 'bg-emerald-500/10 text-emerald-400' : 'text-neutral-200 hover:bg-neutral-800'}`}
              >
                <span>🌍 كل الماتشات (الكل)</span>
                {!selectedGroup && <Check className="w-3.5 h-3.5 text-emerald-400" />}
              </button>

              {groups.map(group => {
                const isSelected = selectedGroup?.id === group.id;
                const userIsAdmin = isUserGroupAdmin(group.id);
                return (
                  <button
                    key={group.id}
                    onClick={() => {
                      setSelectedGroup(group);
                      setIsGroupDropdownOpen(false);
                    }}
                    className={`w-full flex items-center justify-between px-2.5 py-2 rounded-lg text-xs font-medium transition-colors text-right ${isSelected ? 'bg-emerald-500/10 text-emerald-400' : 'text-neutral-200 hover:bg-neutral-800'}`}
                  >
                    <div className="flex items-center gap-1.5 truncate">
                      {userIsAdmin && <span className="text-[10px] px-1 rounded bg-emerald-500/20 text-emerald-400 font-bold shrink-0">أدمن</span>}
                      <span className="truncate">{group.name}</span>
                    </div>
                    {isSelected && <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0" />}
                  </button>
                );
              })}

              <div className="border-t border-neutral-700/60 my-1 pt-1">
                <button
                  onClick={() => {
                    setIsGroupDropdownOpen(false);
                    setActiveTab('groups');
                  }}
                  className="w-full flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-semibold text-emerald-400 hover:bg-emerald-500/10 transition-colors text-right"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>إنشاء أو استكشاف الجروبات</span>
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Right slot actions */}
        <div className="flex items-center gap-1">
          {/* App QR & Share Button */}
          <button
            onClick={() => setShowAppShareModal(true)}
            className="w-9 h-9 rounded-full flex items-center justify-center text-emerald-400 hover:text-emerald-300 hover:bg-neutral-800 relative transition-colors"
            title="مشاركة التطبيق برمز QR وواتساب 📲"
            aria-label="مشاركة التطبيق"
          >
            <QrCode className="w-4.5 h-4.5 stroke-[2]" />
          </button>

          {/* Leaderboard Button */}
          <button
            onClick={() => setActiveTab('leaderboard')}
            className="w-9 h-9 rounded-full flex items-center justify-center text-amber-400 hover:text-amber-300 hover:bg-neutral-800 relative transition-colors"
            title="قائمة أفضل اللاعبين والترتيب 🏆"
            aria-label="قائمة الترتيب"
          >
            <Trophy className="w-4.5 h-4.5 stroke-[2]" />
          </button>

          {/* Notification Button */}
          <button
            onClick={onOpenNotifications}
            className="w-9 h-9 rounded-full flex items-center justify-center text-neutral-300 hover:text-white hover:bg-neutral-800 relative transition-colors"
            aria-label="الإشعارات"
          >
            <Bell className="w-5 h-5 stroke-[1.8]" />
            {unreadCount > 0 && (
              <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-emerald-500 ring-2 ring-neutral-900 animate-pulse" />
            )}
          </button>

          {/* User Profile Avatar */}
          <button
            onClick={onOpenProfile}
            className="w-8 h-8 rounded-full overflow-hidden border border-neutral-700 ring-1 ring-emerald-500/30 hover:ring-emerald-400 transition-all ml-1 shrink-0"
            title={currentUser.name}
          >
            <img
              src={currentUser.avatar}
              alt={currentUser.name}
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
              onError={(e) => {
                // fallback
                (e.target as HTMLElement).style.display = 'none';
              }}
            />
          </button>
        </div>
      </div>

      {/* App Share Modal */}
      {showAppShareModal && (
        <ShareModal
          isOpen={showAppShareModal}
          onClose={() => setShowAppShareModal(false)}
          type="app"
        />
      )}
    </header>
  );
};
