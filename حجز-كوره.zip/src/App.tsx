import React, { useState } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { MobileFrame } from './components/MobileFrame';
import { TopAppBar } from './components/TopAppBar';
import { BottomNavBar } from './components/BottomNavBar';
import { MatchCard } from './components/MatchCard';
import { GroupsView } from './components/GroupsView';
import { NotificationsSheet } from './components/NotificationsSheet';
import { UserProfileModal } from './components/UserProfileModal';
import { CreateMatchModal } from './components/CreateMatchModal';
import { LoginModal } from './components/LoginModal';
import { QuickTestBar } from './components/QuickTestBar';
import { LeaderboardView } from './components/LeaderboardView';
import { ShareModal, ShareType } from './components/ShareModal';
import { 
  Plus, 
  Calendar, 
  MapPin, 
  Users, 
  Sparkles, 
  Filter, 
  CheckCircle2, 
  Flame, 
  LogIn, 
  LogOut,
  RefreshCw,
  Star,
  Award,
  Trophy,
  QrCode,
  Share2,
  Search,
  X
} from 'lucide-react';

const AppContent: React.FC = () => {
  const { 
    currentUser, 
    matches, 
    selectedGroup, 
    activeTab, 
    setActiveTab, 
    notifications, 
    allUsers,
    getUserRatingStats,
    getUserRatings
  } = useApp();

  const [deviceType, setDeviceType] = useState<'ios' | 'android'>('ios');
  const [isFramed, setIsFramed] = useState<boolean>(true);
  
  // Modals state
  const [inspectUserId, setInspectUserId] = useState<string | null>(null);
  const [isProfileModalOpen, setIsProfileModalOpen] = useState(false);
  const [isCreateMatchModalOpen, setIsCreateMatchModalOpen] = useState(false);
  const [isLoginModalOpen, setIsLoginModalOpen] = useState(false);
  const [shareModalState, setShareModalState] = useState<{
    isOpen: boolean;
    type: ShareType;
    group?: any;
  }>({ isOpen: false, type: 'app' });

  // Match feed filters & search
  const [matchFilter, setMatchFilter] = useState<'all' | 'open' | 'completed'>('all');
  const [searchQuery, setSearchQuery] = useState('');

  // Filter matches by selected group, sub-filter, and search query
  const filteredMatches = matches.filter(m => {
    if (selectedGroup && m.groupId !== selectedGroup.id) return false;
    if (matchFilter === 'open' && m.isCompleted) return false;
    if (matchFilter === 'completed' && !m.isCompleted) return false;
    
    if (searchQuery.trim()) {
      const q = searchQuery.trim().toLowerCase();
      const matchPitch = m.pitchName?.toLowerCase().includes(q);
      const matchLoc = m.pitchLocationText?.toLowerCase().includes(q);
      const matchCreator = m.creatorName?.toLowerCase().includes(q);
      const matchNotes = m.notes?.toLowerCase().includes(q);
      if (!matchPitch && !matchLoc && !matchCreator && !matchNotes) {
        return false;
      }
    }
    return true;
  });

  return (
    <div className="w-full min-h-screen bg-neutral-950 flex flex-col font-['Cairo',sans-serif]">
      {/* Top Test Assistant & Scenario Simulation Bar */}
      <QuickTestBar
        deviceType={deviceType}
        setDeviceType={setDeviceType}
        isFramed={isFramed}
        setIsFramed={setIsFramed}
      />

      {/* Mobile Experience Shell */}
      <MobileFrame
        deviceType={deviceType}
        isFramed={isFramed}
        onNotificationClick={() => setActiveTab('notifications')}
      >
        {/* Sticky Mobile Top App Bar */}
        <TopAppBar
          onOpenNotifications={() => setActiveTab('notifications')}
          onOpenProfile={() => {
            setInspectUserId(currentUser.id);
            setIsProfileModalOpen(true);
          }}
        />

        {/* Scrollable Viewport Container */}
        <main className="flex-1 overflow-y-auto px-3.5 py-3 space-y-3">
          {/* TAB 1: MATCHES FEED */}
          {activeTab === 'matches' && (
            <div className="space-y-3">
              {/* Group Banner if selected, or General Hero Header */}
              {selectedGroup ? (
                <div className="rounded-2xl bg-neutral-900 border border-neutral-800 p-3 shadow-md flex items-center justify-between">
                  <div className="flex items-center gap-2.5 truncate">
                    <img
                      src={selectedGroup.avatar}
                      alt={selectedGroup.name}
                      className="w-10 h-10 rounded-xl object-cover border border-neutral-700 shrink-0"
                      referrerPolicy="no-referrer"
                    />
                    <div className="truncate text-right">
                      <h2 className="text-xs font-bold text-white truncate">{selectedGroup.name}</h2>
                      <p className="text-[10px] text-neutral-400 truncate">
                        {selectedGroup.isPublic ? 'جروب عام' : 'جروب خاص'} • {selectedGroup.members.length} لاعب مسجل
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-1.5 shrink-0">
                    <button
                      onClick={() => setShareModalState({ isOpen: true, type: 'group', group: selectedGroup })}
                      className="p-2 rounded-xl bg-neutral-800/80 hover:bg-neutral-800 text-neutral-300 hover:text-emerald-400 border border-neutral-700/80 text-xs font-semibold flex items-center gap-1 transition-colors"
                      title="مشاركة الجروب على واتساب وبرمز QR"
                    >
                      <QrCode className="w-3.5 h-3.5 text-emerald-400" />
                      <span className="hidden sm:inline">QR</span>
                    </button>

                    <button
                      onClick={() => setActiveTab('leaderboard')}
                      className="px-2 py-1.5 rounded-xl bg-amber-500/15 hover:bg-amber-500/25 text-amber-400 border border-amber-500/30 text-xs font-bold flex items-center gap-1 transition-colors"
                      title="ترتيب أفضل لاعبي هذا الجروب"
                    >
                      <Trophy className="w-3.5 h-3.5" />
                      <span className="hidden sm:inline">الترتيب</span>
                    </button>

                    <button
                      onClick={() => setIsCreateMatchModalOpen(true)}
                      className="px-2.5 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold flex items-center gap-1 shadow-md shadow-emerald-950 transition-colors"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>حجز جديد</span>
                    </button>
                  </div>
                </div>
              ) : (
                <div className="relative rounded-2xl overflow-hidden border border-neutral-800 shadow-lg min-h-[110px] flex items-center p-3.5 bg-gradient-to-r from-neutral-900 via-neutral-900/90 to-neutral-950">
                  <img
                    src="/src/assets/images/pitch_night_lights_1790105737855.jpg"
                    alt="ملعب كورة"
                    className="absolute inset-0 w-full h-full object-cover opacity-25 mix-blend-luminosity"
                    referrerPolicy="no-referrer"
                  />
                  <div className="relative z-10 text-right space-y-1">
                    <span className="text-[10px] font-bold text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 px-2 py-0.5 rounded-full inline-block">
                      تنسيق ماتشات الكورة ⚽
                    </span>
                    <h1 className="text-sm font-black font-display text-white">
                      يا كابتن، جمع شلتك واحجز ماتشك الجاي
                    </h1>
                    <p className="text-[11px] text-neutral-300">
                      متابعة حية للردود، كروت واضحة للميعاد والفلوس، ونظام Waitlist تلقائي.
                    </p>
                  </div>
                </div>
              )}

              {/* ========================================================================= */}
              {/* شريط البحث البارز بألوان مميزة وتفاعلية */}
              {/* ========================================================================= */}
              <div className="relative group">
                <div className="relative flex items-center gap-2 p-1.5 pr-2.5 rounded-2xl bg-gradient-to-r from-neutral-900 via-neutral-900 to-neutral-950 border-2 border-emerald-500/50 hover:border-emerald-400 focus-within:border-emerald-400 focus-within:ring-4 focus-within:ring-emerald-500/25 shadow-xl shadow-emerald-950/40 transition-all duration-200">
                  {/* Glowing background accent */}
                  <div className="absolute -inset-0.5 bg-gradient-to-r from-emerald-500/20 via-teal-500/10 to-transparent rounded-2xl blur-sm -z-10 pointer-events-none opacity-70 group-hover:opacity-100 transition-opacity" />
                  
                  {/* Search Icon with Glowing Gradient Badge */}
                  <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-emerald-500 to-teal-600 text-white flex items-center justify-center shadow-md shadow-emerald-950/60 shrink-0 ring-1 ring-white/20">
                    <Search className="w-4 h-4 stroke-[2.5]" />
                  </div>

                  {/* Input field */}
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="ابحث عن ماتش، ملعب، منطقة، أو كابتن..."
                    className="flex-1 bg-transparent text-xs text-white placeholder-neutral-400 outline-none font-semibold text-right"
                  />

                  {/* Clear Button */}
                  {searchQuery && (
                    <button
                      onClick={() => setSearchQuery('')}
                      className="w-6 h-6 rounded-full bg-neutral-800 hover:bg-neutral-700 text-neutral-300 hover:text-white flex items-center justify-center transition-colors shrink-0"
                      title="مسح البحث"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  )}

                  {/* Results Count Badge */}
                  {searchQuery && (
                    <span className="text-[10px] font-black text-emerald-300 bg-emerald-500/20 border border-emerald-500/40 px-2 py-0.5 rounded-lg shrink-0 shadow-sm">
                      {filteredMatches.length} ماتش
                    </span>
                  )}
                </div>
              </div>

              {/* Match Segmented Filter Bar */}
              <div className="flex items-center justify-between gap-1.5 p-1 bg-neutral-900/90 rounded-2xl border border-neutral-800 shadow-sm">
                <button
                  onClick={() => setMatchFilter('all')}
                  className={`flex-1 py-2 text-xs rounded-xl transition-all ${
                    matchFilter === 'all' 
                      ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow-md shadow-emerald-950 font-black' 
                      : 'text-neutral-400 hover:text-neutral-200 font-semibold'
                  }`}
                >
                  الكل ({matches.length})
                </button>
                <button
                  onClick={() => setMatchFilter('open')}
                  className={`flex-1 py-2 text-xs rounded-xl transition-all ${
                    matchFilter === 'open' 
                      ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow-md shadow-emerald-950 font-black' 
                      : 'text-neutral-400 hover:text-emerald-400 font-semibold'
                  }`}
                >
                  مفتوحة ({matches.filter(m => !m.isCompleted).length})
                </button>
                <button
                  onClick={() => setMatchFilter('completed')}
                  className={`flex-1 py-2 text-xs rounded-xl transition-all ${
                    matchFilter === 'completed' 
                      ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow-md shadow-emerald-950 font-black' 
                      : 'text-neutral-400 hover:text-neutral-200 font-semibold'
                  }`}
                >
                  اكتملت ✅ ({matches.filter(m => m.isCompleted).length})
                </button>
              </div>

              {/* Matches List */}
              {filteredMatches.length === 0 ? (
                <div className="p-8 text-center bg-neutral-900 rounded-3xl border border-neutral-800 text-neutral-400 text-xs space-y-2">
                  <Calendar className="w-8 h-8 mx-auto text-neutral-600 stroke-[1.5]" />
                  <p>مفيش بوستات حجز مطابقة للفلتر في هذا الجروب</p>
                  <button
                    onClick={() => setIsCreateMatchModalOpen(true)}
                    className="mt-2 px-3 py-1.5 rounded-xl bg-emerald-600 text-white font-bold text-xs inline-flex items-center gap-1"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>أنشئ أول بوست حجز للماتش</span>
                  </button>
                </div>
              ) : (
                filteredMatches.map(match => (
                  <MatchCard
                    key={match.id}
                    match={match}
                    onViewUserProfile={(userId) => {
                      setInspectUserId(userId);
                      setIsProfileModalOpen(true);
                    }}
                  />
                ))
              )}
            </div>
          )}

          {/* TAB 2: GROUPS VIEW */}
          {activeTab === 'groups' && (
            <GroupsView
              onViewUserProfile={(userId) => {
                setInspectUserId(userId);
                setIsProfileModalOpen(true);
              }}
            />
          )}

          {/* TAB 2.5: LEADERBOARD VIEW (ترتيب أفضل اللاعبين) */}
          {activeTab === 'leaderboard' && (
            <LeaderboardView
              onViewUserProfile={(userId) => {
                setInspectUserId(userId);
                setIsProfileModalOpen(true);
              }}
            />
          )}

          {/* TAB 3: CREATE MATCH */}
          {activeTab === 'create_match' && (
            <div className="p-2">
              <CreateMatchModal onClose={() => setActiveTab('matches')} />
            </div>
          )}

          {/* TAB 4: NOTIFICATIONS */}
          {activeTab === 'notifications' && (
            <NotificationsSheet
              onSelectMatch={() => setActiveTab('matches')}
            />
          )}

          {/* TAB 5: PROFILE VIEW */}
          {activeTab === 'profile' && (() => {
            const myRatingStats = getUserRatingStats(currentUser.id);
            return (
              <div className="space-y-3 pb-8">
                <div className="p-4 rounded-3xl bg-neutral-900 border border-neutral-800 text-center space-y-3 shadow-xl">
                  <div className="w-20 h-20 rounded-2xl overflow-hidden mx-auto ring-2 ring-emerald-500/40 border border-neutral-700 shadow-md">
                    <img
                      src={currentUser.avatar}
                      alt={currentUser.name}
                      className="w-full h-full object-cover"
                      referrerPolicy="no-referrer"
                    />
                  </div>
                  <div>
                    <h2 className="text-base font-bold text-white">{currentUser.name}</h2>
                    <div className="flex items-center justify-center gap-1.5 mt-1">
                      <span className="text-xs font-semibold text-emerald-400">
                        {currentUser.position}
                      </span>
                      <span className="text-neutral-600">•</span>
                      <span className="text-xs font-bold text-amber-400 flex items-center gap-0.5">
                        <Star className="w-3 h-3 fill-current" />
                        <span>{myRatingStats.averageOverall}</span>
                        <span className="text-[10px] text-neutral-400 font-normal">
                          ({myRatingStats.totalRatingsCount})
                        </span>
                      </span>
                    </div>
                    <p className="text-xs text-neutral-400 mt-1">
                      "{currentUser.bio || 'لاعب كورة ملتزم'}"
                    </p>
                  </div>

                  <div className="pt-2 border-t border-neutral-800 flex items-center justify-center gap-2">
                    <button
                      onClick={() => {
                        setInspectUserId(currentUser.id);
                        setIsProfileModalOpen(true);
                      }}
                      className="flex-1 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition-colors"
                    >
                      تعديل البروفايل وإعدادات الخصوصية
                    </button>
                    <button
                      onClick={() => setIsLoginModalOpen(true)}
                      className="px-3 py-2 rounded-xl bg-neutral-800 hover:bg-neutral-750 text-neutral-300 text-xs font-semibold transition-colors flex items-center gap-1"
                      title="تسجيل دخول برقم هاتف آخر"
                    >
                      <LogIn className="w-3.5 h-3.5" />
                      <span>تبديل</span>
                    </button>
                  </div>
                </div>

                {/* Stats Summary Card (3 columns) */}
                <div className="p-3.5 rounded-2xl bg-neutral-900 border border-neutral-800 space-y-2">
                  <span className="text-xs font-bold text-neutral-300 block">
                    إحصائياتك وسجل التقييم 📊
                  </span>
                  <div className="grid grid-cols-3 gap-2">
                    <div className="p-2.5 rounded-xl bg-neutral-950 border border-neutral-800 text-center">
                      <span className="text-lg font-bold font-display text-emerald-400">
                        {currentUser.matchesPlayed}
                      </span>
                      <span className="text-[10px] text-neutral-400 block mt-0.5">
                        ماتش ملعوب
                      </span>
                    </div>
                    <div className="p-2.5 rounded-xl bg-neutral-950 border border-neutral-800 text-center">
                      <span className="text-lg font-bold font-display text-amber-400 flex items-center justify-center gap-0.5">
                        <Star className="w-3.5 h-3.5 fill-current" />
                        <span>{myRatingStats.averageOverall}</span>
                      </span>
                      <span className="text-[10px] text-neutral-400 block mt-0.5">
                        متوسط التقييم
                      </span>
                    </div>
                    <div className="p-2.5 rounded-xl bg-neutral-950 border border-neutral-800 text-center">
                      <span className={`text-lg font-bold font-display ${currentUser.lateCancellations > 0 ? 'text-rose-400' : 'text-emerald-400'}`}>
                        {currentUser.lateCancellations}
                      </span>
                      <span className="text-[10px] text-neutral-400 block mt-0.5">
                        اعتذار متأخر
                      </span>
                    </div>
                  </div>

                  {/* Rating Dimensions Breakdown */}
                  <div className="pt-2 border-t border-neutral-800/80 grid grid-cols-2 gap-2 text-xs">
                    <div className="p-2 rounded-xl bg-neutral-950/70 border border-neutral-800/70">
                      <div className="text-[10px] text-neutral-400">متوسط الالتزام ⏱️</div>
                      <div className="text-sm font-bold text-amber-400 mt-0.5">
                        {myRatingStats.averageCommitment} / 5.0
                      </div>
                    </div>
                    <div className="p-2 rounded-xl bg-neutral-950/70 border border-neutral-800/70">
                      <div className="text-[10px] text-neutral-400">متوسط المستوى ⚽</div>
                      <div className="text-sm font-bold text-emerald-400 mt-0.5">
                        {myRatingStats.averageSkill} / 5.0
                      </div>
                    </div>
                  </div>
                </div>

                {/* Leaderboard CTA from Profile */}
                <div className="p-3.5 rounded-2xl bg-gradient-to-r from-amber-500/15 via-neutral-900 to-neutral-900 border border-amber-500/30 flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className="w-9 h-9 rounded-xl bg-amber-500/20 border border-amber-500/30 flex items-center justify-center text-amber-400 shrink-0">
                      <Trophy className="w-5 h-5" />
                    </div>
                    <div>
                      <span className="text-xs font-bold text-white block">قوائم ترتيب اللاعبين 🏆</span>
                      <span className="text-[10px] text-amber-300/80 block">شوف ترتيبك في جروباتك وعلى مستوى مصر</span>
                    </div>
                  </div>
                  <button
                    onClick={() => setActiveTab('leaderboard')}
                    className="px-3 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-neutral-950 text-xs font-bold transition-colors shrink-0 shadow-sm"
                  >
                    عرض الترتيب
                  </button>
                </div>

                {/* Share App CTA in Profile (QR & WhatsApp) */}
                <div className="p-3.5 rounded-2xl bg-gradient-to-r from-emerald-500/15 via-neutral-900 to-neutral-900 border border-emerald-500/30 flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className="w-9 h-9 rounded-xl bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center text-emerald-400 shrink-0">
                      <QrCode className="w-5 h-5" />
                    </div>
                    <div>
                      <span className="text-xs font-bold text-white block">مشاركة تطبيق كورتنا 📲</span>
                      <span className="text-[10px] text-emerald-300/80 block">شارك التطبيق برمز QR أو عبر واتساب مع أصحابك</span>
                    </div>
                  </div>
                  <button
                    onClick={() => setShareModalState({ isOpen: true, type: 'app' })}
                    className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition-colors shrink-0 shadow-sm flex items-center gap-1"
                  >
                    <Share2 className="w-3.5 h-3.5" />
                    <span>مشاركة</span>
                  </button>
                </div>

                {/* Privacy Status */}
              <div className="p-3.5 rounded-2xl bg-neutral-900 border border-neutral-800 flex items-center justify-between">
                <div>
                  <span className="text-xs font-bold text-white block">خصوصية رقم الموبايل:</span>
                  <span className="text-[10px] text-neutral-400 block">
                    {currentUser.hidePhone ? 'رقمك مخفي عن باقي أعضاء الجروبات' : 'رقمك ظاهر لباقي الأعضاء للتواصل'}
                  </span>
                </div>
                <button
                  onClick={() => {
                    setInspectUserId(currentUser.id);
                    setIsProfileModalOpen(true);
                  }}
                  className="text-xs text-emerald-400 font-semibold"
                >
                  تغيير
                </button>
              </div>
            </div>
          );
        })()}
        </main>

        {/* Fixed Bottom Navigation Bar */}
        <BottomNavBar />
      </MobileFrame>

      {/* Floating Modals */}
      {isProfileModalOpen && (
        <UserProfileModal
          userId={inspectUserId}
          onClose={() => {
            setIsProfileModalOpen(false);
            setInspectUserId(null);
          }}
        />
      )}

      {isCreateMatchModalOpen && (
        <CreateMatchModal
          onClose={() => setIsCreateMatchModalOpen(false)}
        />
      )}

      {isLoginModalOpen && (
        <LoginModal
          isOpen={isLoginModalOpen}
          onClose={() => setIsLoginModalOpen(false)}
        />
      )}

      {/* Share Modal (Group / App) */}
      {shareModalState.isOpen && (
        <ShareModal
          isOpen={shareModalState.isOpen}
          onClose={() => setShareModalState(prev => ({ ...prev, isOpen: false }))}
          type={shareModalState.type}
          group={shareModalState.group}
        />
      )}
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}
