import { User, Group, MatchPost, AppNotification, JoinRequest, PlayerRating } from '../types';

export const INITIAL_USERS: User[] = [
  {
    id: 'user_1',
    name: 'كابتن محمد العرابي',
    phone: '01012345678',
    avatar: '/src/assets/images/captain_avatar_1790105748587.jpg',
    position: 'مهاجم (رأس حربة)',
    matchesPlayed: 48,
    lateCancellations: 0,
    hidePhone: false,
    bio: 'بلعب هجوم ومبحبش الميس باص، ملتزم بالمواعيد جداً.',
    ratingStats: {
      averageOverall: 4.9,
      averageCommitment: 5.0,
      averageSkill: 4.8,
      totalRatingsCount: 16
    }
  },
  {
    id: 'user_2',
    name: 'عمر شريف',
    phone: '01123456789',
    avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80',
    position: 'صانع ألعاب (هاف)',
    matchesPlayed: 36,
    lateCancellations: 1,
    hidePhone: true, // Hidden number test
    bio: 'باص سليم وتكتيك عالي.',
    ratingStats: {
      averageOverall: 4.7,
      averageCommitment: 4.6,
      averageSkill: 4.8,
      totalRatingsCount: 12
    }
  },
  {
    id: 'user_3',
    name: 'مصطفى الشناوي',
    phone: '01234567890',
    avatar: 'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?w=150&auto=format&fit=crop&q=80',
    position: 'جون كيبر (حارس مرمى)',
    matchesPlayed: 52,
    lateCancellations: 0,
    hidePhone: false,
    bio: 'حارس أساسي، مفيش كورة بتعدي بسهولة.',
    ratingStats: {
      averageOverall: 4.8,
      averageCommitment: 5.0,
      averageSkill: 4.7,
      totalRatingsCount: 18
    }
  },
  {
    id: 'user_4',
    name: 'أحمد سامي',
    phone: '01511223344',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
    position: 'مساك (قلب دفاع)',
    matchesPlayed: 29,
    lateCancellations: 3, // Shows warning badge in profile
    hidePhone: false,
    bio: 'دفاع حديدي وتدخلات نظيفة.',
    ratingStats: {
      averageOverall: 3.7,
      averageCommitment: 3.1,
      averageSkill: 4.3,
      totalRatingsCount: 9
    }
  },
  {
    id: 'user_5',
    name: 'تامر حسني السعدني',
    phone: '01099887766',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80',
    position: 'وينج يمين',
    matchesPlayed: 19,
    lateCancellations: 1,
    hidePhone: false,
    bio: 'سريع وعرضيات بالمقاس.',
    ratingStats: {
      averageOverall: 4.5,
      averageCommitment: 4.5,
      averageSkill: 4.5,
      totalRatingsCount: 7
    }
  },
  {
    id: 'user_6',
    name: 'كريم عبد العزيز',
    phone: '01155443322',
    avatar: 'https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?w=150&auto=format&fit=crop&q=80',
    position: 'خط وسط مدافع (ديفندر)',
    matchesPlayed: 41,
    lateCancellations: 0,
    hidePhone: false,
    bio: 'رئة الفريق وقطع كور في نص الملعب.',
    ratingStats: {
      averageOverall: 4.8,
      averageCommitment: 4.9,
      averageSkill: 4.7,
      totalRatingsCount: 14
    }
  },
  {
    id: 'user_7',
    name: 'يوسف إبراهيم',
    phone: '01288776655',
    avatar: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=150&auto=format&fit=crop&q=80',
    position: 'باك شمال',
    matchesPlayed: 15,
    lateCancellations: 0,
    hidePhone: false,
    bio: 'عرضيات وسرعة.',
    ratingStats: {
      averageOverall: 4.4,
      averageCommitment: 4.6,
      averageSkill: 4.2,
      totalRatingsCount: 5
    }
  },
  {
    id: 'user_8',
    name: 'خالد عثمان',
    phone: '01044332211',
    avatar: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=150&auto=format&fit=crop&q=80',
    position: 'مهاجم (رأس حربة)',
    matchesPlayed: 22,
    lateCancellations: 2,
    hidePhone: false,
    bio: 'فينشر قدام الجون.',
    ratingStats: {
      averageOverall: 4.1,
      averageCommitment: 3.8,
      averageSkill: 4.4,
      totalRatingsCount: 8
    }
  },
  {
    id: 'user_9',
    name: 'هشام مجدي',
    phone: '01199001122',
    avatar: 'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?w=150&auto=format&fit=crop&q=80',
    position: 'باك يمين',
    matchesPlayed: 12,
    lateCancellations: 0,
    hidePhone: false,
    bio: 'قفل الجبهة اليمين.',
    ratingStats: {
      averageOverall: 4.6,
      averageCommitment: 4.8,
      averageSkill: 4.4,
      totalRatingsCount: 6
    }
  },
  {
    id: 'user_10',
    name: 'سيف الدين محمود',
    phone: '01555667788',
    avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&auto=format&fit=crop&q=80',
    position: 'جوكر في أي مركز',
    matchesPlayed: 33,
    lateCancellations: 0,
    hidePhone: false,
    bio: 'جاهز لأي ماتش وفي أي مكان.',
    ratingStats: {
      averageOverall: 4.7,
      averageCommitment: 4.7,
      averageSkill: 4.7,
      totalRatingsCount: 11
    }
  },
  {
    id: 'user_11',
    name: 'زياد فتحي',
    phone: '01211224455',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
    position: 'صانع ألعاب (هاف)',
    matchesPlayed: 7,
    lateCancellations: 0,
    hidePhone: false,
    bio: 'لاعب جديد عايز ينضم للجروبات.',
    ratingStats: {
      averageOverall: 4.3,
      averageCommitment: 4.5,
      averageSkill: 4.1,
      totalRatingsCount: 3
    }
  }
];

export const INITIAL_GROUPS: Group[] = [
  {
    id: 'group_1',
    name: 'حجوزات الخميس - التجمع الخامس ⚽',
    description: 'جروب ماتش كورة أسبوعي منتظم كل خميس في ملاعب التجمع، مستوى متوسط لحريف، والتزام بالروح الرياضية.',
    avatar: '/src/assets/images/pitch_night_lights_1790105737855.jpg',
    isPublic: true,
    creatorId: 'user_1',
    createdAt: '2026-01-15T18:00:00Z',
    inviteCode: 'TAGAMOA-THU-26',
    members: [
      { userId: 'user_1', role: 'creator', joinedAt: '2026-01-15T18:00:00Z' },
      { userId: 'user_2', role: 'admin', joinedAt: '2026-01-16T10:00:00Z' },
      { userId: 'user_3', role: 'member', joinedAt: '2026-01-16T11:00:00Z' },
      { userId: 'user_4', role: 'member', joinedAt: '2026-01-17T12:00:00Z' },
      { userId: 'user_5', role: 'member', joinedAt: '2026-01-18T14:00:00Z' },
      { userId: 'user_6', role: 'member', joinedAt: '2026-01-18T15:00:00Z' },
      { userId: 'user_7', role: 'member', joinedAt: '2026-01-19T16:00:00Z' },
      { userId: 'user_8', role: 'member', joinedAt: '2026-01-20T17:00:00Z' },
      { userId: 'user_9', role: 'member', joinedAt: '2026-01-20T18:00:00Z' },
      { userId: 'user_10', role: 'member', joinedAt: '2026-01-21T19:00:00Z' }
    ]
  },
  {
    id: 'group_2',
    name: 'أبطال صالات المعادي (السبت) 🏆',
    description: 'جروب خاص بالأصحاب لماتشات الصالات المغطاة والتكتيك السريع في المعادي دجلة.',
    avatar: '/src/assets/images/match_action_cairo_1790105759920.jpg',
    isPublic: false, // Private group
    creatorId: 'user_2',
    createdAt: '2026-02-01T20:00:00Z',
    inviteCode: 'MAADI-INDOOR-99',
    members: [
      { userId: 'user_2', role: 'creator', joinedAt: '2026-02-01T20:00:00Z' },
      { userId: 'user_1', role: 'admin', joinedAt: '2026-02-02T10:00:00Z' },
      { userId: 'user_3', role: 'member', joinedAt: '2026-02-02T11:00:00Z' },
      { userId: 'user_4', role: 'member', joinedAt: '2026-02-02T12:00:00Z' },
      { userId: 'user_5', role: 'member', joinedAt: '2026-02-02T13:00:00Z' },
      { userId: 'user_6', role: 'member', joinedAt: '2026-02-02T14:00:00Z' },
      { userId: 'user_7', role: 'member', joinedAt: '2026-02-02T15:00:00Z' },
      { userId: 'user_8', role: 'member', joinedAt: '2026-02-02T16:00:00Z' },
      { userId: 'user_9', role: 'member', joinedAt: '2026-02-02T17:00:00Z' },
      { userId: 'user_10', role: 'member', joinedAt: '2026-02-02T18:00:00Z' }
    ]
  },
  {
    id: 'group_3',
    name: 'شلة النادي الأهلي - مدينة نصر 🔥',
    description: 'جروب عام مفتوح للشباب الراغبين في ماتشات كورة نجيل صناعي ممتازة ومنافسة شريفة.',
    avatar: 'https://images.unsplash.com/photo-1529900241477-9dfc1c9c8119?w=400&auto=format&fit=crop&q=80',
    isPublic: true,
    creatorId: 'user_1',
    createdAt: '2026-02-10T12:00:00Z',
    inviteCode: 'AHLY-NASRCITY-07',
    members: [
      { userId: 'user_1', role: 'creator', joinedAt: '2026-02-10T12:00:00Z' },
      { userId: 'user_3', role: 'member', joinedAt: '2026-02-11T14:00:00Z' },
      { userId: 'user_5', role: 'member', joinedAt: '2026-02-11T16:00:00Z' }
    ]
  }
];

export const INITIAL_JOIN_REQUESTS: JoinRequest[] = [
  {
    id: 'req_1',
    groupId: 'group_1',
    userId: 'user_11', // Ziad wants to join group 1
    requestedAt: '2026-09-22T10:30:00Z',
    status: 'pending'
  }
];

export const INITIAL_MATCH_POSTS: MatchPost[] = [
  {
    id: 'match_1',
    groupId: 'group_1',
    creatorId: 'user_1',
    creatorName: 'كابتن محمد العرابي',
    creatorAvatar: '/src/assets/images/captain_avatar_1790105748587.jpg',
    createdAt: '2026-09-21T18:00:00Z',
    pitchName: 'ملاعب أرينا سبورت - التجمع الخامس',
    pitchLocationText: 'محور محمد نجيب بجوار النادي الأهلي، التجمع الخامس',
    matchDateTime: '2026-09-24T20:30:00', // Thursday 8:30 PM
    requiredPlayers: 10,
    hourlyRate: 400,
    durationHours: 2,
    totalCost: 800, // 400 * 2 = 800
    notes: '• التواجد في أرض الملعب الساعة 8:15 م للتسخين.\n• اللعب بكوتشي ترتان نجيل صناعي فقط (ممنوع استرزات حديد).\n• يا ريت الالتزام بالمواعيد عشان بنبدأ في دقيقتنا بالظبط.',
    deadlineDateTime: '2026-09-23T18:00:00', // Tomorrow 6 PM
    isCompleted: false, // 9 players playing, 1 spot left!
    responses: [
      { userId: 'user_1', status: 'playing', timestamp: '2026-09-21T18:05:00Z' },
      { userId: 'user_2', status: 'playing', timestamp: '2026-09-21T18:10:00Z' },
      { userId: 'user_3', status: 'playing', timestamp: '2026-09-21T18:15:00Z' },
      { userId: 'user_4', status: 'playing', timestamp: '2026-09-21T18:20:00Z' },
      { userId: 'user_5', status: 'playing', timestamp: '2026-09-21T18:30:00Z' },
      { userId: 'user_6', status: 'playing', timestamp: '2026-09-21T19:00:00Z' },
      { userId: 'user_7', status: 'playing', timestamp: '2026-09-21T19:15:00Z' },
      { userId: 'user_8', status: 'playing', timestamp: '2026-09-21T19:45:00Z' },
      { userId: 'user_9', status: 'playing', timestamp: '2026-09-21T20:00:00Z' },
      { 
        userId: 'user_10', 
        status: 'uncertain', 
        uncertainReason: 'عندي اجتماع في الشغل ومستني أشوف هخلص بدري ولا لأ', 
        timestamp: '2026-09-21T20:10:00Z' 
      }
    ]
  },
  {
    id: 'match_2',
    groupId: 'group_2',
    creatorId: 'user_2',
    creatorName: 'عمر شريف',
    creatorAvatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80',
    createdAt: '2026-09-20T12:00:00Z',
    pitchName: 'صالة المعادي دجلة المغطاة',
    pitchLocationText: 'شارع النصر، دجلة المعادي، الصالة رقم 2',
    matchDateTime: '2026-09-26T19:00:00', // Saturday 7:00 PM
    requiredPlayers: 8,
    hourlyRate: 300,
    durationHours: 1.5,
    totalCost: 450, // 300 * 1.5 = 450
    notes: '• ماتش كورة صالات 4 ضد 4.\n• الحذاء المناسب فوتسال أرضية باركيه خشبية.\n• الكورة رقم 4 خاصة بالصالات.',
    deadlineDateTime: '2026-09-25T14:00:00',
    isCompleted: true, // Exactly 8 playing + 2 waitlisted!
    isFinished: true, // Finished match ready for member rating
    responses: [
      { userId: 'user_1', status: 'playing', timestamp: '2026-09-20T12:05:00Z' },
      { userId: 'user_2', status: 'playing', timestamp: '2026-09-20T12:10:00Z' },
      { userId: 'user_3', status: 'playing', timestamp: '2026-09-20T12:15:00Z' },
      { userId: 'user_4', status: 'playing', timestamp: '2026-09-20T12:20:00Z' },
      { userId: 'user_5', status: 'playing', timestamp: '2026-09-20T12:25:00Z' },
      { userId: 'user_6', status: 'playing', timestamp: '2026-09-20T12:30:00Z' },
      { userId: 'user_7', status: 'playing', timestamp: '2026-09-20T12:35:00Z' },
      { userId: 'user_8', status: 'playing', timestamp: '2026-09-20T12:40:00Z' },
      // Waitlist responses
      { userId: 'user_9', status: 'playing', isWaitlist: true, waitlistIndex: 1, timestamp: '2026-09-20T13:00:00Z' },
      { userId: 'user_10', status: 'playing', isWaitlist: true, waitlistIndex: 2, timestamp: '2026-09-20T13:30:00Z' }
    ]
  },
  {
    id: 'match_3',
    groupId: 'group_3',
    creatorId: 'user_1',
    creatorName: 'كابتن محمد العرابي',
    creatorAvatar: '/src/assets/images/captain_avatar_1790105748587.jpg',
    createdAt: '2026-09-22T08:00:00Z',
    pitchName: 'ملعب النادي الأهلي - فرع مدينة نصر',
    pitchLocationText: 'بوابة 3، بجوار حمام السباحة، مدينة نصر',
    matchDateTime: '2026-09-25T21:00:00',
    requiredPlayers: 10,
    hourlyRate: 350,
    durationHours: 2,
    totalCost: 700,
    notes: '• ماتش ودّي لتجميع أصحاب جدد.\n• الدفع وتقسيم الفلوس قبل ما ننزل الملعب.',
    deadlineDateTime: '2026-09-22T14:00:00', // Deadline expiring soon!
    isCompleted: false,
    responses: [
      { userId: 'user_1', status: 'playing', timestamp: '2026-09-22T08:05:00Z' },
      { userId: 'user_3', status: 'playing', timestamp: '2026-09-22T08:15:00Z' },
      { userId: 'user_5', status: 'declined', timestamp: '2026-09-22T09:00:00Z' }
    ]
  }
];

export const INITIAL_NOTIFICATIONS: AppNotification[] = [
  {
    id: 'notif_1',
    type: 'almost_full',
    title: 'العدد قرّب يكمل! 🔥',
    message: 'حجز الخميس في أرينا سبورت باقي فيه لاعب واحد بس والماتش يتقفل ويكتمل.',
    matchId: 'match_1',
    groupId: 'group_1',
    timestamp: '2026-09-22T11:45:00Z',
    read: false
  },
  {
    id: 'notif_2',
    type: 'waitlist_promoted',
    title: 'مبروك دخلت التشكيل الأساسي! ⚽',
    message: 'في لاعب اعتذر في ماتش صالة المعادي ودخلت مكانه تلقائياً من قائمة الانتظار.',
    matchId: 'match_2',
    groupId: 'group_2',
    timestamp: '2026-09-22T09:10:00Z',
    read: false
  },
  {
    id: 'notif_3',
    type: 'new_match',
    title: 'بوست حجز جديد اتعمل في الجروب 📋',
    message: 'كابتن محمد العرابي نزل حجز جديد لماتش الجمعة بمدينة نصر.',
    matchId: 'match_3',
    groupId: 'group_3',
    timestamp: '2026-09-22T08:00:00Z',
    read: true
  }
];

export const INITIAL_RATINGS: PlayerRating[] = [
  {
    id: 'rate_1',
    matchId: 'match_2',
    matchTitle: 'صالة المعادي دجلة المغطاة',
    raterUserId: 'user_2',
    raterName: 'عمر شريف',
    targetUserId: 'user_1',
    commitmentRating: 5,
    skillRating: 5,
    feedbackTag: 'حريف وملتزم جداً 🌟',
    comment: 'كابتن محمد أول واحد وصل الملعب ولعب بروح عالية وتوجيه ممتاز.',
    createdAt: '2026-09-21T21:00:00Z'
  },
  {
    id: 'rate_2',
    matchId: 'match_2',
    matchTitle: 'صالة المعادي دجلة المغطاة',
    raterUserId: 'user_3',
    raterName: 'مصطفى الشناوي',
    targetUserId: 'user_1',
    commitmentRating: 5,
    skillRating: 5,
    feedbackTag: 'قائد حقيقي في الملعب ⚽',
    comment: 'أداء راقي وهجوم فعال، ودايماً بيشجع كل الفرقة.',
    createdAt: '2026-09-21T21:10:00Z'
  },
  {
    id: 'rate_3',
    matchId: 'match_2',
    matchTitle: 'صالة المعادي دجلة المغطاة',
    raterUserId: 'user_1',
    raterName: 'كابتن محمد العرابي',
    targetUserId: 'user_2',
    commitmentRating: 5,
    skillRating: 5,
    feedbackTag: 'صانع ألعاب من طراز رفيع 🎩',
    comment: 'تمريرات بالمقاس وباص مظبوط، ملتزم بالميعاد ودقيق في اللعب.',
    createdAt: '2026-09-21T21:05:00Z'
  },
  {
    id: 'rate_4',
    matchId: 'match_2',
    matchTitle: 'صالة المعادي دجلة المغطاة',
    raterUserId: 'user_1',
    raterName: 'كابتن محمد العرابي',
    targetUserId: 'user_3',
    commitmentRating: 5,
    skillRating: 5,
    feedbackTag: 'سد منيع في الجون 🧤',
    comment: 'شال كور انفرادات صعبة جداً ومنقذ الماتش بلا منازع.',
    createdAt: '2026-09-21T21:15:00Z'
  },
  {
    id: 'rate_5',
    matchId: 'match_2',
    matchTitle: 'صالة المعادي دجلة المغطاة',
    raterUserId: 'user_1',
    raterName: 'كابتن محمد العرابي',
    targetUserId: 'user_4',
    commitmentRating: 3,
    skillRating: 4,
    feedbackTag: 'دفاع حديدي بس محتاج تدقيق بالميعاد ⏱️',
    comment: 'لعب ماتش كبير وقوي دفاعياً، بس وصل متأخر 15 دقيقة بعد بداية الماتش.',
    createdAt: '2026-09-21T21:20:00Z'
  },
  {
    id: 'rate_6',
    matchId: 'match_2',
    matchTitle: 'صالة المعادي دجلة المغطاة',
    raterUserId: 'user_2',
    raterName: 'عمر شريف',
    targetUserId: 'user_6',
    commitmentRating: 5,
    skillRating: 5,
    feedbackTag: 'رئة الفريق في نص الملعب ⚡',
    comment: 'قطع كور بدون أي فاول والتزام تام بالوقت.',
    createdAt: '2026-09-21T21:25:00Z'
  }
];
